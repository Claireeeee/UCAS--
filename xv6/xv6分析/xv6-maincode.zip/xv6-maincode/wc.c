#include "types.h"
#include "stat.h"
#include "user.h"

char buf[512];

void
wc(int fd, char *name)    //Word Count，统计指定文件中的字节数、字数、行数，并将统计结果显示输出
{
  int i, n;
  int l, w, c, inword;

  l = w = c = 0;
  inword = 0;
  while((n = read(fd, buf, sizeof(buf))) > 0)
  {                                                   //一个buf一个buf的查
    for(i=0; i<n; i++)
    {                                                 //buf内部一个一个字节的查
      c++;                                //c++，字节
      if(buf[i] == '\n')
        l++;                              //line++
      if(strchr(" \r\t\n\v", buf[i]))     //遇到一个
        inword = 0;                       //当前偏移是否在word中
      else if(!inword){                   //inword
        w++;                              //w++，字（除\r\t\n\v外的字节）
        inword = 1;
      }
    }
  }
  if(n < 0){
    printf(1, "wc: read error\n");
    exit();
  }
  printf(1, "%d %d %d %s\n", l, w, c, name);
}

int
main(int argc, char *argv[])
{
  int fd, i;

  if(argc <= 1){                 //如果只有一个参数，直接从wc标准输入
    wc(0, "");
    exit();
  }

  for(i = 1; i < argc; i++)
  {                              //obo wc参数中的fd
    if((fd = open(argv[i], 0)) < 0){
      printf(1, "wc: cannot open %s\n", argv[i]);
      exit();
    }
    wc(fd, argv[i]);
    close(fd);
  }
  exit();
}
