// Sleeping locks

#include "types.h"
#include "defs.h"
#include "param.h"
#include "x86.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
  initlock(&lk->lk, "sleep lock");
  lk->name = name;
  lk->locked = 0;
  lk->pid = 0;
}

void
acquiresleep(struct sleeplock *lk)
{
  acquire(&lk->lk);              //sleeplock结构的锁
  while (lk->locked) {
    sleep(lk, &lk->lk);           //如果已经lock，在这个lock上睡眠  而不是反复spin 因为这个锁使每次用的时间会比较长
  }
  lk->locked = 1;             //否则get
  lk->pid = myproc()->pid;
  release(&lk->lk);
}

void
releasesleep(struct sleeplock *lk)
{
  acquire(&lk->lk);
  lk->locked = 0;
  lk->pid = 0;
  wakeup(lk);
  release(&lk->lk);
}

int
holdingsleep(struct sleeplock *lk)
{
  int r;
  
  acquire(&lk->lk);              //调用保护sleeplock结构的锁，查看sleeplock的状态
  r = lk->locked;
  release(&lk->lk);
  return r;
}



