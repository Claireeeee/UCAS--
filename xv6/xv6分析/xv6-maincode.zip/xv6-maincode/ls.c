#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"

char*
fmtname(char *path)               //返回一个路径中最后的文件的文件名
{
  static char buf[DIRSIZ+1];             //静态数组buf
  char *p;

  // Find first character after last slash.
  for(p=path+strlen(path); p >= path && *p != '/'; p--)        //以路径中最后一个\为分界，取出路径最后的文件名
    ;
  p++;

  // Return blank-padded name.
  if(strlen(p) >= DIRSIZ)             //如果文件名已达最大字数，直接返回（不用下几行的剪空格步骤）
    return p;
  memmove(buf, p, strlen(p));         //把p移动到buf
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));     //文件名有效位数后置零
  return buf;                         //返回buf
}

void
ls(char *path)
{
  char buf[512], *p;                //开一个buf
  int fd;
  struct dirent de;
  struct stat st;

  if((fd = open(path, 0)) < 0){                   //用路径打开一个fd
    printf(2, "ls: cannot open %s\n", path);
    return;
  }

  if(fstat(fd, &st) < 0){                      //fd的信息转到st
    printf(2, "ls: cannot stat %s\n", path);
    close(fd);
    return;
  }

  switch(st.type){
  case T_FILE:                                             //如果是一个文件，直接输出信息
    printf(1, "%s %d %d %d\n", fmtname(path), st.type, st.ino, st.size);
    break;

  case T_DIR:                                      //如果fd是一个目录
    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){       
      printf(1, "ls: path too long\n");
      break;
    }
    strcpy(buf, path);                          //把path放入buf
    p = buf+strlen(buf);                        //p始终保持在buf的最前
    *p++ = '/';                                 //路径后放一个／
    while(read(fd, &de, sizeof(de)) == sizeof(de)) //依次处理每个de
    {                                              
      if(de.inum == 0)
        continue;
      memmove(p, de.name, DIRSIZ);                 //de中文件名放到p
      p[DIRSIZ] = 0;                               //放完后放0做结束标志
      if(stat(buf, &st) < 0){                      //st保存新路径对应文件信息
        printf(1, "ls: cannot stat %s\n", buf);
        continue;
      }
      printf(1, "%s %d %d %d\n", fmtname(buf), st.type, st.ino, st.size);    //输出文件信息
    }
    break;
  }
  close(fd);
}

int
main(int argc, char *argv[])
{
  int i;

  if(argc < 2){
    ls(".");
    exit();
  }
  for(i=1; i<argc; i++)
    ls(argv[i]);
  exit();
}
