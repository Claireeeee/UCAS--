// Shell.

#include "types.h"
#include "user.h"
#include "fcntl.h"

// Parsed command representation
#define EXEC  1
#define REDIR 2
#define PIPE  3
#define LIST  4
#define BACK  5

#define MAXARGS 10

struct cmd {
  int type;
};

struct execcmd {
  int type;
  char *argv[MAXARGS];
  char *eargv[MAXARGS];
};

struct redircmd {
  int type;
  struct cmd *cmd;
  char *file;
  char *efile;
  int mode;
  int fd;
};

struct pipecmd {
  int type;
  struct cmd *left;
  struct cmd *right;
};

struct listcmd {
  int type;
  struct cmd *left;
  struct cmd *right;
};

struct backcmd {
  int type;
  struct cmd *cmd;
};

int fork1(void);  // Fork but panics on failure.
void panic(char*);
struct cmd *parsecmd(char*);

// Execute cmd.  Never returns.
void
runcmd(struct cmd *cmd)
{
  int p[2];
  struct backcmd *bcmd;
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
    exit();

  switch(cmd->type){           //命令类型
  default:
    panic("runcmd");

  case EXEC:
    ecmd = (struct execcmd*)cmd;        //转化成相应类型的cmd结构   应该不回有精度丢失
    if(ecmd->argv[0] == 0)              //参数
      exit();
    exec(ecmd->argv[0], ecmd->argv);     //根据命令参数加载不同的命令执行程序
    printf(2, "exec %s failed\n", ecmd->argv[0]);    //如果返回，就输出failed
    break;

  case REDIR:
    rcmd = (struct redircmd*)cmd;        //重定向。close+open
    close(rcmd->fd);
    if(open(rcmd->file, rcmd->mode) < 0){      //会把刚释放fd用到新开的file上  （用不用一个锁？）
      printf(2, "open %s failed\n", rcmd->file);
      exit();
    }
    runcmd(rcmd->cmd);
    break;

  case LIST:                          
    lcmd = (struct listcmd*)cmd;
    if(fork1() == 0)                  //再开一个子进程，在子进程里执行
      runcmd(lcmd->left);             //
    wait();
    runcmd(lcmd->right);
    break;

  case PIPE:
    pcmd = (struct pipecmd*)cmd;       
    if(pipe(p) < 0)
      panic("pipe");
    if(fork1() == 0){
      close(1);                    //对于每个执行子进程，都要重定向输入输出到管道某端的文件描述符
      dup(p[1]);
      close(p[0]);
      close(p[1]);
      runcmd(pcmd->left);
    }
    if(fork1() == 0){
      close(0);
      dup(p[0]);
      close(p[0]);
      close(p[1]);
      runcmd(pcmd->right);
    }
    close(p[0]);
    close(p[1]);
    wait();                     //回收子进程
    wait();
    break;

  case BACK:                        //后台程序，开一个子进程来执行子命令即可。
    bcmd = (struct backcmd*)cmd;
    if(fork1() == 0)
      runcmd(bcmd->cmd);
    break;
  }
  exit();
}

int
getcmd(char *buf, int nbuf)
{
  printf(2, "$ ");
  memset(buf, 0, nbuf);
  gets(buf, nbuf);               //从键盘读个字符串到buf
  if(buf[0] == 0) // EOF
    return -1;
  return 0;
}

int main(void)
{
  static char buf[100];
  int fd;

  // Ensure that three file descriptors are open.
  while((fd = open("console", O_RDWR)) >= 0){              //开3个fd
    if(fd >= 3){
      close(fd);
      break;
    }
  }

  // Read and run input commands.
  while(getcmd(buf, sizeof(buf)) >= 0){                        //从键盘读个字符串到buf
    if(buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' '){          //如果是cd，直接处理
      // Chdir must be called by the parent, not the child.
      buf[strlen(buf)-1] = 0;  // chop \n
      if(chdir(buf+3) < 0)                                 //chdir
        printf(2, "cannot cd %s\n", buf+3);
      continue;
    }
    if(fork1() == 0)                                  //如果是其他，开个子进程进runcmd处理
      runcmd(parsecmd(buf));                     //对命令进行语法分析，包装成cmd结构传递给runcmd
    wait();
  }
  exit();
}

void
panic(char *s)
{
  printf(2, "%s\n", s);
  exit();
}

int
fork1(void)             //加了一个panic处理的fork
{
  int pid;

  pid = fork();
  if(pid == -1)
    panic("fork");
  return pid;
}

//PAGEBREAK!
// Constructors              构建一个空的相应的cmd结构，用参数初始化，返回地址

struct cmd*
execcmd(void)                             
{
  struct execcmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = EXEC;
  return (struct cmd*)cmd;
}

struct cmd*
redircmd(struct cmd *subcmd, char *file, char *efile, int mode, int fd)
{
  struct redircmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = REDIR;
  cmd->cmd = subcmd;
  cmd->file = file;
  cmd->efile = efile;
  cmd->mode = mode;
  cmd->fd = fd;
  return (struct cmd*)cmd;
}

struct cmd*
pipecmd(struct cmd *left, struct cmd *right)
{
  struct pipecmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = PIPE;
  cmd->left = left;
  cmd->right = right;
  return (struct cmd*)cmd;
}

struct cmd*
listcmd(struct cmd *left, struct cmd *right)
{
  struct listcmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = LIST;
  cmd->left = left;
  cmd->right = right;
  return (struct cmd*)cmd;
}

struct cmd*
backcmd(struct cmd *subcmd)
{
  struct backcmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = BACK;
  cmd->cmd = subcmd;
  return (struct cmd*)cmd;
}
//PAGEBREAK!
// Parsing                       语法分析

char whitespace[] = " \t\r\n\v";        //空格们
char symbols[] = "<|>&;()";             //符号们



//从ps起始es结尾的地址区间中，取一段字符串（无空格无符号），一般是基本命令或者重定向的文件名，q和eq分别是起始和结束未知
int
gettoken(char **ps, char *es, char **q, char **eq)
{
  char *s;
  int ret;

  s = *ps;                 
  while(s < es && strchr(whitespace, *s))         //第一个非零字符
    s++;
  if(q)                     //用第一个非零的地址初始化记录起始位置的q
    *q = s;
  ret = *s;                   
  switch(*s)
  {
  case 0:
    break;
  case '|':                  //遇到!();&<>等等则简单地忽略
  case '(':
  case ')':
  case ';':
  case '&':
  case '<':
    s++;
    break;
  case '>':
    s++;
    if(*s == '>')           //遇到>>，返回+（就是代表>>）
    {
      ret = '+';
      s++;
    }
    break;
  default:
    ret = 'a';           //遇到合法字符，ret修改为a,然后往后，跳过空格与符号，找到一个结尾
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
      s++;
    break;
  }
  if(eq)                   //记录结尾
    *eq = s;

  while(s < es && strchr(whitespace, *s))          //跳过空格移动到下一个字符字符处
    s++;
  *ps = s;           //然后把地址区间起始修改为下一个非零字符
  return ret;
}

int
peek(char **ps, char *es, char *toks)        //移动ps到第一个非零字符，并检验ps中第一个非零字符是不是在合法字符串toks中，返回结果
{
  char *s;

  s = *ps;
  while(s < es && strchr(whitespace, *s))        //找到第一个不是空格的字符s，返回s，放到ps
    s++;
  *ps = s;
  return *s && strchr(toks, *s);            //如果s存在且toks中有s，返回1
}

struct cmd *parseline(char**, char*);
struct cmd *parsepipe(char**, char*);
struct cmd *parseexec(char**, char*);
struct cmd *nulterminate(struct cmd*);

struct cmd*
parsecmd(char *s)
{
  char *es;
  struct cmd *cmd;

  es = s + strlen(s);     //指令结尾
  cmd = parseline(&s, es);
  peek(&s, es, "");        //移动s到首个非零，或到结尾
  if(s != es)
  {
    printf(2, "leftovers: %s\n", s);              //如果还剩下处理不了的字符
    panic("syntax");
  }
  nulterminate(cmd);
  return cmd;
}

struct cmd*
parseline(char **ps, char *es)       //一个line处理的长度，是，一个括号内部，两个分号之间，或者一次完整的命令缓冲区
{
  struct cmd *cmd;

  cmd = parsepipe(ps, es);          //先查是不是管道
  while(peek(ps, es, "&")){         //遇到&
    gettoken(ps, es, 0, 0);         //取出来
    cmd = backcmd(cmd);             //构造一个后台命令cmd，并把之前cmd的都放到子命令里
  }
  if(peek(ps, es, ";")){            //遇到“;”
    gettoken(ps, es, 0, 0);         //取出来
    cmd = listcmd(cmd, parseline(ps, es));         //构造平行cmd，并一个子命令一个子命令的连进去
  }
  return cmd;
}

struct cmd*
parsepipe(char **ps, char *es)
{
  struct cmd *cmd;

  cmd = parseexec(ps, es);           //解析左边基本命令放入cmd（中间会兼顾redir，block，遇到|的时候转出来）
  if(peek(ps, es, "|")){          //管道命令标志，接下来处理右边
    gettoken(ps, es, 0, 0);        //取出|，往后取基本指令
    cmd = pipecmd(cmd, parsepipe(ps, es));    //前后两次pipe调用生成的cmd作为子命令分别放入pipecmd的左右子命令位置
  }
  return cmd;
}

struct cmd*
parseredirs(struct cmd *cmd, char **ps, char *es)        //构造一个redircmd，放到cmd里（原来的cmd放入redircmd的字命令位置）
{
  int tok;
  char *q, *eq;

  while(peek(ps, es, "<>"))
  {           //如果第一个非零是“<>”（重定向参数）
    tok = gettoken(ps, es, 0, 0);      //取出第一个“>>,<或>”
    if(gettoken(ps, es, &q, &eq) != 'a')     //再往后取参数
      panic("missing file for redirection");
    switch(tok)
    {                                 //构造三种重定向命令结构
    case '<':
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
      break;
    case '>':
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
      break;
    case '+':  // >>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
      break;
    }
  }
  return cmd;
}

struct cmd*
parseblock(char **ps, char *es)
{
  struct cmd *cmd;

  if(!peek(ps, es, "("))
    panic("parseblock");
  gettoken(ps, es, 0, 0);      //输出位置为空，只是跳过“（“，然后调用parceline
  cmd = parseline(ps, es);
  if(!peek(ps, es, ")"))        //检查“）“
    panic("syntax - missing )");
  gettoken(ps, es, 0, 0);     //跳过“）”
  cmd = parseredirs(cmd, ps, es);   //()内的整体命令可能跟着重定向参数，用parseredirs()看能不能包装成redircmd
  return cmd;
}

struct cmd*
parseexec(char **ps, char *es)
{
  char *q, *eq;
  int tok, argc;
  struct execcmd *cmd;
  struct cmd *ret;

  if(peek(ps, es, "("))                 //如果ps开始的字符串第一个非零字符是（，说明是个独立的命令，用parseblock开一个新parseline
    return parseblock(ps, es);

  ret = execcmd();                     //开一个基本命令结构
  cmd = (struct execcmd*)ret;          //然后包装成统一命令结构

  argc = 0;
  ret = parseredirs(ret, ps, es);        //把execcmd作为子命令传递给parseredirs()函数，看能不能构造redircmd。
  while(!peek(ps, es, "|)&;"))
  {                       //如果第一个非零不是"|)&;"
    if((tok=gettoken(ps, es, &q, &eq)) == 0)   //取基本指令
      break;
    if(tok != 'a')                   //如果找不到基本指令
      panic("syntax");
    cmd->argv[argc] = q;            //基本指令字符串放到cmd的参数里
    cmd->eargv[argc] = eq;
    argc++;
    if(argc >= MAXARGS)
      panic("too many args");
    ret = parseredirs(ret, ps, es);     //看能不能构造redircmd。
  }
  cmd->argv[argc] = 0;                //取到第一个非零是"|)&;"时（留着给管道和block等处理），参数的最后填上0，返回构建好的基本命令cmd数组
  cmd->eargv[argc] = 0;
  return ret;
}

// NUL-terminate（每一个字符串的结束位置放\0） all the counted strings.
struct cmd*
nulterminate(struct cmd *cmd)
{
  int i;
  struct backcmd *bcmd;
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
    return 0;

  switch(cmd->type){
  case EXEC:
    ecmd = (struct execcmd*)cmd;
    for(i=0; ecmd->argv[i]; i++)
      *ecmd->eargv[i] = 0;
    break;

  case REDIR:
    rcmd = (struct redircmd*)cmd;
    nulterminate(rcmd->cmd);
    *rcmd->efile = 0;
    break;

  case PIPE:
    pcmd = (struct pipecmd*)cmd;
    nulterminate(pcmd->left);
    nulterminate(pcmd->right);
    break;

  case LIST:
    lcmd = (struct listcmd*)cmd;
    nulterminate(lcmd->left);
    nulterminate(lcmd->right);
    break;

  case BACK:
    bcmd = (struct backcmd*)cmd;
    nulterminate(bcmd->cmd);
    break;
  }
  return cmd;
}
