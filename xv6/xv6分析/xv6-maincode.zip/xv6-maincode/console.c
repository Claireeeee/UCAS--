// Console input and output.
// Input is from the keyboard or serial port.
// Output is written to the screen and serial port.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "traps.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "file.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"


static void consputc(int);

static int panicked = 0;             //记录是否panic

static struct {
  struct spinlock lock;            //locking是什么？
  int locking;
} cons;

static void
printint(int xx, int base, int sign)        //基为base，符号（正负）为sign的int输出    xx应该是一个地址啊
{
  static char digits[] = "0123456789abcdef";
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))            //sign=1且xx<0
    x = -xx;
  else
    x = xx;

  i = 0;
  do{
    buf[i++] = digits[x % base];         //一位一位的放入缓冲区（逆序）（没有用编码，直接用了一个类似编码的数组）
  }while((x /= base) != 0);

  if(sign)
    buf[i++] = '-';          //最后放入符号

  while(--i >= 0)
    consputc(buf[i]);       //连续输出xx
}
//PAGEBREAK: 50

// Print to the console. only understands %d, %x, %p, %s.        输出fmt到控制台（屏幕（缓冲区））
void
cprintf(char *fmt, ...)      
{
  int i, c, locking;
  uint *argp;
  char *s;

  locking = cons.locking;
  if(locking)
    acquire(&cons.lock);

  if (fmt == 0)
    panic("null fmt");

  argp = (uint*)(void*)(&fmt + 1);   //字符串地址的地址+1，就是第二个参数的地址
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++)
  {
    if(c != '%')
    {
      consputc(c);                   //如果是字符，直接char输出
      continue;
    }
    c = fmt[++i] & 0xff;             //如果是格式参数，分辨以后用专门的函数输出
    if(c == 0)
      break;
    switch(c)
    {
    case 'd':
      printint(*argp++, 10, 1);            //int  每次处理完一个参数后++，到下一个参数的位置
      break;
    case 'x':
    case 'p':
      printint(*argp++, 16, 0);            //16进制
      break;
    case 's':
      if((s = (char*)*argp++) == 0)        //字符串
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
      break;
    case '%':                          //%
      consputc('%');
      break;
    default:
      // Print unknown % sequence to draw attention.
      consputc('%');
      consputc(c);
      break;
    }
  }

  if(locking)
    release(&cons.lock);
}

void
panic(char *s)
{
  int i;
  uint pcs[10];

  cli();
  cons.locking = 0;
  // use lapiccpunum so that we can call panic from mycpu()
  cprintf("lapicid %d: panic: ", lapicid());
  cprintf(s);
  cprintf("\n");
  getcallerpcs(&s, pcs);
  for(i=0; i<10; i++)
    cprintf(" %p", pcs[i]);
  panicked = 1;  // freeze other CPU    （用死循环）  为什么是other cpu，这不是把自己困住了吗？
  for(;;)        //每次panic都freeze？为什么要这样？frose了怎么破？
    ;
}

//PAGEBREAK: 50
#define BACKSPACE 0x100
#define CRTPORT 0x3d4          //是一个IO端口，里面放的是crt内存的当前位置   为什么非得用一个端口存储位置？
static ushort *crt = (ushort*)P2V(0xb8000);  // CGA memory   crt数组=显示内存=屏幕缓冲区

static void
cgaputc(int c)              //把c放入crt数组
{ 
  int pos;

  // Cursor position: col + 80*row.      控制台就是80列的表格  pos记录位置
  outb(CRTPORT, 14);                     //14和15写入crtport。为什么？这是什么标志？
  pos = inb(CRTPORT+1) << 8;          //8位8位的读进crtport里记录的的位置
  outb(CRTPORT, 15);
  pos |= inb(CRTPORT+1);

  if(c == '\n')
    pos += 80 - pos%80;         //换行  退格
  else if(c == BACKSPACE){      
    if(pos > 0) --pos;
  } else
    crt[pos++] = (c&0xff) | 0x0700;  // black on white    pos处放上c  这是实质性的一步

  if(pos < 0 || pos > 25*80)                //只有25*80这么大的显示内存
    panic("pos under/overflow");

  if((pos/80) >= 24){  // Scroll up.           本来指向25行的
    memmove(crt, crt+80, sizeof(crt[0])*23*80);         //后23行往前移
    pos -= 80;                                         //pos挪到24行
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));      //把pos降行后的地址所在的一行pos之后的位置清0
  }

  outb(CRTPORT, 14);               //pos的值放到crtport。crtport地址里，记录的是crt的当前位置
  outb(CRTPORT+1, pos>>8);
  outb(CRTPORT, 15);
  outb(CRTPORT+1, pos);
  crt[pos] = ' ' | 0x0700;    //pos处放一个空格
}

void
consputc(int c)          
{
  if(panicked){
    cli();
    for(;;)
      ;
  }

  if(c == BACKSPACE){             //退格
    uartputc('\b'); uartputc(' '); uartputc('\b');     //这几个uart函数没有看懂
  } else
    uartputc(c);          //uartput是干什么的？（cgaput是放到显示内存里）
  cgaputc(c);
}

#define INPUT_BUF 128                     //输入缓冲区  直接用128个buf实现的
struct {
  char buf[INPUT_BUF];
  uint r;  // Read index
  uint w;  // Write index
  uint e;  // Edit index
} input;

#define C(x)  ((x)-'@')  // Control-x     ？？？

void
consoleintr(int (*getc)(void))    //io中断 （不同函数指针处理不同的中断，比如kbdget处理键盘（用于从键盘硬件端口读输入并返回）
{
  int c, doprocdump = 0;

  acquire(&cons.lock);
  while((c = getc()) >= 0){               //读一个输入
    switch(c){
    case C('P'):  // Process listing.      //case们没看懂
      // procdump() locks cons.lock indirectly; invoke later
      doprocdump = 1;
      break;
    case C('U'):  // Kill line.
      while(input.e != input.w &&            
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
        input.e--;
        consputc(BACKSPACE);
      }
      break;
    case C('H'): case '\x7f':  // Backspace
      if(input.e != input.w){
        input.e--;
        consputc(BACKSPACE);
      }
      break;
    default:
      if(c != 0 && input.e-input.r < INPUT_BUF){
        c = (c == '\r') ? '\n' : c;
        input.buf[input.e++ % INPUT_BUF] = c;
        consputc(c);
        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
          input.w = input.e;
          wakeup(&input.r);
        }
      }
      break;
    }
  }
  release(&cons.lock);
  if(doprocdump) {
    procdump();  // now call procdump() wo. cons.lock held
  }
}

int
consoleread(struct inode *ip, char *dst, int n)     //读n个int到dst，这里的ip是console的inode
{
  uint target;
  int c;

  iunlock(ip);          //为什么这个过程要解开console的inode的锁？
  target = n;
  acquire(&cons.lock);
  while(n > 0)
  {
    while(input.r == input.w)
    {
      if(myproc()->killed)
      {
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
    }
    c = input.buf[input.r++ % INPUT_BUF];        //从input缓冲区读出一个c
    if(c == C('D'))              //如果遇到EOF
    {  // EOF
      if(n < target)        //如果一次读循环的过程中间
      {
        // Save ^D for next time, to make sure caller gets a 0-byte result.
        input.r--;   //放回去，下次再来。这样下次可以设计返回一个0（或其他）标志结尾（如果中途eof这次的返回值是要标志读出量的）
      }
      break;               //遇到EOF，（放回去），断
    }
    *dst++ = c;                //放入dst
    --n;
    if(c == '\n')
      break;               //遇到\n，断
  }
  release(&cons.lock);
  ilock(ip);

  return target - n;          //返回读出的int数
}

int
consolewrite(struct inode *ip, char *buf, int n)          //从buf里输出n个int
{
  int i;

  iunlock(ip);            
  acquire(&cons.lock);
  for(i = 0; i < n; i++)
    consputc(buf[i] & 0xff);
  release(&cons.lock);
  ilock(ip);                  //为什么

  return n;
}

void
consoleinit(void)
{
  initlock(&cons.lock, "console");

  devsw[CONSOLE].write = consolewrite;             //设备映射   函数名值就是函数地址吗？
  devsw[CONSOLE].read = consoleread;
  cons.locking = 1;

  ioapicenable(IRQ_KBD, 0);
}

