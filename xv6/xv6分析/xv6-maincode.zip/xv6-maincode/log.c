#include "types.h"
#include "defs.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "buf.h"

// Simple logging that allows concurrent FS system calls.
//
// A log transaction contains the updates of multiple FS system
// calls. The logging system only commits when there are
// no FS system calls active. Thus there is never
// any reasoning required about whether a commit might
// write an uncommitted system call's updates to disk.
//
// A system call should call begin_op()/end_op() to mark
// its start and end. Usually begin_op() just increments
// the count of in-progress FS system calls and returns.
// But if it thinks the log is close to running out, it
// sleeps until the last outstanding end_op() commits.
//
// The log is a physical re-do log containing disk blocks.
// The on-disk log format:
//   header block, containing block #s for block A, B, C, ...
//   block A
//   block B
//   block C
//   ...
// Log appends are synchronous.

// Contents of the header block, used for both the on-disk header block
// and to keep track in memory of logged block# before commit.
struct logheader {
  int n;
  int block[LOGSIZE];   //应该是block号 
};

struct log {
  struct spinlock lock;
  int start;              //开始的扇区号
  int size;
  int outstanding; // how many FS sys calls are executing.
  int committing;  // in commit(), please wait.
  int dev;
  struct logheader lh;
};
struct log log;     //一开始就建了一个log结构

static void recover_from_log(void);
static void commit();

void
initlog(int dev)          //没有清零outstanding
{
  if (sizeof(struct logheader) >= BSIZE)         //lh也有大小限制
    panic("initlog: too big logheader");

  struct superblock sb;              //一个sb
  initlock(&log.lock, "log");
  readsb(dev, &sb);                   //从dev read superblock，里面先用了bread读到buf，然后从buf menmove到sb
  log.start = sb.logstart;            //初始化log
  log.size = sb.nlog;
  log.dev = dev;
  recover_from_log();                //如果loglh不是0的话，直接开始commit（说明之前的没完成）
}

// Copy committed blocks from log to their home location   
//从log往磁盘log，数据部分（以buf为中介，从磁盘read到各自的buf，修改buf，然后write）
static void
install_trans(void)
{
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) { 
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block   就是从log里读一个buf出来，
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); 
                                                   // read dst   dst也要读出来？，不是往里写就行了吗？感觉bget开个空buf就行了啊
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    bwrite(dbuf);  // write dst to disk
    brelse(lbuf);
    brelse(dbuf);
  }
}

// Read the log header from disk into the in-memory log header
//内存log与磁盘log，lh交替
static void
read_head(void)
{
  struct buf *buf = bread(log.dev, log.start);        //这一下就是一个block吧，lh在disk的start那里哦？
  struct logheader *lh = (struct logheader *) (buf->data);      //lh的内存地址
  int i;
  log.lh.n = lh->n;                                   //记录到log里
  for (i = 0; i < log.lh.n; i++) {                   
    log.lh.block[i] = lh->block[i];        //直接放上block数组地址不可以吗？为什么要一个一个值的复制？  ……因为这里是磁盘和内存的交接啊……
  }
  brelse(buf);
}

// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
//内存log与磁盘log，lh交替
static void
write_head(void)
{
  struct buf *buf = bread(log.dev, log.start);      //也是用read，用bget不行吗？
  struct logheader *hb = (struct logheader *) (buf->data);   //buf的内存地址，这里应该放lh
  int i;
  hb->n = log.lh.n;
  for (i = 0; i < log.lh.n; i++) {
    hb->block[i] = log.lh.block[i];          //把准备好的lh放进去
  }
  bwrite(buf);                //写回磁盘log区
  brelse(buf);
}



//
static void
recover_from_log(void)               
{
  read_head();         //加载lh到内存上的log结构
  install_trans(); // if committed, copy from log to disk       有了log的start和lh，就可以安排数据转移了
  log.lh.n = 0;               //转移完lh的block数置零
  write_head(); // clear the log      往磁盘写lh
}

// called at the start of each FS system call.
void
begin_op(void)
{
  acquire(&log.lock);
  while(1){
    if(log.committing){            //commiting（这就是传说中的会话？）
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    } else {
      log.outstanding += 1;
      release(&log.lock);
      break;
    }
  }
}

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
  int do_commit = 0;

  acquire(&log.lock);
  log.outstanding -= 1;
  if(log.committing)
    panic("log.committing");
  if(log.outstanding == 0){
    do_commit = 1;
    log.committing = 1;
  } else {
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);

  if(do_commit){
    // call commit w/o holding locks, since not allowed
    // to sleep with locks.
    commit();
    acquire(&log.lock);
    log.committing = 0;
    wakeup(&log);
    release(&log.lock);
  }
}

// Copy modified blocks from cache to log.
static void
write_log(void)
{
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
    struct buf *to = bread(log.dev, log.start+tail+1); // log block      要转移的buf内容写入log的从start开始的block，日志区的block里（并不直接放到该放的block）
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    memmove(to->data, from->data, BSIZE);
    bwrite(to);  // write the log
    brelse(from);
    brelse(to);
  }
}

static void
commit()
{
  if (log.lh.n > 0) {
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    install_trans(); // Now install writes to home locations
    log.lh.n = 0;
    write_head();    // Erase the transaction from the log
  }
}

// Caller has modified b->data and is done with the buffer.
// Record the block number and pin in the cache with B_DIRTY.
// commit()/write_log() will do the disk write.
//
// log_write() replaces bwrite(); a typical use is:
//   bp = bread(...)
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)              //把一个buf加到log里，
{
  int i;
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    panic("too big a transaction");
  if (log.outstanding < 1)
    panic("log_write outside of trans");

  acquire(&log.lock);
  for (i = 0; i < log.lh.n; i++) {
    if (log.lh.block[i] == b->blockno)   // log absorbtion
      break;
  }
  log.lh.block[i] = b->blockno;
  if (i == log.lh.n)
    log.lh.n++;
  b->flags |= B_DIRTY; // prevent eviction
  release(&log.lock);
}

