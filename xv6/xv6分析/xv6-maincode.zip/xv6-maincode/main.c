#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"

static void startothers(void);
static void mpmain(void)  __attribute__((noreturn));
extern pde_t *kpgdir;
extern char end[]; // first address after kernel loaded from ELF file

// Bootstrap processor starts running C code here.
// Allocate a real stack and switch to it, first
// doing some setup required for memory allocator to work.
int
main(void)
{
  kinit1(end, P2V(4*1024*1024)); // phys page allocator
  kvmalloc();      // kernel page table         更换页表
                
  //一堆init
  //mp的配置，APIC的配置，usrt的配置，缓冲区，段描述符，控制台，磁盘     都跟硬件相关


  mpinit();        // detect other processors   配置化其他处理器   好多看不懂
  lapicinit();     // interrupt controller   设置APIC？          好多看不懂
  seginit();       // segment descriptors    段基址设为0，基本取消了分段机制
  picinit();       // disable pic            disable pic
  ioapicinit();    // another interrupt controller      ioapic       不懂
  consoleinit();   // console hardware       初始化了一个锁和结构 
  uartinit();      // serial port            uart                    不懂
  pinit();         // process table          初始化一个ptable锁 
  tvinit();        // trap vectors           trap vector？没查到，可能讲义里有？
  binit();         // buffer cache           buffer和cache初始化
  fileinit();      // file table             只初始化了一个文件锁
  ideinit();       // disk                   disk init？              不太懂
  startothers();   // start other processors    boot CPU在运转，其他CPU需要boot CPU启动
  

  kinit2(P2V(4*1024*1024), P2V(PHYSTOP)); // must come after startothers()   接着kinit，分配剩余的内存（到freelist）


  userinit();      // first user process     构建第一个进程
  mpmain();        // finish this processor's setup
}

// Other CPUs jump here from entryother.S.
static void
mpenter(void)
{
  switchkvm();   //换新页表
  seginit();     //
  lapicinit();
  mpmain();
}

// Common CPU setup code.
//cpu就是这么启动的
static void
mpmain(void)
{
  cprintf("cpu%d: starting %d\n", cpuid(), cpuid());
  idtinit();       // 将IDT的入口地址装入IDTR寄存器   load idt register
  xchg(&(mycpu()->started), 1); // 修改cpu状态，tell startothers() we're up
  scheduler();     // start running processes

// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run
//  - swtch to start running that process
//  - eventually that process transfers control
//      via swtch back to the scheduler.

}

pde_t entrypgdir[];  // For entry.S

// Start the non-boot (AP) processors.
static void
startothers(void)
{
  extern uchar _binary_entryother_start[], _binary_entryother_size[];
  uchar *code;
  struct cpu *c;
  char *stack;

  // Write entry code to unused memory at 0x7000.
  // The linker has placed the image of entryother.S in _binary_entryother_start.

  //让其他CPU执行名为entryother.S对应的代码
  code = P2V(0x7000);          //entryothers在生成二进制文件时指定入口点start以及加载地址和链接地址都为0x7000
                               //(都是从makefile看出来的，感觉可以学一下makefile 的语法)
  memmove(code, _binary_entryother_start, (uint)_binary_entryother_size);  

  for(c = cpus; c < cpus+ncpu; c++)
  {
    if(c == mycpu())  // We've started already.
      continue;

    // Tell entryother.S what stack to use, where to enter, and what pgdir to use. 
    // We cannot use kpgdir yet, because the AP processor is running in low  memory, so we use entrypgdir for the APs too.
    stack = kalloc();
    *(void**)(code-4) = stack + KSTACKSIZE;
    *(void**)(code-8) = mpenter;
    *(int**)(code-12) = (void *) V2P(entrypgdir);
  //此时其他cpu相当于刚上电的情形，entryothers是它们最初运行的内核代码，没有开启保护模式和分页机制
  //所以用entrypgdir，是因为现在code那分配的地址，是其他cpu一会要用的？它们只能用基址，只能自己手动开页表

    lapicstartap(c->apicid, V2P(code));   
    //就是这个函数启动了其他cpu，让他们从code那里开始运行entryothers（但是我没看懂,怎么调度其他cpu呀？谁在调度？ ß）
    //entryothers初始化了段寄存器，开了保护模式，建了4M页表，然后跳回了上面的mpenter函数那里

    // wait for cpu to finish mpmain()
    while(c->started == 0)
      ;
  }
}

// The boot page table used in entry.S and entryother.S.
// Page directories (and page tables) must start on page boundaries,
// hence the __aligned__ attribute.
// PTE_PS in a page directory entry enables 4Mbyte pages.

//这几行是汇编吧？没看懂怎么实现


__attribute__((__aligned__(PGSIZE)))
pde_t entrypgdir[NPDENTRIES] = {
  // Map VA's [0, 4MB) to PA's [0, 4MB)
  [0] = (0) | PTE_P | PTE_W | PTE_PS,
  // Map VA's [KERNBASE, KERNBASE+4MB) to PA's [0, 4MB)
  [KERNBASE>>PDXSHIFT] = (0) | PTE_P | PTE_W | PTE_PS,
};

//PAGEBREAK!
// Blank page.
//PAGEBREAK!
// Blank page.
//PAGEBREAK!
// Blank page.

