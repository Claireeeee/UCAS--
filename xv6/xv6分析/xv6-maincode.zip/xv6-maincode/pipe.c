#include "types.h"
#include "defs.h"
#include "param.h"
#include "mmu.h"
#include "proc.h"
#include "fs.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "file.h"

#define PIPESIZE 512

struct pipe {
  struct spinlock lock;
  char data[PIPESIZE];
  uint nread;     // number of bytes read
  uint nwrite;    // number of bytes written
  int readopen;   // read fd is still open
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)      //新建一个连接到f1，f2的pipe
{
  struct pipe *p;

  p = 0;
  *f0 = *f1 = 0;
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)       //开两个文件结构，用于管道的读写
    goto bad;
  if((p = (struct pipe*)kalloc()) == 0)              //为pipe分配物理内存    
    goto bad;
  p->readopen = 1;
  p->writeopen = 1;
  p->nwrite = 0;
  p->nread = 0;
  initlock(&p->lock, "pipe");
  (*f0)->type = FD_PIPE;             //分别用于读写
  (*f0)->readable = 1;
  (*f0)->writable = 0;
  (*f0)->pipe = p;
  (*f1)->type = FD_PIPE;
  (*f1)->readable = 0;
  (*f1)->writable = 1;
  (*f1)->pipe = p;
  return 0;

//PAGEBREAK: 20
 bad:
  if(p)
    kfree((char*)p);
  if(*f0)
    fileclose(*f0);
  if(*f1)
    fileclose(*f1);
  return -1;
}

void
pipeclose(struct pipe *p, int writable)      //一次只能关闭一个端口。参数会是一个端口文件的pipe和writable
{
  acquire(&p->lock);
  if(writable){                   //要关闭写端口
    p->writeopen = 0;             //关闭writeopen
    wakeup(&p->nread);            //唤醒read
  } else {
    p->readopen = 0;              //要关闭读端口，关闭readopen，唤醒write
    wakeup(&p->nwrite);
  }
  if(p->readopen == 0 && p->writeopen == 0){     //如果两个文件口都已经关闭，就释放pipe
    release(&p->lock);
    kfree((char*)p);
  } else
    release(&p->lock);
}

//PAGEBREAK: 40
int
pipewrite(struct pipe *p, char *addr, int n)         //从addr处写n个字节到p
{
  int i;

  acquire(&p->lock);                     //锁  
  for(i = 0; i < n; i++)
  {
    while(p->nwrite == p->nread + PIPESIZE)       //如果是满的，启动要读的进程
    {  //DOC: pipewrite-full      
      if(p->readopen == 0 || myproc()->killed)
      {                 //满的，又不能读
        release(&p->lock);
        return -1;
      }
      wakeup(&p->nread);                    //唤醒在这个chan上sleep的进程
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep         要write的进程先在这sleep
    }
    p->data[p->nwrite++ % PIPESIZE] = addr[i];     //写。write记录的是已经写入的总字节数
  }
  wakeup(&p->nread);                               //写完之后启动要读的进程
  release(&p->lock);
  return n;
}

int
piperead(struct pipe *p, char *addr, int n)         //读n个数据到addr
{
  int i;

  acquire(&p->lock);
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty     如果是空的，可以写
    if(myproc()->killed){                 //检查一下是不是kill了？为什么有可能被kill？
      release(&p->lock);
      return -1;
    }
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    if(p->nread == p->nwrite)    
      break;
    addr[i] = p->data[p->nread++ % PIPESIZE];         //一个一个读入addr
  }
  wakeup(&p->nwrite);  //DOC: piperead-wakeup    唤醒要写的进程
  release(&p->lock);
  return i;
}
