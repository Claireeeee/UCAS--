#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "defs.h"
#include "x86.h"
#include "elf.h"


//exec()会构建进程页表，读取程序ELF信息，找到相应的section，申请内存并将section中数据写入新分配的内存中
//ph加载完之后压入参数，然后修改cpu当前进程的寄存器，切换到新加载的进程里
//进程结构的其他部分fork已经设定好了，exec只需要改一下页表，加载一下程序文件，切换一下上下文执行就好
int
exec(char *path, char **argv)
{
  char *s, *last;
  int i, off;
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;    //在内存上为要加载的文件声明空间，一会就放进去
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();

  begin_op();  // called at the start of each FS system call.  用于get一个锁

  //找到path对应的inode
  if((ip = namei(path)) == 0){  //namei：Look up and return the inode for a path name.
    end_op();   // called at the end of each FS system call.commits if this was the last outstanding operation.
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);  // Lock the given inode.（？？？why？）Reads the inode from disk if necessary.
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))   //从ip中读文件到建好的elf结构中
    goto bad;
  if(elf.magic != ELF_MAGIC)
    goto bad;

  if((pgdir = setupkvm()) == 0)  //内核态页表映射
    goto bad;

  // Load program into memory.
  sz = 0;
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){   //一块一块的加载ph（复制）到ph结构中（只是头表）
      if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
      goto bad;
    if(ph.type != ELF_PROG_LOAD)
      continue;
    if(ph.memsz < ph.filesz)
      goto bad;
    if(ph.vaddr + ph.memsz < ph.vaddr)
      goto bad;
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
      // 按ph定义的va找到页框位置，分配物理页，建立映射（并没有填充）
      // 此时sz=0（因为每个进程的虚拟地址都是从0开始的吧），pgdir是内核目录页基址
      // allocuvm: Allocate page tables and physical memory to grow process from oldsz to
      // newsz, which need not be page aligned.  Returns new size or 0 on error.
      goto bad;
    if(ph.vaddr % PGSIZE != 0)
      goto bad;
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
      //loaduvm: Load a program segment into pgdir.  addr must be page-aligned
      // and the pages from addr to addr+sz must already be mapped.
      //按ph中的va（此时页表已经可以映射到物理内存了）加载data和code
      goto bad;
  }
  iunlockput(ip);
  //unlock(打开一个文件的锁)，then iput（// Drop a reference to an in-memory inode.）
  end_op();
  ip = 0;

  // Allocate two pages at the next page boundary.
  // Make the first inaccessible.  Use the second as the user stack.
  //开两个页，一个保护，一个作为用户堆栈，地址会放到tf的esp里
  sz = PGROUNDUP(sz);   //sz记录的应该是当前进程使用的最高虚拟地址
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
    goto bad;
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
  // Clear PTE_U on a page. Used to create an inaccessible   
  // page beneath the user stack.
  sp = sz;

  // Push argument strings, prepare rest of stack in ustack.
  for(argc = 0; argv[argc]; argc++) {
    if(argc >= MAXARG)
      goto bad;
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;   //& ~3，最后两位清零，4位对齐
    //strlen(argv[argc]) + 1)，读地址中的字符串长度，再加上最后的\0
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)   //参数全部压栈
      //copyout： Copy len bytes from p to user address va in page table pgdir.
      // Most useful when pgdir is not the current page table.
      goto bad;
    ustack[3+argc] = sp;   //ustack数组，存放各参数的指针，pc，argc，参数指针的指针，一会数组会压栈
  }
  ustack[3+argc] = 0;   //最后一位放空指针

  ustack[0] = 0xffffffff;  //系统调用不用返回，这里pc占个位就行  //进程的栈都是这样的结构（从低到高：pc，参数个数，参数地址指针，参数地址们）
  ustack[1] = argc;
  ustack[2] = sp - (argc+1)*4;  // argv pointer  参数指针的地址

  sp -= (3+argc+1) * 4;
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)    //ustack压栈
    goto bad;

  // Save program name for debugging.
  for(last=s=path; *s; s++)
    if(*s == '/')
      last = s+1;
  safestrcpy(curproc->name, last, sizeof(curproc->name));

  // Commit to the user image.
  //用新加载的程序文件修改cpu当前进程参数
  oldpgdir = curproc->pgdir;
  curproc->pgdir = pgdir;
  curproc->sz = sz;
  curproc->tf->eip = elf.entry;  //新代码块入口
  cprintf("\n****************%d*****************\n",elf.entry);
  curproc->tf->esp = sp;
  switchuvm(curproc);     //更新cpu中该进程会用的信息（因为刚刚换血了嘛）：该进程指定的内核栈（放TSS中）和页表
  freevm(oldpgdir);       //释放原来进程的页表管理的空间
  //父子进程各有自己的内存空间，这里的页表空间释放掉，父进程的页表不会受影响
  return 0;

 bad:
  if(pgdir)
    freevm(pgdir);
  if(ip){
    iunlockput(ip);
    end_op();
  }
  return -1;
}
