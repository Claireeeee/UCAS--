// Physical memory allocator, intended to allocate
// memory for user processes, kernel stacks, page table pages,
// and pipe buffers. Allocates 4096-byte pages.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"

void freerange(void *vstart, void *vend);
extern char end[]; // first address after kernel loaded from ELF file
                   // defined by the kernel linker script in kernel.ld

struct run {            //空闲链表
  struct run *next;
};

struct {                //链表和保护链表的锁都封装在一个结构体中，这样逻辑就比较明晰：锁保护了该结构体中的域。
  struct spinlock lock;
  int use_lock;          //判断是否使用锁（kinit1就主动选择不用锁）
  struct run *freelist;
} kmem;                       

// Initialization happens in two phases.
// 1. main() calls kinit1() while still using entrypgdir to place just
// the pages mapped by entrypgdir on free list.
// 2. main() calls kinit2() with the rest of the physical pages
// after installing a full page table that maps them on all cores.

/*pdt中只存在4MB内存需要使用kinit1初始化。后面建立成熟的页表可以访问所有内存后，再调用kinit2初始化剩余内存。
调用kinit1时并不用锁，也不能锁。因为锁在4MB空间之外。一旦建立好成熟页表后，锁对于保护这个全局链表的安全就相当重要了。*/

//kinit1 使用freerange 将内存加入空闲链表
void
kinit1(void *vstart, void *vend)
{
  initlock(&kmem.lock, "kmem");   //初始化锁
  kmem.use_lock = 0;
  freerange(vstart, vend);
}

void
kinit2(void *vstart, void *vend)
{
  freerange(vstart, vend);
  kmem.use_lock = 1;
}


//freearnge 通过kfree将内存加入空闲链表
void
freerange(void *vstart, void *vend)            //用的都是虚拟地址
{
  char *p;
  p = (char*)PGROUNDUP((uint)vstart);
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
    kfree(p);
}
//PAGEBREAK: 21
// Free the page of physical memory pointed at by v,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)   //v必须对齐一页，freelist是一页一页的链表
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);    //这个页要释放了，页面内容要先junk     这里是要用到v的物理地址的

  if(kmem.use_lock)        //用锁
    acquire(&kmem.lock);
  r = (struct run*)v;       //把v转换为一个run结构
  r->next = kmem.freelist;  //放回freelist
  kmem.freelist = r;        //freelist就是这么从空表构建起来的
  if(kmem.use_lock)
    release(&kmem.lock);
}

// Allocate one 4096-byte page of physical memory.  分配一个4k的物理内存
// Returns a pointer that the kernel can use.  返回一个内核可以使用的地址
// Returns 0 if the memory cannot be allocated.
char*
kalloc(void)
{
  struct run *r;

  if(kmem.use_lock)        //kmem锁
    acquire(&kmem.lock);
  r = kmem.freelist;
  if(r)
    kmem.freelist = r->next;  //取走一页，更新freelist（内存就是freelist管理的呀）
  if(kmem.use_lock)
    release(&kmem.lock);
  return (char*)r;    //应该是一个页基址（应该是一个虚拟地址，好像减去kernbase就可以变回物理地址）
}

