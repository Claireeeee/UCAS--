// Format of an ELF executable file

#define ELF_MAGIC 0x464C457FU  // "\x7FELF" in little endian

// File header
/*  // elf.h 部分内容
 
struct Elf {  // ELF header
  uint32_t e_magic; // must equal ELF_MAGIC
  uint8_t e_elf[12];  // magic number 的相关信息
  uint16_t e_type;  // 文件类型，1 = 可重定位的，2 = 可执行的，3 = 共享的，4 = 核心的
  uint16_t e_machine; // 机器的指令集结构，例如 0x03 代表 x86，0x08 代表 MIPS 等
  uint32_t e_version; // ELF 文件版本
  uint32_t e_entry; // 程序入口的地址
  uint32_t e_phoff; // program header table 的偏移地址
  uint32_t e_shoff; // section header table 的偏移地址
  uint32_t e_flags; // 与机器的架构相关的值
  uint16_t e_ehsize;  // ELF header 大小
  uint16_t e_phentsize; // program header table 条目大小
  uint16_t e_phnum;<  // program header table 条目数量
  uint16_t e_shentsize; // section header table 条目大小
  uint16_t e_shnum;<  // section header table 条目数量
  uint16_t e_shstrndx;  // 含有 section 名称的条目索引
}; 
 
struct Proghdr {  // program header table 程序头表
  uint32_t p_type;  // program header 类型
  uint32_t p_offset;  // 相对于文件的偏移地址
  uint32_t p_va;< // 虚拟地址
  uint32_t p_pa;< // 物理地址
  uint32_t p_filesz;  // 在文件中的大小
  uint32_t p_memsz; // 在内存中的大小
  uint32_t p_flags; // 相关的标志
  uint32_t p_align; // 对齐方式
};

*/


struct elfhdr {
  uint magic;  // must equal ELF_MAGIC
  uchar elf[12];
  ushort type;
  ushort machine;
  uint version;
  uint entry;
  uint phoff;
  uint shoff;
  uint flags;
  ushort ehsize;
  ushort phentsize;
  ushort phnum;
  ushort shentsize;
  ushort shnum;
  ushort shstrndx;
};

// Program section header
struct proghdr {
  uint type;
  uint off;
  uint vaddr;
  uint paddr;
  uint filesz;
  uint memsz;
  uint flags;
  uint align;
};

// Values for Proghdr type
#define ELF_PROG_LOAD           1

// Flag bits for Proghdr flags
#define ELF_PROG_FLAG_EXEC      1
#define ELF_PROG_FLAG_WRITE     2
#define ELF_PROG_FLAG_READ      4
