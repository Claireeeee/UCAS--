//
// File-system system calls.
// Mostly argument checking, since we don't trust
// user code, and calls into file.c and fs.c.
//

#include "types.h"
#include "defs.h"
#include "param.h"
#include "stat.h"
#include "mmu.h"
#include "proc.h"
#include "fs.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "file.h"
#include "fcntl.h"

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)        //在第n个参数的地方取出文件描述符fd和file结构
{
  int fd;
  struct file *f;

  if(argint(n, &fd) < 0)
    return -1;
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    return -1;
  if(pfd)
    *pfd = fd;
  if(pf)
    *pf = f;
  return 0;
}

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
  int fd;
  struct proc *curproc = myproc();

  for(fd = 0; fd < NOFILE; fd++){           //找到一个空的ofile项，放入f，返回索引fd（就是那些0，1文件描述符）
    if(curproc->ofile[fd] == 0){
      curproc->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
}

int
sys_dup(void)             //包括以下的sys，都是针对文件的
{
  struct file *f;
  int fd;

  if(argfd(0, 0, &f) < 0)
    return -1;
  if((fd=fdalloc(f)) < 0)
    return -1;
  filedup(f);
  return fd;
}

int
sys_read(void)
{
  struct file *f;
  int n;
  char *p;

  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
    return -1;
  return fileread(f, p, n);
}

int
sys_write(void)
{
  struct file *f;
  int n;
  char *p;

  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
    return -1;
  return filewrite(f, p, n);
}

int
sys_close(void)
{
  int fd;
  struct file *f;

  if(argfd(0, &fd, &f) < 0)
    return -1;
  myproc()->ofile[fd] = 0;
  fileclose(f);
  return 0;
}

int
sys_fstat(void)
{
  struct file *f;
  struct stat *st;

  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)    
                                                //在参数中取出file和st指针，下一步修改
    return -1;
  return filestat(f, st);
}

// Create the path new as a link to the same inode as old.     加路径path（参数是新旧两个path）
int
sys_link(void)
{
  char name[DIRSIZ], *new, *old;
  struct inode *dp, *ip;

  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)    //取出syscall的第0和1个参数，放到old和new，应该是新旧路径
    return -1;

  begin_op();          //每次FS syscall之前要用的，检查一下log区是不是在commting
  if((ip = namei(old)) == 0){ 
                  //old对应的ip   namei（用到dirlookup，用到iget，会放到icache，）会加ref，最后记得iput
    end_op();
    return -1;
  }

  ilock(ip);                 //用锁，防止路径覆盖吧，这是在修改一个共享文件的信息
  if(ip->type == T_DIR){     //如果ip是一个目录（目录不能加link）
    iunlockput(ip);
    end_op();
    return -1;
  }

  ip->nlink++;     //加个link数，update
  iupdate(ip);
  iunlock(ip);

  if((dp = nameiparent(new, name)) == 0)      //取出new的上层目录
    goto bad;
  ilock(dp);
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){    //在new上层目录上加一个entry，指向old
    iunlockput(dp);
    goto bad;
  }
  iunlockput(dp);
  iput(ip);             //用完了一个inode一定要put掉

  end_op();

  return 0;

bad:
  ilock(ip);
  ip->nlink--;
  iupdate(ip);
  iunlockput(ip);
  end_op();
  return -1;
}

// Is the directory dp empty except for "." and ".." ?
static int
isdirempty(struct inode *dp)
{
  int off;
  struct dirent de;

  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
      panic("isdirempty: readi");
    if(de.inum != 0)
      return 0;
  }
  return 1;         //空就返回1
}

//PAGEBREAK!
int
sys_unlink(void)
{
  struct inode *ip, *dp;
  struct dirent de;
  char name[DIRSIZ], *path;
  uint off;

  if(argstr(0, &path) < 0)
  //取出参数（文件路径）（这个路径是命令参数，发布命令时自然会把要处理的ionde放到路径的最后，跟实际的文件系统无关）
    return -1;

  begin_op();
  if((dp = nameiparent(path, name)) == 0){       //上层目录（通过剪断上层目录来unlink）
    end_op();
    return -1;
  }

  ilock(dp);

  // Cannot unlink "." or "..".
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    goto bad;

  if((ip = dirlookup(dp, name, &off)) == 0)      //找到要unlink的inode
    goto bad;
  ilock(ip);

  if(ip->nlink < 1)                 //至少得有一个link才能放吧……你本来就没link要我怎么放……
    panic("unlink: nlink < 1");
  if(ip->type == T_DIR && !isdirempty(ip)){        //是空目录且不空，不能放
    iunlockput(ip);
    goto bad;
  }

  memset(&de, 0, sizeof(de));       //清零一个de
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
                                   //清零要释放的inode的dir entry，前面的off都记好了
    panic("unlink: writei");
  if(ip->type == T_DIR){     //如果ip是一个目录
    dp->nlink--;             //因为ip中有一个..是指向上层目录的link，现在没有了，要--
    iupdate(dp);
  }
  iunlockput(dp);

  ip->nlink--;
  iupdate(ip);
  iunlockput(ip);

  end_op();

  return 0;

bad:
  iunlockput(dp);
  end_op();
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor) 
      //也是加路径，参数是目的路径和inode信息，主要用于在inode块开一个新的inode
      //返回一个连好的lock的inode
      //（命令中会把要link的文件名放到path后，就像你自己用mkdir加路径参数时一样
{
  uint off;
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)       //上层目录，name记录最后的文件名
    return 0;
  ilock(dp);                    //上层目录加个锁

  if((ip = dirlookup(dp, name, &off)) != 0){       //检查同名文件是否存在（在路径中和在dir inode中是不一样的）
/*如果的确存在，create的行为就由它服务的系统调用所决定
* open（type==T_FILE）调用的 create ，按指定文件名找到的是一个普通文件：认为打开成功， create 中也认为是成功。
* 在其他情况下，这是一个错误*/          //哪里有这种分支？

       iunlockput(dp);
    ilock(ip);                     //可能只是为了加载一下ip，状态不会变
    if(type == T_FILE && ip->type == T_FILE)       //ip已经是一个文件
      return ip;
    iunlockput(ip);
    return 0;
  }

  if((ip = ialloc(dp->dev, type)) == 0)      //在inode块开一个inode，得到inum
    panic("create: ialloc");

  ilock(ip);              //共享文件，修改的时候维护
  ip->major = major;
  ip->minor = minor;
  ip->nlink = 1;
  iupdate(ip);

  if(type == T_DIR){  //如果是一个目录
    dp->nlink++;      // for ".."
    iupdate(dp);
    // No ip->nlink++ for ".": avoid cyclic ref count.
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0) 
                                              //往ip中添加当前目录和上层目录entry
      panic("create dots");
  }

  if(dirlink(dp, name, ip->inum) < 0)         //最后把ip加到dp（目录）中
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}


//使用 create能轻易地实现 sys_open sys_mkdir sys_mknod

int
sys_open(void)              //从path中找到或加载一个inode，包装成文件，放到ofile里
{
  char *path;
  int fd, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)   //读参数。path和，mode
    return -1;

  begin_op();

  if(omode & O_CREATE)                //如果需要create
  {
    ip = create(path, T_FILE, 0, 0);   //命令的path中放好名字了
    if(ip == 0){
      end_op();
      return -1;
    }
  } 
  else                    //如果已经存在
  {
    if((ip = namei(path)) == 0)
    {          //ip是不是在path那里
      end_op();
      return -1;
    }
    ilock(ip);         //也是为了加载一下
    if(ip->type == T_DIR && omode != O_RDONLY){ 
                              //如果是dir，检查一下是不是rdonly mode（一般进程不能随便修改目录的意思？）
      iunlockput(ip);
      end_op();
      return -1;
    }
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0)     //开一个文件结构包装起来，放入myproc的ofile
  {
    if(f)
      fileclose(f);
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
  end_op();

  f->type = FD_INODE;                   //填充file信息
  f->ip = ip;
  f->off = 0;
  f->readable = !(omode & O_WRONLY);
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
  return fd;
}

int
sys_mkdir(void)          //新增一个目录
{
  char *path;
  struct inode *ip;

  begin_op();
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){          //取path，create一个dir
    end_op();
    return -1;
  }
  iunlockput(ip);
  end_op();
  return 0;
}

int
sys_mknod(void)             //新增一个设备文件
{
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
  if((argstr(0, &path)) < 0 ||           //取参数，存放路径，major，minor
     argint(1, &major) < 0 ||
     argint(2, &minor) < 0 ||
     (ip = create(path, T_DEV, major, minor)) == 0){  //create一个设备inode，命名并链接
    end_op();
    return -1;
  }
  iunlockput(ip);
  end_op();
  return 0;
}

int
sys_chdir(void)               //改变当前目录
{
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();
  
  begin_op();
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){           //读参数
    end_op();
    return -1;
  }
  ilock(ip);  
  if(ip->type != T_DIR){              //如果不是一个目录，报错
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
  iput(curproc->cwd);             //iput当前目录inode
  end_op();
  curproc->cwd = ip;               //转换
  return 0;
}

int
sys_exec(void)          //包装好的系统调用exec
{
  char *path, *argv[MAXARG];    //path和字符串指针数组
  int i;
  uint uargv, uarg;            //好像是记录字符串参数基址和当前参数的？

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){     //path放好，字符串参数开始地址放好
    return -1;
  }
  memset(argv, 0, sizeof(argv));  //argv数组先清零
  for(i=0;; i++)
  {         //一个int一个int的取参数
    if(i >= NELEM(argv))        //参数数量
      return -1;
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)  //取出参数放入uarg（是一个字符串地址）
      return -1;
    if(uarg == 0)
    {
      argv[i] = 0;
      break;
    } 
    if(fetchstr(uarg, &argv[i]) < 0)   //验证地址
      return -1;
  }
  return exec(path, argv);   //取好path和argv后开始exec
}

int
sys_pipe(void)
{
  int *fd;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)            //取第0个参数：fd数组的指针
    return -1;
  if(pipealloc(&rf, &wf) < 0)          //建一个管道，连到两个文件上
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){     //为两个端口分配描述符
    if(fd0 >= 0)
      myproc()->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  fd[0] = fd0;          //放入fd数组。以后这就是管道的两个端口的描述符了
  fd[1] = fd1;
  return 0;
}
