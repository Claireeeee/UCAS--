// Simple grep.  Only supports ^ . * $ operators.

#include "types.h"
#include "stat.h"
#include "user.h"

char buf[1024];
int match(char*, char*);      //从一些文件中搜索字符串‘pattern’，并输出所在的行

void
grep(char *pattern, int fd)        //在fd的文件中搜索字符串‘pattern’，并输出所在的行
{
  int n, m;
  char *p, *q;

  m = 0;
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0)    //循环使用一个buf，用完及时清理
  {                                                 //前面声明的空buf
    m += n;
    buf[m] = '\0';
    p = buf;
    while((q = strchr(p, '\n')) != 0)        //以每个\n间隔循环
    {      //一个一个的取得buf中每个\n的地址，换成0
      *q = 0;
      if(match(pattern, p)){              //以p为起始寻找pattern，修改p到pattern其实地址，或者直到最后。找到返回1
        *q = '\n';                      //如果找到，把当初的最后一个\n换回来
        write(1, p, q+1 - p);           //输出，从p开始，到q

      }
      p = q+1;                    //p移到\n后面
    }
    if(p == buf)
      m = 0;
    if(m > 0){
      m -= p - buf;         //下次加载后起始点m，修改为最后一个\n后的p
      memmove(buf, p, m);    //把这次留下的p后的m个数据移到buf的起始
    }
  }
}

int
main(int argc, char *argv[])
{
  int fd, i;
  char *pattern;

  if(argc <= 1){
    printf(2, "usage: grep pattern [file ...]\n");
    exit();
  }
  pattern = argv[1];                  //  pattern = 从main收到参数中找

  if(argc <= 2){                //如果只有pattern参数，直接从标准输入中找
    grep(pattern, 0);
    exit();
  }

  for(i = 2; i < argc; i++){         //挨个查找参数中提到的fd
    if((fd = open(argv[i], 0)) < 0){
      printf(1, "grep: cannot open %s\n", argv[i]);
      exit();
    }
    grep(pattern, fd);
    close(fd);
  }
  exit();
}

// Regexp matcher from Kernighan & Pike,
// The Practice of Programming, Chapter 9.

int matchhere(char*, char*);
int matchstar(int, char*, char*);

int
match(char *re, char *text)
{
  if(re[0] == '^')                  //^直接跳过（开始标志）
    return matchhere(re+1, text);         
  do
  {  // must look at empty string
    if(matchhere(re, text))              
      return 1;
  }while(*text++ != '\0');       //每次后移一位，循环到结束（或者中间对比成功，直接return）
  return 0;
}

// matchhere:                                    search for re at beginning of text
int matchhere(char *re, char *text)
{
  if(re[0] == '\0')               //re对比结束
    return 1;
  if(re[1] == '*')                 //处理*
    return matchstar(re[0], re+2, text);
  if(re[0] == '$' && re[1] == '\0')          //处理$（结尾标志），当前位置放一个\0，输出的时候到这里结束，不会全行输出
    return *text == '\0';
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))    //re当前位对比通过，进入下一位
    return matchhere(re+1, text+1);
  return 0;                             //re当前位对比不通过
}

// matchstar:                                      search for c*re at beginning of text
int matchstar(int c, char *re, char *text)
{
  do{  // a * matches zero or more instances
    if(matchhere(re, text))
      return 1;
  }while(*text!='\0' && (*text++==c || c=='.'));
  return 0;
}

