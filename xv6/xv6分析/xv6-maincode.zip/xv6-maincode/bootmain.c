// Boot loader.
//
// Part of the boot block, along with bootasm.S, which calls bootmain().
// bootasm.S has put the processor into protected 32-bit mode.
// bootmain() loads an ELF kernel image from the disk starting at
// sector 1 and then jumps to the kernel entry routine.

//从磁盘中读取内核扇区的内容，并写到规定好的内存地址 paddr 处  然后从entry执行

#include "types.h"
#include "elf.h"
#include "x86.h"
#include "memlayout.h"

#define SECTSIZE  512

void readseg(uchar*, uint, uint);   //磁盘读取函数

void
bootmain(void)
{
  struct elfhdr *elf;
  struct proghdr *ph, *eph;
  void (*entry)(void);       //内核入口地址
  uchar* pa;

  elf = (struct elfhdr*)0x10000;  // 分一个内存地址用于存放从磁盘读过来的文件头  kernel.ld指明了内核的paddr是0x00100000

  // Read 1st page off disk
  readseg((uchar*)elf, 4096, 0);  //1扇区是内核磁盘地址（函数内部会把0改为1扇区）。读取elf文件头，文件头指明了elf的文件结构和各部分的地址

  // Is this an ELF executable?
  if(elf->magic != ELF_MAGIC)     //魔数
    return;  // let bootasm.S handle error

  // Load each program segment (ignores ph flags).    //加载程序段到内存
  ph = (struct proghdr*)((uchar*)elf + elf->phoff);
  eph = ph + elf->phnum;       //程序头表地址+条目数量（*条目大小）
  for(; ph < eph; ph++){
    pa = (uchar*)ph->paddr;      //读出程序自己规定某一段的虚拟地址pa
    readseg(pa, ph->filesz, ph->off);  //从磁盘扇区把数据加载到读到pa   这里都是直接映射
    if(ph->memsz > ph->filesz)         //如果规定的内存大小比文件大
      stosb(pa + ph->filesz, 0, ph->memsz - ph->filesz);   //就用0补齐
  }

  // Call the entry point from the ELF header.
  // Does not return!
  //elf中entry文件指明程序段的入口地址
  entry = (void(*)(void))(elf->entry);
  entry();                   //生成的汇编中好像是先解析了地址，然后call了
}

void
waitdisk(void)
{
  // Wait for disk ready.  在 waitdisk 函数中，while 条件所代表的意义为读取驱动器状态，
  //利用逻辑 AND 取出第 6、7 位，并与 0x40（01000000） 比较，若相等则代表驱动器准备好
  while((inb(0x1F7) & 0xC0) != 0x40)     //0x1F7是驱动器端口吧，in读一个字节并返回。如果不等于，就一直循环，直到准备好
    ;
}

// Read a single sector at offset into dst.
void
readsect(void *dst, uint offset)   //读一个扇区到dst
{
  // Issue command.
  

  //第 76 行，由于每次只读取 1 个扇区，所以向扇区数寄存器写入 1
  //第 77 、78、79 行，写入扇区号、柱面号信息，注意每个函数写入的大小为 1byte
  //第 80 行，注意 0xE0 = 11100000，代表主驱动器，LBA 寻址方式
  //第 81 行，向命令寄存器写入读取扇区的命令
  waitdisk();
  outb(0x1F2, 1);   // count = 1
  outb(0x1F3, offset);
  outb(0x1F4, offset >> 8);
  outb(0x1F5, offset >> 16);
  outb(0x1F6, (offset >> 24) | 0xE0);
  outb(0x1F7, 0x20);  // cmd 0x20 - read sectors

  // Read data.
  //读取扇区
  waitdisk();
  insl(0x1F0, dst, SECTSIZE/4);    //0x1F0处是扇区基址，读到dst，读512/4次（每次4个字节）
}

// Read 'count' bytes at 'offset' from kernel into physical address 'pa'. 
// Might copy more than asked.
void
readseg(uchar* pa, uint count, uint offset)
{
  uchar* epa;

  epa = pa + count;

  // Round down to sector boundary.
  pa -= offset % SECTSIZE;

  // Translate from bytes to sectors; kernel starts at sector 1.
  //以扇区为单位度读
  offset = (offset / SECTSIZE) + 1;  

  // If this is too slow, we could read lots of sectors at a time.
  // We'd write more to memory than asked, but it doesn't matter --
  // we load in increasing order.
  for(; pa < epa; pa += SECTSIZE, offset++)
    readsect(pa, offset);   
}
