// init: The initial user-level program

#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
//init 进程，由0进程创建（由initcode创建exec加载），完成系统的初始化. 是系统中所有其它用户进程的祖先进程

//工作：初始化启动shell+不断回收僵尸进程
//init会在需要的情况下创建一个新的控制台设备文件，然后把它作为描述符0，1，2打开。
//接下来它将不断循环，开启控制台 shell，处理没有父进程的僵尸进程，直到 shell 退出，然后再反复。
//shell开启，接收命令，系统就这样运行起来了

char *argv[] = { "sh", 0 };

int
main(void)
{
  int pid, wpid;

  if(open("console", O_RDWR) < 0){
    mknod("console", 1, 1);  //创建设备文件（如果没有的话），代表控制台（这里就是指shell吧）
    open("console", O_RDWR); 
  }
  dup(0);  // stdout  继续给这个设备开两个描述符用于输出和错误输出(这三个标准IO就是init打开的，一般会一直开着)
  //dup用来复制oldfd所指的文件描述符。但复制成功时返回最小的（索引值最小）尚未被使用的文件描述符(文件描述符就是文件描述符表的索引值)
  //若有错误则返回－1，错误代码存入errno中。返回的新文件描述符和参数oldfd指向同一个文件，共享所有的锁定，读写指针，和各项权限或标志位
  dup(0);  // stderr

  for(;;)   //这个for在什么时候（正常）退出呢？
  {
    printf(1, "init: starting sh\n");   
    pid = fork();  //为了配合exec开shell
    if(pid < 0){
      printf(1, "init: fork failed\n");
      exit();
    }
    if(pid == 0){   //子进程中的分支，进到这个分支，说明scheduler转换了子进程，这时候cpu的proc就是子进程的proc地址了
      exec("sh", argv);  //在子进程里开一个shell（init开的），进去运行（main是接口）。
      //shell是一个进程，它接收命令，不断的打开其他的进程，系统就这样运行起来了

      printf(1, "init: exec sh failed\n");  //exec不用返回的，一旦返回，就是failed了
      exit();
    }
    while((wpid=wait()) >= 0 && wpid != pid) 
    //父进程分支，wait负责释放子进程，如果wait返回的pid不是子进程，子进程成为一个僵尸进程，报错，继续wait，直到wait返回-1（没有子进程了）或成功关闭
    //可是这个pid只是32行开的pid
    //如果32行总是放在最后关的话（没有exit，wait就不回碰它）（shell进程会一直开着吗？），就可以实现其他孤儿的关闭了吧
      printf(1, "zombie!\n");
  }
}
