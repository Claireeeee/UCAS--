#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "spinlock.h"

struct {
  struct spinlock lock;      //结构里有自己的lock
  struct proc proc[NPROC];
} ptable;                  

static struct proc *initproc;

int nextpid = 1;     //从启动时开始计数，用于分配pid（在allocproc里，即每次启动新进程时分配）  应该是每个cpu一个nextpid
extern void forkret(void);
extern void trapret(void);  //是个汇编函数

static void wakeup1(void *chan);

void
pinit(void)
{
  initlock(&ptable.lock, "ptable");     //初始化ptable lock
}

// Must be called with interrupts disabled
int
cpuid() {
  return mycpu()-cpus;
}

// Must be called with interrupts disabled to avoid the caller being
// rescheduled between reading lapicid and running through the loop.
struct cpu*
mycpu(void)
{
  int apicid, i;
  
  if(readeflags()&FL_IF)
    panic("mycpu called with interrupts enabled\n");
  
  apicid = lapicid();
  // APIC IDs are not guaranteed to be contiguous. Maybe we should have
  // a reverse map, or reserve a register to store &cpus[i].
  for (i = 0; i < ncpu; ++i) {
    if (cpus[i].apicid == apicid)
      return &cpus[i];
  }
  panic("unknown apicid\n");
}

// Disable interrupts so that we are not rescheduled
// while reading proc from the cpu structure
struct proc*
myproc(void) {
  struct cpu *c;
  struct proc *p;
  pushcli();       
  c = mycpu();
  p = c->proc;
  popcli();
  return p;
}

//PAGEBREAK: 32
//遍历进程表找到一个空的进程结构，设置状态，设置好内核栈结构（仅分配地址，未填充）：trap frame，trapret，context，forkret。返回找到的进程结构序号
//这个空proc数组是什么时候分配的？前面的函数吗？
//创建进程就是：创建进程数据结构，初始化，栈填充，设其状态为RUNNABLE，等待进入scheduler()
// If found, change state to EMBRYO and initialize
// state required to run in the kernel.
// Otherwise return 0.
static struct proc*
allocproc(void)      //userinit 仅仅在创建第一个进程时被调用,allocproc创建每个进程时都会被调用。
{
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);  //acquire一个锁，一定会获得，不然就一直循环不返回

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)    //遍历进程结构表找一个空表
    if(p->state == UNUSED)          //因为不是一步就get的，如果没有锁，这句后就有可能被修改
      goto found;
  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;   //nextpid是一个cpu一个的吧？

  release(&ptable.lock);          //能不能在修改状态之前放？因为状态是用指针修改的呀，没有用ptable

  // Allocate kernel stack.   每个进程都有对应的内核栈，记录 在proc中，构建如下
  if((p->kstack = kalloc()) == 0){  //分配空间
    p->state = UNUSED;
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;  //内核栈顶

  // Leave room for trap frame.   //填充内核栈：放trapframe
  sp -= sizeof *p->tf;
  p->tf = (struct trapframe*)sp;
  
  // Set up new context to start executing at forkret,  //放trapret
  // which returns to trapret.
  sp -= 4;
  *(uint*)sp = (uint)trapret;  //一个汇编函数，跳出trap，为恢复原进程做准备吧
  //但是这里的赋值语句怎么理解？赋的函数地址？

  sp -= sizeof *p->context;    //放进程上下文
  p->context = (struct context*)sp;
  memset(p->context, 0, sizeof *p->context);//初始化置零
  p->context->eip = (uint)forkret;   //放forkret。也是一个汇编函数，fork return

  return p;
}

//PAGEBREAK: 32
// Set up first user process.
void
userinit(void)
{
  struct proc *p;
  extern char _binary_initcode_start[], _binary_initcode_size[]; //initcode的地址，好像是编译链接的时候定义的

  p = allocproc();  //得到一个初始化好的进程结构

  //下面开始填充内核栈（各自的地址已由allocproc划分好）
  //普通进程的栈由谁填充呢？fork会直接复制父进程内存，exec构建新页表，分配内存加载新文件
  initproc = p;
  if((p->pgdir = setupkvm()) == 0)  //内核部分页表
    panic("userinit: out of memory?");
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);  
  //Load the initcode into address 0 of pgdir:分配内存，建立页表映射（到0），加载到物理内存
  p->sz = PGSIZE;
  memset(p->tf, 0, sizeof(*p->tf));          //清空tf
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;   //设置trapframe
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
  p->tf->es = p->tf->ds;
  p->tf->ss = p->tf->ds;
  p->tf->eflags = FL_IF;
  p->tf->esp = PGSIZE;
  p->tf->eip = 0;  // beginning of initcode.S
  //trapframe里的eip正是从内核退出进入用户态（每次建立新进程都要进入内核态再退出）之后执行的程序的入口（这里是initcode.S）
  //init进程跟普通进程的差别就在这里了:
  //init进程设置的eip=0(0这里已经放置了initcode.S),而普通进程这里设置的是elf->entry,即程序的main()函数

  safestrcpy(p->name, "initcode", sizeof(p->name));  //进程名
  p->cwd = namei("/");

  // this assignment to p->state lets other cores
  // run this process. the acquire forces the above
  // writes to be visible, and the lock is also needed
  // because the assignment might not be atomic.
  acquire(&ptable.lock);
  p->state = RUNNABLE;   
  //没涉及共享数据，但这一句有4步汇编，是为了保证原子操作吧（这4步逻辑上是要实现一个原子操作的），而且状态是和其他进程有交互的，保证原子很重要
  release(&ptable.lock);
}

// Grow current process's memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  uint sz;
  struct proc *curproc = myproc();

  sz = curproc->sz;
  if(n > 0){
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  } else if(n < 0){
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
      return -1;
  }
  curproc->sz = sz;
  switchuvm(curproc);
  return 0;
}

// Create a new process copying p as the parent.
// Sets up stack to return as if from system call.
// Caller must set state of returned proc to RUNNABLE.
//就是分个新进程，各域都copy一下，状态该改改一下，调一下tf的eax（为了在子进程pid返回0）
int
fork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *curproc = myproc();  //cpu当前的进程

  // Allocate process.
  if((np = allocproc()) == 0){     //分配进程结构，设置状态，分配内核栈
    return -1;
  }

  // Copy process state from proc.
  //copyuvm：Given a parent process's page table, create a copy of it for a child.
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
    kfree(np->kstack);
    np->kstack = 0;
    np->state = UNUSED;
    return -1;
  }
  //全都继承过来
  np->sz = curproc->sz;
  np->parent = curproc;
  *np->tf = *curproc->tf;

  //Clear %eax so that fork returns 0 in the child.  ？？？为什么这样就可以实现
  np->tf->eax = 0;


  //继承文件
  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);
  //name
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));

  //pid是自己的
  pid = np->pid;

  acquire(&ptable.lock);  //修改状态要先拿一个ptable锁

  np->state = RUNNABLE;

  release(&ptable.lock);

  return pid;
}

// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait() to find out it exited.
void
exit(void)
{
  struct proc *curproc = myproc();
  struct proc *p;
  int fd;

  if(curproc == initproc)
    panic("init exiting");

                                        // Close all open files.
  for(fd = 0; fd < NOFILE; fd++){
    if(curproc->ofile[fd]){
      fileclose(curproc->ofile[fd]);
      curproc->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(curproc->cwd);              //释放当前目录
  end_op();
  curproc->cwd = 0;

  acquire(&ptable.lock);

                                    // Parent might be sleeping in wait().
  wakeup1(curproc->parent);

                                    // Pass abandoned children to init.
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->parent == curproc)
    {
      p->parent = initproc;
      if(p->state == ZOMBIE)
        wakeup1(initproc);
    }
  }

                                    // Jump into the scheduler, never to return.
  curproc->state = ZOMBIE;
  sched();
  panic("zombie exit");
}
  
// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.   
int
wait(void)
{
  struct proc *p;
  int havekids, pid;
  struct proc *curproc = myproc();
  
  acquire(&ptable.lock);
  for(;;)
  {
    // Scan through table looking for exited children.
    havekids = 0;
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    {
      if(p->parent != curproc)
        continue;
      havekids = 1;
      if(p->state == ZOMBIE){
        // Found one.
        pid = p->pid;
        kfree(p->kstack);
        p->kstack = 0;
        freevm(p->pgdir);
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->state = UNUSED;
        release(&ptable.lock);
        return pid;
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || curproc->killed){
      release(&ptable.lock);
      return -1;
    }

    // Wait for children to exit.  (See wakeup1 call in proc_exit.)
    sleep(curproc, &ptable.lock);  //DOC: wait-sleep
  }
}

//PAGEBREAK: 42
// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run
//  - swtch to start running that process
//  - eventually that process transfers control
//      via swtch back to the scheduler.
void
scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();
  c->proc = 0;
  
  for(;;)
  {
    // Enable interrupts on this processor.
    sti();

    // Loop over process table looking for process to run.
    //这一过程一直重复下去，直至收到暂停指令或循环等待指令
    acquire(&ptable.lock);
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    {
      if(p->state != RUNNABLE)
        continue;

      // Switch to chosen process.  It is the process's job
      // to release ptable.lock and then reacquire it
      // before jumping back to us.
      c->proc = p;  //记录当前CPU正在执行的进程
      switchuvm(p); // Switch TSS and h/w page table to correspond to process p.  

      //设置TSS段(xv6是每个cpu一个TSS)，其中的ss0设置为SEG_KDATA，esp0设置成p->kstack+KSTACKSIZE，也就是该进程内核栈的栈底，
      //然后ltr(SEG_TSS<<3)，这会让CPU在执行iret时使用该TSS的内容。（tr更新tss段基址）
      //即，该进程以后被中断或者trap时，无论什么情况，只要进入kernel就使用TSS指定的这个stack，也就是说告诉进程它的返程路线是什么
      
      p->state = RUNNING;
      
      swtch(&(c->scheduler), p->context); //context switch
      
      //进入forkret函数中
      //forkret()启动了一个log之后返回，接下来在栈中的是trapret()的地址，于是返回到trapret()继续执行
      //trapret，从内核栈返回：tf中存好的eip弹出（userinit中设置的：p->tf->eip = 0; // beginning of initcode.S）

      //一个进程完成之后，或者时钟中断中，从yield调用swtch回到这里回到这里。cr3加载回最初的只有内核映射的页表
      switchkvm(); // Switch h/w page table register to the kernel-only page table
                    // for when no process is running.

      // Process is done running for now.
      // It should have changed its p->state before coming back.
      c->proc = 0;
    }    //仅仅是从这个循环中出来，p是接着往后走的，所以yield释放的p会被放到下一轮，确实是轮转
    release(&ptable.lock);

  }
}

// Enter scheduler.  Must hold only ptable.lock and have changed proc->state. 
// Saves and restores intena because intena is a property of this kernel thread, not this CPU. 
// It should be proc->intena and proc->ncli, but that would break in the few places where a lock is held but
// there's no process.
void
sched(void)               //进入scheduler
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&ptable.lock))
    panic("sched ptable.lock");
  if(mycpu()->ncli != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched running");
  if(readeflags()&FL_IF)
    panic("sched interruptible");
  intena = mycpu()->intena;                 //记录下当前的intena  （Were interrupts enabled）
  swtch(&p->context, mycpu()->scheduler);           
  mycpu()->intena = intena;                  //为什么要这样暂时存一下？然后再换回来？
}

// Give up the CPU for one scheduling round.          
void
yield(void)
{
  acquire(&ptable.lock);  //DOC: yieldlock
  myproc()->state = RUNNABLE;      //放弃一下当前进程的running
  sched();                         //转到scheduler
  release(&ptable.lock);
}

// A fork child's very first scheduling by scheduler()  //每次fork都会进
// will swtch here.  "Return" to user space.   //返回到用户空间
void
forkret(void)
{
  static int first = 1;    //静态变量  在整个os运行过程中，只在启动的时候初始化一次
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);  //释放锁

  if (first) {
    // Some initialization functions must be run in the context 
    //一些初始化函数必须在用户进程（regular process？）的上下文中进行（比如sleep函数）
    // of a regular process (e.g., they call sleep), and thus cannot
    // be run from main().         //main不是regular process？
    first = 0;
    iinit(ROOTDEV);          //没有看懂这两个函数
    initlog(ROOTDEV);
  }
  // Return to "caller", actually trapret (see allocproc).
}

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)                 
{
  struct proc *p = myproc();
  
  if(p == 0)
    panic("sleep");

  if(lk == 0)                   //修改sleep状态的时候要有锁
    panic("sleep without lk");

  // Must acquire ptable.lock in order to
  // change p->state and then call sched.
  // Once we hold ptable.lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup runs with ptable.lock locked),
  // so it's okay to release lk.
  if(lk != &ptable.lock){  //DOC: sleeplock0            //内部有一次锁的释放与再获取
    acquire(&ptable.lock);  //DOC: sleeplock1
    release(lk);
  }
  // Go to sleep.
  p->chan = chan;                     //设一下chan，改状态
  p->state = SLEEPING;

  sched();                       // Enter scheduler，转一下context，新进程负责ptable锁释放

  // Tidy up.            再次被调用的时候从这接着来
  p->chan = 0;

  // Reacquire original lock.
  if(lk != &ptable.lock){  //DOC: sleeplock2             //再获取
    release(&ptable.lock);
    acquire(lk);
  }
}

//PAGEBREAK!
// Wake up all processes sleeping on chan.
// The ptable lock must be held.
static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if(p->state == SLEEPING && p->chan == chan)
      p->state = RUNNABLE;
}

// Wake up all processes sleeping on chan.             chan？什么叫sleeping on chan？
void
wakeup(void *chan)                
{
  acquire(&ptable.lock);
  wakeup1(chan);
  release(&ptable.lock);
}

// Kill the process with the given pid.
// Process won't exit until it returns to user space (see trap in trap.c).
int
kill(int pid)
{
  struct proc *p;

  acquire(&ptable.lock);
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->pid == pid){
      p->killed = 1;
                                         // Wake process from sleep if necessary.
      if(p->state == SLEEPING)
        p->state = RUNNABLE;
      release(&ptable.lock);
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}

//PAGEBREAK: 36
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [EMBRYO]    "embryo",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  int i;
  struct proc *p;
  char *state;
  uint pc[10];

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    cprintf("%d %s %s", p->pid, state, p->name);
    if(p->state == SLEEPING){
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
  }
}
