#ifndef INCLUDE_FS_H_
#define INCLUDE_FS_H_

#include "type.h"
#include "queue.h"

#define min(a,b) a<b?a:b
#define max(a,b) a>b?a:b

#define O_RD   0x1
#define O_WR   0x2
#define O_RDWR 0x3

#define INODE_SIZE sizeof(inode_t)
#define DENTRY_SIZE sizeof(dentry_t)
#define FD_SIZE sizeof(file_desc_t)

#define SECTOR_SIZE 512
#define FS_BEGIN 0x20000000 //512MB
#define BLOCK_SIZE 0x1000
#define FS_SIZE 0x20000
#define BLOCK_MAP_OFFSET 0x1
#define BLOCK_MAP_SIZE 0x4
#define INODE_MAP_OFFSET 0x5
#define INODE_MAP_SIZE 0x1
#define INODE_OFFSET 0x6
#define INODE_BLOCK_SIZE 0x1
#define DATA_OFFSET 0x7

#define ROOT_BLOCK 0x7
/***
 * SUPER_BLOCK(1 block) BLOCK_MAP(4 blocks) INODE_MAP(1 block) INODE(1 block) DATA(left)
***/

#define DENTRY_NUM_PER_BLOCK 128
#define INODE_NUM_PER_BLOCK 64 
#define POINTER_NUM_PER_BLOCK 1024
#define FD_NUM 16

#define UPALIGN_SECTOR(x) (((x)+SECTOR_SIZE-1) & ~(SECTOR_SIZE-1))
#define SECTORNUM(x) UPALIGN_SECTOR(x)/SECTOR_SIZE
#define UPALIGN_BLOCK(x) (((x)+BLOCK_SIZE-1) & ~(BLOCK_SIZE-1))
#define BLOCKNUM(x) UPALIGN_BLOCK(x)/BLOCK_SIZE

extern char cur_dir[100];

#define MAGIC 0x10101010

typedef struct Super_Block{
    uint32_t spare;
    uint32_t magic;
    uint32_t block_size;
    uint32_t fs_begin;
    uint32_t fs_size;//uint of block
    uint32_t block_map_size;
    uint32_t inode_map_begin;
    uint32_t inode_map_size;
    uint32_t inode_begin;
    uint32_t inode_size;
    uint32_t data_begin;
    uint32_t data_size;
    uint32_t junk[1024-12];
}super_block_t;

typedef struct Inode{
    uint32_t mode;//0 for free, 1 for file, 2 for dir
    uint32_t owner_info;
    uint32_t file_size;
    uint32_t direct_pointer[9];
    uint32_t one_level_pointer;
    uint32_t two_level_pointer;
    uint32_t three_level_pointer;
    uint32_t hard_link;
}inode_t;

typedef struct Dentry{
    uint32_t mode;//0 for free, 1 for file and 2 for dir
    uint32_t ino;
    char name[16];
    inode_t *hard_link[2];
}dentry_t;

typedef struct File_Desc{
    uint32_t spare;
    uint32_t access;
    uint32_t ino;
    uint32_t seek_pos_r;
    uint32_t seek_pos_w; 
}file_desc_t;


void mkfs(void);
void statfs(void);
void cd(char *);
void mkdir(char *);
void rmdir(char *);
void ls(void);
void touch(char *);
void cat(char *);
int open(char*, int);
int read(int, char *, int);
int write(int, char *, int);
void close(int);

#endif