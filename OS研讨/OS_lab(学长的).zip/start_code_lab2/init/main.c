/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *            Copyright (C) 2018 Institute of Computing Technology, CAS
 *               Author : Han Shukai (email : hanshukai@ict.ac.cn)
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *         The kernel's entry, where most of the initialization work is done.
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this 
 * software and associated documentation files (the "Software"), to deal in the Software 
 * without restriction, including without limitation the rights to use, copy, modify, 
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit 
 * persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE. 
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * */
#include "lock.h"
#include "time.h"
#include "irq.h"
#include "test.h"
#include "stdio.h"
#include "queue.h"
#include "sched.h"
#include "screen.h"
#include "common.h"
#include "syscall.h"

#define STACK_BASE 0xa0f00000
#define STACK_SIZE 0x100000//1MB
#define EBASE 0xbfc00000
#define EBASE_OFFSET 0x380

#ifndef NUM_SYSCALLS
    #define NUM_SYSCALLS 64
#endif


/* ready queue to run */
extern queue_t ready_queue[3];

/* block queue to wait */
extern queue_t block_queue;

uint32_t exception_handler[32];
extern int (*syscall_handler[NUM_SYSCALLS])();

extern void handle_int(void);
extern void handle_syscall(void);
extern void handle_other(void);
extern void close_int(void);
extern void start_int(void);
extern void reset_timer(uint32_t);

static void init_pcb()
{
	pcb_t * p;
	//queue_init(&ready_queue);
	ready_queue_init();
	queue_init(&block_queue);
	queue_init(&sleep_queue);
	current_running = &pcb[0];
	uint32_t default_cp0_status = 0x10008000;

	int i=4;
	for(;i<=10;i++){
		p = &pcb[i];
		
		memset(p,0,sizeof(pcb_t));
		p->kernel_context.regs[31] = (uint32_t ) int_clear_finish;
		p->kernel_context.cp0_epc = myowntask[i]->entry_point;		
		p->kernel_context.regs[29] = p->kernel_stack_top = STACK_BASE + process_id * STACK_SIZE;
		p->kernel_context.cp0_status = default_cp0_status;
		

		p->user_context.regs[31] = p->kernel_context.regs[31];
		p->user_context.cp0_epc = myowntask[i]->entry_point;	
		p->user_context.regs[29] = p->user_stack_top =  p->kernel_context.regs[29];
		p->user_context.cp0_status = default_cp0_status;

		p->pid = i;
		p->type = myowntask[i]->type;
		p->status = TASK_READY;
		p->priority = i%3;
		printk("entry point of %d: 0x%x\n", process_id,p->user_context.regs[31]);
		//printk("Stop point before queue_push in init_pcb\n");		
		//queue_push(&ready_queue, p);
		ready_queue_push(p);
		process_id++;
	}
	
}

static void init_exception_handler()
{
	int i = 0;
	for(;i<32;++i){
		exception_handler[i] = (uint32_t ) handle_other;
	}
	exception_handler[0] = (uint32_t ) handle_int;
	exception_handler[8] = (uint32_t ) handle_syscall;
}

static void init_exception()
{
	// 1. Get CP0_STATUS
	// 2. Disable all interrupt
	// 3. Copy the level 2 exception handling code to 0x80000180
	// 4. reset CP0_COMPARE & CP0_COUNT register
	init_exception_handler();

	bzero(EBASE, EBASE_OFFSET);
	memcpy((uint8_t *) (EBASE+EBASE_OFFSET), (uint8_t *)exception_handler_entry, (uint32_t ) (exception_handler_end - exception_handler_begin));
	//Get CP0_STATUS ??
	uint32_t cp0_status =  get_cp0_status();
	cp0_status |=0x8000;
	set_cp0_status(0x10000000 | cp0_status);
	//2. Disable
	close_int();
	
	//3. Copy
	bzero(0x80000000, 0x180);
	memcpy((uint8_t *) 0x80000180, (uint8_t *)exception_handler_entry, (uint32_t ) (exception_handler_end - exception_handler_begin));
	
	//4. reset CP0_COMPARE and CP0_COUNT
	reset_timer(TIMER_INTERVAL);
	
}

static void init_syscall(void)
{
	// init system call table.
	int i;
	for(i=0;i<NUM_SYSCALLS;i++){
		syscall_handler[i] = (int (*)()) do_sys_others;
	}
	syscall_handler[SYSCALL_SLEEP] = (int (*)()) do_sys_sleep;
	syscall_handler[SYSCALL_BLOCK] = (int (*)()) do_sys_block;
	syscall_handler[SYSCALL_UNBLOCK_ONE] = (int (*)()) do_sys_unblock_one;
	syscall_handler[SYSCALL_UNBLOCK_ALL] = (int (*)()) do_sys_unblock_all;
	syscall_handler[SYSCALL_WRITE] = (int (*)()) do_sys_write;
	//syscall_handle[SYSCALL_READ] = sys_read;
	syscall_handler[SYSCALL_CURSOR] = (int (*)()) do_sys_move_cursor;
	syscall_handler[SYSCALL_REFLUSH] = (int (*)()) do_sys_reflush;
	syscall_handler[SYSCALL_MUTEX_LOCK_INIT] = (int (*)()) do_sys_mutex_lock_init;
	syscall_handler[SYSCALL_MUTEX_LOCK_ACQUIRE] = (int (*)()) do_sys_mutex_lock_acquire;
	syscall_handler[SYSCALL_MUTEX_LOCK_RELEASE] = (int (*)()) do_sys_mutex_lock_release;
}

// jump from bootloader.
// The beginning of everything >_< ~~~~~~~~~~~~~~
void __attribute__((section(".entry_function"))) _start(void)
{
	// Close the cache, no longer refresh the cache 
	// when making the exception vector entry copy
	asm_start();
	
	//memset(new_screen, 0, sizeof(new_screen));
	//time_elapsed = 0;
	//is_init = 0;
	// init interrupt (^_^)
	init_exception();
	printk("> [INIT] Interrupt processing initialization succeeded.\n");

	// init system call table (0_0)
	init_syscall();
	printk("> [INIT] System call initialized successfully.\n");

	// init Process Control Block (-_-!)
	init_pcb();
	printk("> [INIT] PCB initialization succeeded.\n");

	// init screen (QAQ)
	init_screen();
	printk("> [INIT] SCREEN initialization succeeded.\n");

	// TODO Enable interrupt
	//reset_timer(TIMER_INTERVAL);
	start_int();
	//exception_handler_entry();
	//printk("int start\n");
	while (1)
	{
		//printk("Init done\n");
		// (QAQQQQQQQQQQQ)
		// If you do non-preemptive scheduling, you need to use it to surrender control
		//do_scheduler();
		//int k=1;
		//printk("scheduler %d done\n",k++);
	};
	return;
}
