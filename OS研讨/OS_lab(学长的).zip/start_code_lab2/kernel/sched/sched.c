//#include "lock.h"
//#include "time.h"
//#include "stdio.h"
//#include "sched.h"
//#include "queue.h"
//#include "screen.h"
#include "lock.h"
#include "time.h"
#include "stdio.h"
#include "sched.h"
#include "queue.h"
#include "syscall.h"
#include "test2.h"
#include "screen.h"

pcb_t pcb[NUM_MAX_TASK];

/* current running task PCB */
pcb_t *current_running;

/* global process id */
pid_t process_id = 1;

extern int screen_cursor_x;
extern int screen_cursor_y;

extern uint32_t time_elapsed;


static void check_sleeping()
{
    pcb_t *tmp = sleep_queue.head;

    while(tmp != NULL){
        if(tmp->deadline <= time_elapsed){
            tmp->status = TASK_READY;
            //queue_push(&ready_queue, tmp);
            ready_queue_push(tmp);
            tmp = queue_remove(&sleep_queue, tmp);
        }else{
            tmp = tmp->next;
        }
    }
}
//int i=1;
void scheduler(void)
{
    check_sleeping();
    
    //int print_location = 3;
    //vt100_move_cursor(1, print_location);
    //printk("Get into scheduler successfully.(%d)\n",i++);
    // TODO schedule
    current_running->cursor_x = screen_cursor_x;
    current_running->cursor_y = screen_cursor_y;

    if(current_running->status == TASK_BLOCKED){
        //queue_push(&block_queue,current_running);
    }else if(current_running != &pcb[0]){
        priority_down(current_running);
        ready_queue_push(current_running);
        //queue_push(&ready_queue,current_running);
    }
    
    while(ready_queue_is_empty()){
        start_int();
        check_sleeping();//however, while scheduler, no time_irq, so no time_elapsed inc
    }
    close_int();

    current_running = ready_queue_dequeue();
    //current_running = queue_dequeue(&ready_queue);
    current_running->status = TASK_RUNNING;

    screen_cursor_x = current_running->cursor_x;
    screen_cursor_y = current_running->cursor_y;

    //printk("current_running: 0x%x\n",(uint32_t ) current_running->user_context.regs[31]);
    //printk("Scheduler function done\n");
    // Modify the current_running pointer.
}


void do_sleep(uint32_t sleep_time)
{
    // TODO sleep(seconds)
    current_running->status = TASK_BLOCKED;//sleep is regarded as a kind of block
    current_running->deadline = time_elapsed + 10*sleep_time;

    queue_push(&sleep_queue, current_running);
    //epc_add_4();
    //current_running->user_context.cp0_epc += 4;
    do_scheduler();
}

void do_block(queue_t *queue)
{
    current_running->status = TASK_BLOCKED;
    queue_push(queue,current_running);
    // block the current_running task into the queue
}

void do_unblock_one(queue_t *queue)
{
    if(queue_is_empty(queue)==0){
        pcb_t * p = queue_dequeue(queue);
        p->status = TASK_READY;
        ready_queue_push(p);
        //queue_push(&ready_queue,p);
    }
    // unblock the head task from the queue
}

void do_unblock_all(queue_t *queue)
{
    while(queue_is_empty(queue)==0){
        pcb_t * p = queue_dequeue(queue);
        p->status = TASK_READY;
        ready_queue_push(p);
        //queue_push(&ready_queue,p);
    }
    // unblock all task in the queue
}

void ready_queue_push(pcb_t *item){
    queue_push(&ready_queue[item->priority],item);
}

void priority_down(pcb_t *item){
    item->priority = item->priority ?  item->priority-1 : 0;
}

int ready_queue_is_empty(){
    return queue_is_empty(&ready_queue[0]) & queue_is_empty(&ready_queue[1]) & queue_is_empty(&ready_queue[2]);
}

pcb_t *ready_queue_dequeue(){
    if(queue_is_empty(&ready_queue[2])){
        if(queue_is_empty(&ready_queue[1])){
            return queue_dequeue(&ready_queue[0]);
        }
        return queue_dequeue(&ready_queue[1]);
    }
    return queue_dequeue(&ready_queue[2]);
}

void ready_queue_init(){
    int i=0;
    for(;i<3;i++){
        queue_init(&ready_queue[i]);
    }
}