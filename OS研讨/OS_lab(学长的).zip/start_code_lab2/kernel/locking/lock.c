#include "lock.h"
#include "sched.h"
#include "syscall.h"
extern pcb_t *current_running;

void spin_lock_init(spin_lock_t *lock)
{
    lock->status = UNLOCKED;
}

void spin_lock_acquire(spin_lock_t *lock)
{
    while (LOCKED == lock->status)
    {
    };
    lock->status = LOCKED;
}

void spin_lock_release(spin_lock_t *lock)
{
    lock->status = UNLOCKED;
}

void do_mutex_lock_init(mutex_lock_t *lock)
{
    lock->status = UNLOCKED;
}

void do_mutex_lock_acquire(mutex_lock_t *lock)
{
    
    while(lock->status == LOCKED){
        do_block(&block_queue);
        do_scheduler();
    }
    lock->status = LOCKED;
    
/*
    if(lock->status == UNLOCKED){
        lock->status = LOCKED;
    }else{
        do_block(&block_queue);
        //do_scheduler();

        //epc_add_4();
        //current_running->user_context.cp0_epc += 4;
        do_scheduler();
        
    }
*/
}

void do_mutex_lock_release(mutex_lock_t *lock)
{
    
    lock->status = UNLOCKED;
    do_unblock_one(&block_queue);
    
/*
    if(queue_is_empty(&block_queue)){
        lock->status = UNLOCKED;
    }else{
        do_unblock_one(&block_queue);
    }
*/  
}
