void __attribute__((section(".entry_function"))) _start(void)
{
	// Call PMON BIOS printstr to print message "Hello OS!"
	//char str[20] = "I'm Lemover\n"; 
	//((void(*)())0x8007b980)(str);
	((void(*)())0x8007ba00)('A');
	while(1)
		;
	return;
}
