#ifndef INCLUDE_FS_H_
#define INCLUDE_FS_H_

#include "type.h"
#include "queue.h"

#define min(a,b) a<b?a:b
#define max(a,b) a>b?a:b

#define O_RD   0x1
#define O_WR   0x2
#define O_RDWR 0x3

#define INODE_SIZE sizeof(inode_t)
#define DENTRY_SIZE sizeof(dentry_t)
#define FD_SIZE sizeof(file_desc_t)

#define SECTOR_SIZE 512
#define FS_BEGIN 0x20000000 //512MB
#define BLOCK_SIZE 0x1000
#define FS_SIZE 0x20000
#define BLOCK_MAP_OFFSET 0x1
#define BLOCK_MAP_SIZE 0x4
#define INODE_MAP_OFFSET 0x5
#define INODE_MAP_SIZE 0x1
#define INODE_OFFSET 0x6
#define INODE_BLOCK_SIZE 0x1
#define DATA_OFFSET 0x7

#define ROOT_BLOCK 0x7
/***
 * SUPER_BLOCK(1 block) BLOCK_MAP(4 blocks) INODE_MAP(1 block) INODE(1 block) DATA(left)
***/

#define DENTRY_NUM_PER_BLOCK 128
#define INODE_NUM_PER_BLOCK 64 
#define POINTER_NUM_PER_BLOCK 1024
#define FD_NUM 16

#define UPALIGN_SECTOR(x) (((x)+SECTOR_SIZE-1) & ~(SECTOR_SIZE-1))
#define SECTORNUM(x) UPALIGN_SECTOR(x)/SECTOR_SIZE
#define UPALIGN_BLOCK(x) (((x)+BLOCK_SIZE-1) & ~(BLOCK_SIZE-1))
#define BLOCKNUM(x) UPALIGN_BLOCK(x)/BLOCK_SIZE

extern char cur_dir[100];

#define MAGIC 0x10101010

typedef struct Super_Block{
    uint32_t spare;
    uint32_t magic;
    uint32_t block_size;
    uint32_t fs_begin;
    uint32_t fs_size;//uint of block
    uint32_t block_map_size;
    uint32_t inode_map_begin;
    uint32_t inode_map_size;
    uint32_t inode_begin;
    uint32_t inode_size;
    uint32_t data_begin;
    uint32_t data_size;
    uint32_t junk[1024-12];
}super_block_t;

typedef struct Inode{
    uint32_t mode;//0 for free, 1 for file, 2 for dir
    uint32_t owner_info;
    uint32_t file_size;
    uint32_t direct_pointer[9];
    uint32_t one_level_pointer;
    uint32_t two_level_pointer;
    uint32_t three_level_pointer;
    uint32_t hard_link;
}inode_t;

typedef struct Dentry{
    uint32_t mode;//0 for free, 1 for file and 2 for dir
    uint32_t ino;
    char name[16];
    inode_t *hard_link[2];
}dentry_t;

typedef struct File_Desc{
    uint32_t spare;
    uint32_t access;
    uint32_t ino;
    uint32_t seek_pos_r;
    uint32_t seek_pos_w; 
}file_desc_t;

typedef uint16_t Elf32_Half;
typedef uint32_t Elf32_Word;
typedef uint32_t *Elf32_Addr;   
typedef int      Elf32_Sword;
typedef uint32_t Elf32_Off;

#define EI_NIDENT (16)
typedef struct
{
  unsigned char e_ident[EI_NIDENT];   /* Magic number and other info */
  Elf32_Half    e_type;               /* Object file type */
  Elf32_Half    e_machine;            /* Architecture */
  Elf32_Word    e_version;            /* Object file version */
  Elf32_Addr    e_entry;              /* Entry point virtual address */
  Elf32_Off     e_phoff;              /* Program header table file offset */
  Elf32_Off     e_shoff;              /* Section header table file offset */
  Elf32_Word    e_flags;              /* Processor-specific flags */
  Elf32_Half    e_ehsize;             /* ELF header size in bytes */
  Elf32_Half    e_phentsize;          /* Program header table entry size */
  Elf32_Half    e_phnum;              /* Program header table entry count */
  Elf32_Half    e_shentsize;          /* Section header table entry size */
  Elf32_Half    e_shnum;              /* Section header table entry count */
  Elf32_Half    e_shstrndx;           /* Section header string table index */
} Elf32_Ehdr;

typedef struct { 
    Elf32_Word p_type; /* segment type */ 
    Elf32_Off  p_offset; /* segment offset */ 
    Elf32_Addr p_vaddr; /* virtual address of segment */ 
    Elf32_Addr p_paddr; /* physical address - ignored? */ 
    Elf32_Word p_filesz; /* number of bytes in file for seg. */ 
    Elf32_Word p_memsz; /* number of bytes in mem. for seg. */ 
    Elf32_Word p_flags; /* flags */ 
    Elf32_Word p_align; /* memory alignment */ 
} Elf32_Phdr;


void mkfs(char *);
void statfs(void);
void cd(char *);
void mkdir(char *);
void rmdir(char *);
void ls(void);
void touch(char *);
void cat(char *);
int open(char*, int);
int read(int, char *, int);
int write(int, char *, int);
void close(int);
void launch(char *);
#endif