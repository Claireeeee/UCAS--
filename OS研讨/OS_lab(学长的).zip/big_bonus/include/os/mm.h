#ifndef INCLUDE_MM_H_
#define INCLUDE_MM_H_

#include "type.h"
#include "sched.h"


#define TLB_ENTRY_NUMBER 32
#define PTE_ENTRY_NUMBER 0x40000
#define PAGE_FRAME_NUMBER 0x1100
#define PADDR_BASE 0x00f00000
#define PADDR_STOP 0x02000000
#define VADDR_BASE 0x00000000
#define PAGE_FRAME_SIZE  0x1000//1KB

//pte_t 结构：
// 20位物理页号， 6位flag，依次为C(3), D(1), V(1), G(1)

//page number
#define PTXSHIFT 12
#define MYPNUM(va) ((uint32_t)(va) >> PTXSHIFT)
#define PTE_C 0x10
#define PTE_D 0x4
#define PTE_V 0x2
#define PTE_G 0x1


void do_TLB_Refill(uint32_t idx);
void do_page_fault();

void init_page_table();
void init_TLB();
void init_swap();

void init_mem(void );
void free(uint32_t );
char *alloc(void );
void free_range(uint32_t , uint32_t);

extern pte_t pte[3][PTE_ENTRY_NUMBER];

#endif
