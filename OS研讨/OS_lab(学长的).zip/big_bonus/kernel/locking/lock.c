#include "lock.h"
#include "sched.h"
#include "syscall.h"
extern pcb_t *current_running;

void add_queue_to_block(queue_t *queue){
    int i=0;
    while(block_queue[i]!=NULL && i<16) i++;
    if(i==16){
        printkf("add_queue_to_block error: no space in block queue");
        return;
    }
    block_queue[i] = queue;

    //i=0;printkf("\n");
    //while(i<16){
        //printkf("block_queue(%d): 0x%x\n",i,block_queue[i]);
        //i++;
    //}
} 

void spin_lock_init(spin_lock_t *lock)
{
    lock->status = UNLOCKED;
}

void spin_lock_acquire(spin_lock_t *lock)
{
    while (LOCKED == lock->status)
    {
    };
    lock->status = LOCKED;
}

void spin_lock_release(spin_lock_t *lock)
{
    lock->status = UNLOCKED;
}

void do_mutex_lock_init(mutex_lock_t *lock)
{
    add_queue_to_block(&lock->queue);
    queue_init(&lock->queue);
    lock->status = UNLOCKED;
}

void do_mutex_lock_acquire(mutex_lock_t *lock)
{
    
    while(lock->status == LOCKED){
        do_block(&lock->queue);
        do_scheduler();
    }
    lock->status = LOCKED;
    
    int i=0;
    while(current_running->mutex_lock[i] != 0 && i<16) i++;
    if(i<16) current_running->mutex_lock[i] = lock;
    else printkf("mutex_lock in pcb is full 1\n");
    //printkf("\n");
    //for(i=0;i<10;i++) printkf("cur-mutex[%d]: 0x%x\n",i,current_running->mutex_lock[i]);
/*
    if(lock->status == UNLOCKED){
        lock->status = LOCKED;
    }else{
        do_block(&lock->queue);
        do_scheduler();        
    }
*/
}

void do_mutex_lock_release(mutex_lock_t *lock)
{
    
    lock->status = UNLOCKED;
    do_unblock_all(&lock->queue);
    
    //printkf("8\n");
    int i;
    //printkf("\n");
    //for(i=0;i<16;i++) printkf("cur-mutex[%d]: 0x%x\n",i,current_running->mutex_lock[i]);
    i=0;
    while(i<16){  
        if(current_running->mutex_lock[i] == lock){
            current_running->mutex_lock[i] = 0;
            break;
        }
        i++;
    } 
    //printkf("\n");
    //for(i=0;i<16;i++) printkf("cur-mutex[%d]: 0x%x\n",i,current_running->mutex_lock[i]);
    //printkf("9\n");
/*
    if(queue_is_empty(&lock->queue)){
        lock->status = UNLOCKED;
    }else{
        pcb_t *p = do_unblock_one(&lock->queue);
        //printkf("\n");
        //for(i=0;i<16;i++) printkf("cur-mutex[%d]: 0x%x\n",i,p->mutex_lock[i]);
        //i=0;
        //while(p->mutex_lock[i] != 0 && i<16) i++;
        //if(i<16) p->mutex_lock[i] = lock;
        //else printkf("mutex_lock in pcb is full 2\n");
    }
*/
    //printkf("10\n");
}

