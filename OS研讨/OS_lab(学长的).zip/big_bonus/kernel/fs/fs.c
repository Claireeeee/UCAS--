#include "fs.h"
#include "syscall.h"
#include "sd.h"
#include "mm.h"

char cur_dir[100];
file_desc_t file_desc[16];

int cnt_bit(char a){
    return (a&0x1)+((a&0x2)>>1)+((a&0x4)>>2)+((a&0x8)>>3)+((a&16)>>4)+((a&32)>>5)+((a&64)>>6)+((a&128)>>7);
}

int find_bit(char a){
    if((a&0x1)==0) return 0;
    if((a&0x2)==0) return 1;
    if((a&0x4)==0) return 2;
    if((a&0x8)==0) return 3;
    if((a&0x10)==0) return 4;
    if((a&0x20)==0) return 5;
    if((a&0x40)==0) return 6;
                  return 7;
}

int reset_bit(char a){
    if(a==0) return 0xfe;
    if(a==1) return 0xfd;
    if(a==2) return 0xfb;
    if(a==3) return 0xf7;
    if(a==4) return 0xef;
    if(a==5) return 0xdf;
    if(a==6) return 0xbf;
    else     return 0x7f;
}

void print_superblock(super_block_t *sb){
    //printkf("spare:%d(1 for exist)\n",sb->spare);
    printkf("spare:%d(1 for exist); block size:0x%x(B);\nfs begin:0x%x(B); fs size:0x%x(blocks);\nblock map size:0x%x(blocks); inode map begin(offset):0x%x(blocks);\ninode map size:0x%x(blocks); inode begin(offset):0x%x(blocks);\ninode size:0x%x(blocks); ",sb->spare,sb->block_size,sb->fs_begin,sb->fs_size,sb->block_map_size,sb->inode_map_begin,sb->inode_map_size,sb->inode_begin,sb->inode_size);
    printkf("data begin(offset):0x%x(blocks);\ndata size:0x%x(blocks)\n",sb->data_begin,sb->data_size);
}

dentry_t curdir_data[DENTRY_NUM_PER_BLOCK];

void mkfs(char *name){
    super_block_t super_block;
    sd_card_read(&super_block,FS_BEGIN,BLOCK_SIZE);
    if(super_block.spare==1 && super_block.magic==MAGIC &&name[0]!='f') {
        printkf("fs ever exists\n");
        goto ever;
    }
    memset(&super_block,0,BLOCK_SIZE);
    printkf("[FS]Start initialize filesystem...\n");
    printkf("[FS]Seting superblock...\n");
    
    super_block.spare = 0x1;
    super_block.magic = MAGIC;
    super_block.block_size = BLOCK_SIZE;
    super_block.fs_begin = FS_BEGIN;//byte
    super_block.fs_size = FS_SIZE;//block
    super_block.block_map_size = BLOCK_MAP_SIZE;
    super_block.inode_map_begin = INODE_MAP_OFFSET;//block
    super_block.inode_map_size = INODE_MAP_SIZE;
    super_block.inode_begin = INODE_OFFSET;
    super_block.inode_size = INODE_SIZE;
    super_block.data_begin = DATA_OFFSET;
    super_block.data_size = FS_SIZE-1-BLOCK_MAP_SIZE-INODE_MAP_OFFSET-INODE_BLOCK_SIZE;
    //print_superblock(&super_block);
    sd_card_write(&super_block, FS_BEGIN, BLOCK_SIZE);
    printkf("[FS]>Setting block map...\n");
    
    unsigned char set[BLOCK_SIZE];
    //char set2[BLOCK_SIZE];
    memset(set,0,sizeof(set));
    //memset(set2,0,sizeof(set2));
    set[0] = 0xff;
    sd_card_write(set, FS_BEGIN+BLOCK_MAP_OFFSET*BLOCK_SIZE, BLOCK_SIZE);
    //sd_card_read(set2, FS_BEGIN+BLOCK_MAP_OFFSET*BLOCK_SIZE, UPALIGN_SECTOR(sizeof(set)));
    //printkf("set2[0]: %d",set2[0]);
    set[0]=0;
    int tmp=1;
    for(;tmp<BLOCK_MAP_SIZE;tmp++){
        sd_card_write(set, FS_BEGIN+(BLOCK_MAP_OFFSET+tmp)*BLOCK_SIZE, BLOCK_SIZE);
    }
    
    printkf("[FS]>Setting inode map...\n");
    set[0] = 1;
    
    sd_card_write(set, FS_BEGIN+INODE_MAP_OFFSET*BLOCK_SIZE, BLOCK_SIZE);
    printkf("[FS]>Setting root dir...\n");
    memset(curdir_data,0,sizeof(curdir_data));
    dentry_t *dentry = (dentry_t *) curdir_data;
    dentry->mode = 2;
    dentry->ino  = 0;
    strcpy(dentry->name, ".");
    (dentry+1)->mode = 2;
    (dentry+1)->ino = 0;
    strcpy((dentry+1)->name, "..");
    sd_card_write(dentry, FS_BEGIN+BLOCK_SIZE*ROOT_BLOCK, UPALIGN_SECTOR(BLOCK_SIZE));
    inode_t *inode = (inode_t *)set;
    memset(inode,0,BLOCK_SIZE);
    inode[0].direct_pointer[0] = ROOT_BLOCK;
    inode[0].mode = 2;
    inode[0].hard_link=0;
    sd_card_write(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    memset(file_desc,0,sizeof(file_desc));
ever:
    sd_card_read(curdir_data, FS_BEGIN+BLOCK_SIZE*ROOT_BLOCK, UPALIGN_SECTOR(BLOCK_SIZE));
    print_superblock(&super_block);
    printkf("size of inode_t: %d(B)\n",sizeof(inode_t));
    printkf("size of dentry_t: %d(B)\n",sizeof(dentry_t));
    //printkf("command mkfs\n");
}

void statfs(){
    unsigned char set[BLOCK_SIZE];
    int i=0,cnt=0;
    //unsigned char set2[BLOCK_SIZE];
    //memset(set2,0,sizeof(set2));
    //sd_card_read(set2, FS_BEGIN+BLOCK_MAP_OFFSET*BLOCK_SIZE, UPALIGN_SECTOR(sizeof(set)));
    //printkf("set2[0]: %d\n",set2[0]);
    for(;i<BLOCK_MAP_SIZE;i++){
        sd_card_read(set, FS_BEGIN+BLOCK_SIZE*(BLOCK_MAP_OFFSET+i), sizeof(set));
        int j=0;
        for(;j<BLOCK_SIZE;j++) cnt+=cnt_bit(set[j]);
        //printkf("%d: set[0]: %d\n",i,set[0]);
    }
    
    printkf("block size: 0x%x(B)\n",BLOCK_SIZE);
    printkf("used block: %d/%d   start block: %d\n",cnt,FS_SIZE,FS_BEGIN/BLOCK_SIZE);

    cnt=0;
    i=0;
    for(;i<INODE_MAP_SIZE;i++){
        sd_card_read(set, FS_BEGIN+BLOCK_SIZE*(INODE_MAP_OFFSET+i),sizeof(set));
        int j=0;
        for(;j<BLOCK_SIZE;j++) cnt+=cnt_bit(set[j]);
    }
    printkf("inode map offset: %d  inode map used: %d/%d",INODE_MAP_OFFSET,cnt,BLOCK_SIZE/INODE_SIZE);
    printkf("size of inode_t: %d(B)\n",sizeof(inode_t));
    printkf("size of dentry_t: %d(B)\n",sizeof(dentry_t));

}

int get_segdir(char *des, char *src){
    if(src[0]=='/' || src[0]=='\''){
        printkf("char '/' or '\'' is not allowed in dir name\n");
        return 0;
    }
    
    int i=0;
    while(src[i]!='\0' && src[i]!='/'){
        des[i]=src[i];
        i++;
    }
    des[i]=='\0';
    //printkf("src in get_segdir: %s des: %s, i:%d\n",src,des,i);
    return i+(src[i]=='/');
}
//ino-from 0
char tmp_dir[100];
dentry_t tmpdir_data[DENTRY_NUM_PER_BLOCK];
int getin_dir(char *dir){
    int i=0;
    //printkf("dir: %s\n",dir);
    for(;i<DENTRY_NUM_PER_BLOCK;i++){
        if(strcmp(dir,tmpdir_data[i].name)==0 && tmpdir_data[i].mode==2) break; 
    }
    //printkf("666666666666666: %d\n",i);
    if(i==DENTRY_NUM_PER_BLOCK){
        //printkf("7777777777777777\n");
        printkf("dir name not found\n");
        return 0;
    }
    int ino = tmpdir_data[i].ino;
    inode_t inode;
    sd_card_read(&inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE+sizeof(inode_t)*ino, sizeof(inode_t));
    if(inode.mode!=2){
        printkf("error: inode mode wrong\n");
        return 0;
    }else{
        sd_card_read(tmpdir_data,FS_BEGIN+BLOCK_SIZE*inode.direct_pointer[0],BLOCK_SIZE);
        strcpy(tmp_dir+strlen(tmp_dir),"/");
        strcpy(tmp_dir+strlen(tmp_dir),dir);
        return 1;
    }
}

void cd(char *name){
    //printkf("111111111\n");
    char seg_dir[100];
    memset(tmp_dir,0,sizeof(tmp_dir));
    memcpy(tmp_dir,cur_dir,strlen(cur_dir));
    memcpy(tmpdir_data,curdir_data,sizeof(curdir_data));
    memset(seg_dir,0,sizeof(seg_dir));    
    
    int name_idx=0;
    int len;
    if(strcmp(name,".")==0) return ;
    if(strcmp(name,"..")==0){
        //printkf("tmp_dir before:%s ",tmp_dir);
        int len_cu = strlen(tmp_dir);
        if(len_cu!=0){
            while(tmp_dir[--len_cu]!='/');
            memset(tmp_dir+len_cu,0,strlen(tmp_dir+len_cu)); 
        }
        //printkf("tmp_dir:%s len_cu:%d\n",tmp_dir,len_cu);
        memset(name,0,sizeof(name));
        strcpy(name,tmp_dir);
    }
    
    if(name[0]=='\0'){
        memset(cur_dir,0,sizeof(cur_dir));
        sd_card_read(curdir_data,FS_BEGIN+ROOT_BLOCK*BLOCK_SIZE,BLOCK_SIZE);
        return;
    }

    if(name[0]=='/'){
        //printkf("22222222222\n");
        name_idx=1;
        memset(tmp_dir,0,sizeof(tmp_dir));
        //strcpy(tmp_dir,"/");
        sd_card_read(tmpdir_data,FS_BEGIN+BLOCK_SIZE*ROOT_BLOCK,BLOCK_SIZE);
    }

    while((len=get_segdir(seg_dir,name+name_idx))!=0){
        //printkf("333333333333333\n");
        //printkf("cur seg dir: %s, dir left: %s\n\n",seg_dir,name+name_idx);
        name_idx += len;
        if(getin_dir(seg_dir)==0) {
            //printkf("555555555555555\n");
            printkf("getin dir failed\n");
            return;
        }
        memset(seg_dir,0,sizeof(seg_dir));
        if(name[name_idx]=='\0') break;
    }
    //printkf("4444444444444\n");
    memset(cur_dir,0,sizeof(cur_dir));
    strcpy(cur_dir,tmp_dir);
    memcpy(curdir_data,tmpdir_data,sizeof(curdir_data));
}

int get_ino(void){
    unsigned char ino_map[BLOCK_SIZE];
    sd_card_read(ino_map,FS_BEGIN+INODE_MAP_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    int i=0;
    for(;i<BLOCK_SIZE;i++){
        if(ino_map[i]!=0xff) break;
    }
    if(i==BLOCK_SIZE){
        printkf("no spare ino-map, u can remove some dentry or file and try again\n");
        return -1;
    }
    
    int res = i*8+find_bit(ino_map[i]);
    //printkf("i in getio:%d res:%d\n",i,res);
    if(res>=INODE_NUM_PER_BLOCK){
        printkf("no spare inode, which is not exist now. u can remove some dentry or file and try again\n");
        return -1;
    }
    ino_map[i] |= 1<<find_bit(ino_map[i]);
    sd_card_write(ino_map,FS_BEGIN+INODE_MAP_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    return res;
}

int get_bm(void){
    int i=0;
    unsigned char bm[BLOCK_SIZE];
    for(;i<BLOCK_MAP_SIZE;i++){
        sd_card_read(bm,FS_BEGIN+(BLOCK_MAP_OFFSET+i)*BLOCK_SIZE,BLOCK_SIZE);
        uint32_t j=0;
        for(;j<BLOCK_SIZE;j++){
            if(bm[j]!=0xff){
                int res = j*8+find_bit(bm[j]);
                //printkf("j:%d, res:%d, bm[%d]:%d\n",j,res,j,bm[j]);
                bm[j] |= 1<<find_bit(bm[j]);
                sd_card_write(bm,FS_BEGIN+(BLOCK_MAP_OFFSET+i)*BLOCK_SIZE,BLOCK_SIZE);
                return res;
            }
        }
    }
    printkf("no spare block. u can remove some file or and try again\n");
    return -1;
}

void mkdir(char *name){
    //printkf("in mkdir\n");
    int i=0;
    for(;i<DENTRY_NUM_PER_BLOCK;i++){
        if(curdir_data[i].mode==2 && strcmp(curdir_data[i].name,name)==0){
            printkf("dir already exists\n");
            return ;
        }
    }
    i=0;
    for(;i<DENTRY_NUM_PER_BLOCK;i++){
        //printkf("curdir[%d].mode:%d\n",i,curdir_data[i].mode);
        if(curdir_data[i].mode==0) break;
    }
    if(i==DENTRY_NUM_PER_BLOCK){
        printkf("no more spare dentry in the dir. u can remove some dentry and try again\n");
        return ;
    }

    int ino = get_ino();
    //printkf("ino:%d\n",ino);
    if(ino==-1 || ino==0) return ;
    inode_t inode[INODE_NUM_PER_BLOCK];
    sd_card_read(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    memset(inode+ino,0,sizeof(inode_t));
    inode[ino].mode = 2;
    
    int bm = get_bm();
    //printkf("bm: %d\n",bm);
    if(bm<=7) return;
    inode[ino].direct_pointer[0] = bm;
    inode[curdir_data[0].ino].hard_link += 1;

    //printkf("111111111111\n");
    memset(curdir_data+i,0,sizeof(dentry_t));
    curdir_data[i].ino=ino;
    curdir_data[i].mode=2;
    //printkf("i:%d\n",i);
    strcpy(curdir_data[i].name,name);
    int cur_bm = inode[curdir_data[0].ino].direct_pointer[0];
    sd_card_write(curdir_data,FS_BEGIN+cur_bm*BLOCK_SIZE,BLOCK_SIZE);

    sd_card_write(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);

    dentry_t *dentry = (dentry_t *)inode;
    memset(dentry,0,BLOCK_SIZE);
    dentry->ino = ino;
    dentry->mode = 2;
    strcpy(dentry->name,".");
    (dentry+1)->ino = curdir_data[0].ino;
    (dentry+1)->mode = 2;
    strcpy((dentry+1)->name, "..");
    sd_card_write(dentry,FS_BEGIN+bm*BLOCK_SIZE,BLOCK_SIZE);
    return ;
}

void rmdir(char *name){
    int i=2;
    for(;i<DENTRY_NUM_PER_BLOCK;i++){
        if(curdir_data[i].mode==2 && strcmp(curdir_data[i].name,name)==0){
            unsigned char ino_map[BLOCK_SIZE];
            sd_card_read(ino_map,FS_BEGIN+INODE_MAP_OFFSET*BLOCK_MAP_SIZE,BLOCK_SIZE);
            int ino = curdir_data[i].ino;
            ino_map[ino/8] &= reset_bit(ino%8);
            sd_card_write(ino_map,FS_BEGIN+INODE_MAP_OFFSET*BLOCK_MAP_SIZE,BLOCK_SIZE);
            
            inode_t *inode = (inode_t *)ino_map;
            sd_card_read(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);

            curdir_data[i].mode=0;
            memset(curdir_data[i].name,0,strlen(curdir_data[i].name));
            curdir_data[i].ino=-1;
            sd_card_write(curdir_data,FS_BEGIN+inode[curdir_data[0].ino].direct_pointer[0]*BLOCK_SIZE,BLOCK_SIZE);

            int bm=inode[ino].direct_pointer[0];
            int bm_bn=bm/(BLOCK_SIZE*8);
            int bm_idx=bm%(BLOCK_SIZE*8);
            unsigned char *bm_map = ino_map;
            sd_card_read(bm_map,FS_BEGIN+(BLOCK_MAP_OFFSET+bm_bn)*BLOCK_SIZE,BLOCK_SIZE);
            bm_map[bm_idx/8] &= reset_bit(bm_idx%8);
            sd_card_write(bm_map,FS_BEGIN+(BLOCK_MAP_OFFSET+bm_bn)*BLOCK_SIZE,BLOCK_SIZE);

            return ;
        }
    }
    //printkf("command rmdir: %s\n",name);
}

void ls(){
    int i=0;
    for(;i<DENTRY_NUM_PER_BLOCK;i++){
        if(curdir_data[i].mode==1 || curdir_data[i].mode==2){
            printkf("%s: ",curdir_data[i].mode==1?"file":"dir");
            printkf("%s\n",curdir_data[i].name);
        }
    }
}

void touch(char *name){
    if(name[0]=='\0'){
        printkf("empty name is not allowed\n");
        return ;
    }
    int i=0;
    for(;i<DENTRY_NUM_PER_BLOCK;i++){
        if(curdir_data[i].mode==1 && strcmp(curdir_data[i].name,name)==0){
            printkf("file already exists\n");
            return ;
        }
    }
    i=0;
    for(;i<DENTRY_NUM_PER_BLOCK;i++){
        //printkf("curdir[%d].mode:%d\n",i,curdir_data[i].mode);
        if(curdir_data[i].mode==0) break;
    }
    if(i==DENTRY_NUM_PER_BLOCK){
        printkf("no more spare dentry in the dir. u can remove some dentry and try again\n");
        return ;
    }

    int ino = get_ino();
    //printkf("ino:%d\n",ino);
    if(ino==-1 || ino==0) return ;
    inode_t inode[INODE_NUM_PER_BLOCK];
    sd_card_read(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    memset(inode+ino,0,sizeof(inode_t));
    inode[ino].mode = 1;
    /*
    int bm = get_bm();
    printkf("bm: %d\n",bm);
    if(bm<=7) return;
    */
    inode[ino].file_size = 0;
    inode[curdir_data[0].ino].hard_link += 1;
    
    //printkf("111111111111\n");
    memset(curdir_data+i,0,sizeof(dentry_t));
    curdir_data[i].ino=ino;
    curdir_data[i].mode=1;
    //printkf("i:%d\n",i);
    strcpy(curdir_data[i].name,name);
    int cur_bm = inode[curdir_data[0].ino].direct_pointer[0];
    sd_card_write(curdir_data,FS_BEGIN+cur_bm*BLOCK_SIZE,BLOCK_SIZE);

    sd_card_write(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);

    //printkf("command touch: %s\n",name);
}

void cat(char *name){
    int file_idx=0;
    for(;file_idx<DENTRY_NUM_PER_BLOCK;file_idx++){
        if(curdir_data[file_idx].mode==1 && strcmp(curdir_data[file_idx].name,name)==0){
            break;
        }
    }
    if(file_idx==DENTRY_NUM_PER_BLOCK){
        printkf("no such file exists\n");
        return ;
    }
    int ino = curdir_data[file_idx].ino;
    inode_t inode[INODE_NUM_PER_BLOCK];
    sd_card_read(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    int fb_idx = 0, file_size = inode[ino].file_size;
    int file_block = BLOCKNUM(file_size);
    
    for(;fb_idx<10 && fb_idx<file_block;fb_idx++){
        char data[BLOCK_SIZE];
        sd_card_read(data,FS_BEGIN+inode[ino].direct_pointer[fb_idx]*BLOCK_SIZE,BLOCK_SIZE);
        int cur_size = ((fb_idx+1)*BLOCK_SIZE>=file_size) ? file_size-fb_idx*BLOCK_SIZE : BLOCK_SIZE;
        int i=0;
        for(;i<cur_size;i++) printkf("%c",data[i]);
    }
    if(fb_idx*BLOCK_SIZE>=file_size) return;

    fb_idx = 0;
    file_size -= 10*BLOCK_SIZE;
    file_block -= 10;
    
    uint32_t first_idx_block[POINTER_NUM_PER_BLOCK];
    int first_idx=0;
    sd_card_read(first_idx_block,FS_BEGIN+inode[ino].one_level_pointer*BLOCK_SIZE,BLOCK_SIZE);
    for(;first_idx<POINTER_NUM_PER_BLOCK && fb_idx<file_block; first_idx++){
        uint32_t cur_p = first_idx_block[first_idx];
        for(;fb_idx<1024 && fb_idx<file_block;fb_idx++){
            char data[BLOCK_SIZE];
            sd_card_read(data,FS_BEGIN+cur_p*BLOCK_SIZE,BLOCK_SIZE);
            int cur_size = ((fb_idx+1)*BLOCK_SIZE>=file_size) ? file_size-fb_idx*BLOCK_SIZE : BLOCK_SIZE;
            int i=0;
            for(;i<cur_size;i++) printkf("%c",data[i]);
        }
    }
    if(fb_idx*BLOCK_SIZE>=file_size) return;
    printkf("block not enough, need two level pointer\n");
    return ;
    fb_idx = 0;
    file_size -= 1024*BLOCK_SIZE;
    file_block -= 1024;

    //printkf("command cat: %s\n",name);
}


int open(char *name, int access){
    //printkf("command open\n");
    int i=0;
    for(;i<DENTRY_NUM_PER_BLOCK;i++){
        if(curdir_data[i].mode==1 && strcmp(curdir_data[i].name,name)==0) break;
    }
    if(i==DENTRY_NUM_PER_BLOCK) {
        touch(name);
        for(i=0;i<DENTRY_NUM_PER_BLOCK;i++){
            if(curdir_data[i].mode==1 && strcmp(curdir_data[i].name,name)==0) break;
        }
    }
    int fd=0;
    for(;fd<FD_NUM;fd++){
        if(file_desc[fd].spare==0) break;
    }
    if(fd==FD_NUM){
        printkf("no spare file desc. u can close some file and try again\n");
        return -1;
    }
    file_desc[fd].spare=1;
    file_desc[fd].seek_pos_r=0;
    file_desc[fd].seek_pos_w=0;
    file_desc[fd].access = access;
    file_desc[fd].ino=curdir_data[i].ino;
    //printkf("open file desc:\n fd:%d spare:%d seek_pos:%d access:%d ino:%d\n",fd,file_desc[fd].spare,file_desc[fd].seek_pos_r,file_desc[fd].access,file_desc[fd].ino);
    return fd;
}

int read(int fd, char *buff, int size){
    //printkf("command read\n");
    //printkf("read file desc:\n fd:%d spare:%d seek_pos_r:%d access:%d ino:%d\n",fd,file_desc[fd].spare,file_desc[fd].seek_pos_r,file_desc[fd].access,file_desc[fd].ino);
    if(file_desc[fd].spare!=1){
        printkf("fd %d is not open\n",fd);
        return 0;
    }
    if(file_desc[fd].access & O_RD == 0){
        printkf("not allowed to read\n");
        return 0;
    }

    int ino = file_desc[fd].ino;
    int seek_pos = file_desc[fd].seek_pos_r;

    inode_t inode[INODE_NUM_PER_BLOCK];
    sd_card_read(inode, FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    
    int fb_idx = 0;
    int goal_pos = min(inode[ino].file_size,seek_pos+size);
    int goal_block = BLOCKNUM(goal_pos);

    int size_count=0;
    for(;fb_idx<10 && fb_idx<goal_block;fb_idx++){
        if(seek_pos/BLOCK_SIZE > fb_idx) continue;
        char data[BLOCK_SIZE];
        sd_card_read(data,FS_BEGIN+inode[ino].direct_pointer[fb_idx]*BLOCK_SIZE,BLOCK_SIZE);
        int inner_pos = seek_pos%BLOCK_SIZE;
        //printkf("read inner_pos:%d fb_idx:%d ",inner_pos,fb_idx);
        for(;inner_pos<BLOCK_SIZE && seek_pos<goal_pos;inner_pos++, seek_pos++) 
            buff[size_count++]=data[inner_pos];
        //printkf("buff:%s data:%s\n",buff, data);
    }
    file_desc[fd].seek_pos_r = seek_pos;
    if(seek_pos>=goal_pos) return size_count;
    return size_count;
    
    uint32_t first_idx_block[POINTER_NUM_PER_BLOCK];
    int first_idx=0;
    sd_card_read(first_idx_block,FS_BEGIN+inode[ino].one_level_pointer*BLOCK_SIZE,BLOCK_SIZE);
    for(;first_idx<POINTER_NUM_PER_BLOCK && fb_idx<goal_block; first_idx++, fb_idx++){
        if(seek_pos/BLOCK_SIZE > fb_idx) continue;
        char data[BLOCK_SIZE];
        sd_card_read(data, FS_BEGIN+first_idx_block[first_idx]*BLOCK_SIZE,BLOCK_SIZE);
        int inner_pos = seek_pos%BLOCK_SIZE;
        for(;inner_pos<BLOCK_SIZE && seek_pos<goal_pos; inner_pos++, seek_pos++){
            buff[size_count++] = data[inner_pos];
        }
        ///printkf("read buff:%s data:%s\n");
    }
    file_desc[fd].seek_pos_r = seek_pos;
    if(seek_pos>=goal_pos) {
        printkf("block not enough, need two level pointer\n");
        return size_count;
    }
    return size_count;
}

int write(int fd, char *buff, int size){
    //printkf("command write\n");
    //printkf("write file desc:\n fd:%d spare:%d seek_pos_w:%d access:%d ino:%d\n",fd,file_desc[fd].spare,file_desc[fd].seek_pos_w,file_desc[fd].access,file_desc[fd].ino);
    if(file_desc[fd].spare!=1){
        printkf("fd %d is not open\n",fd);
        return 0;
    }
    if(file_desc[fd].access & O_WR == 0){
        printkf("not allowed to write\n");
        return ;
    }
    int seek_pos = file_desc[fd].seek_pos_w;
    int ino = file_desc[fd].ino;

    inode_t inode[INODE_NUM_PER_BLOCK];
    sd_card_read(inode, FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    
    int goal_pos = seek_pos+size;
    int old_file_size = inode[ino].file_size;
    int goal_file_size = max(goal_pos,old_file_size);
    int old_file_block = BLOCKNUM(old_file_size);
    int goal_file_block = BLOCKNUM(goal_file_size);

    inode[ino].file_size = goal_file_size;

    int file_size = min(inode[ino].file_size,size);
    int file_block = BLOCKNUM(file_size);
    
    int size_count=0;
    int fb_idx = 0;
    for(;fb_idx<10 && fb_idx<goal_file_block;fb_idx++){
        if(seek_pos/BLOCK_SIZE > fb_idx) continue;
        if(fb_idx>=old_file_block){
            //printkf("fb_idx:%d old_file_block:%d ",fb_idx,old_file_block);
            //printkf("not enough\n");
            int bm=get_bm();
            inode[ino].direct_pointer[fb_idx]=bm;
            char data[BLOCK_SIZE];
            memset(data,0,BLOCK_SIZE);
            sd_card_write(data,FS_BEGIN+bm*BLOCK_SIZE,BLOCK_SIZE);
        }
        char data[BLOCK_SIZE];
        sd_card_read(data,FS_BEGIN+inode[ino].direct_pointer[fb_idx]*BLOCK_SIZE,BLOCK_SIZE);
        int inner_pos = seek_pos%BLOCK_SIZE;
        //printkf("write inner_pos:%d, buff:%s data_inner:",inner_pos,buff);
        for(;inner_pos<BLOCK_SIZE && seek_pos<goal_file_size;inner_pos++,seek_pos++){
            data[inner_pos] = buff[size_count++];
            //printkf("%c",data[inner_pos]);
        }
        //printkf("fb_idx:%d data:%s",fb_idx,data);
        sd_card_write(data,FS_BEGIN+inode[ino].direct_pointer[fb_idx]*BLOCK_SIZE,BLOCK_SIZE);
    }
    sd_card_write(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);

    //return size_count;
    file_desc[fd].seek_pos_w = seek_pos;
    if(seek_pos>=goal_file_size) return size_count;
    
    uint32_t first_idx_block[POINTER_NUM_PER_BLOCK];
    if(fb_idx>=old_file_block){
        int bm = get_bm();
        inode[ino].one_level_pointer = bm;
        sd_card_write(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    }
    
    sd_card_read(first_idx_block,FS_BEGIN+inode[ino].one_level_pointer*BLOCK_SIZE,BLOCK_SIZE);
    
    int first_idx=0;
    for(;first_idx<POINTER_NUM_PER_BLOCK && fb_idx<goal_file_block; first_idx++){
        if(seek_pos/BLOCK_SIZE > fb_idx) continue;
        if(fb_idx>=old_file_block){
            int bm=get_bm();
            first_idx_block[first_idx] = bm;
            char data[BLOCK_SIZE];
            memset(data,0,BLOCK_SIZE);
            sd_card_write(data,FS_BEGIN+bm*BLOCK_SIZE,BLOCK_SIZE);
        }
        uint32_t bm = first_idx_block[first_idx];
        char data[BLOCK_SIZE];
        sd_card_read(data,FS_BEGIN+bm*BLOCK_SIZE,BLOCK_SIZE);
        int inner_pos = seek_pos%BLOCK_SIZE;
        for(;inner_pos<BLOCK_SIZE && seek_pos<goal_file_size;inner_pos++, seek_pos++){
            data[inner_pos] = buff[size_count++];
        }
        sd_card_write(data, FS_BEGIN+bm*BLOCK_SIZE,BLOCK_SIZE);
    }
     sd_card_write(first_idx_block,FS_BEGIN+inode[ino].one_level_pointer*BLOCK_SIZE,BLOCK_SIZE);
    
    file_desc[fd].seek_pos_w = seek_pos;
    if(seek_pos>=goal_file_size) return size_count;

    return size_count;
}

void close(int fd){
    //printkf("command close\n");
    if(fd<0 || fd>=FD_NUM){
        printkf("fd is not valid.(need 0~15, but %d)\n",fd);
        return ;
    }
    memset(file_desc+fd,0,sizeof(file_desc_t));
    return ;
}

uint32_t code_data[1024];

void launch(char *name){
    printkf("command launch %s\n",name);

    //file size default less than 4KB
    int d_idx=0;
    for(;d_idx<DENTRY_NUM_PER_BLOCK;d_idx++){
        if(curdir_data[d_idx].mode==1 && strcmp(curdir_data[d_idx].name,name)==0){
            break;
        }
    }
    if(d_idx==DENTRY_NUM_PER_BLOCK){
        printkf("no such file\n");
        return ;
    }
    printkf("d_idx: %d ",d_idx);
    int ino = curdir_data[d_idx].ino;
    printkf("ino: %d ",ino);
    inode_t inode[INODE_NUM_PER_BLOCK];
    sd_card_read(inode,FS_BEGIN+INODE_OFFSET*BLOCK_SIZE,BLOCK_SIZE);
    uint32_t bm=inode[ino].direct_pointer[0];
    printkf("bm: %d ",bm);
    uint32_t file_size = inode[ino].file_size;
    printkf("file size: %x\n",file_size);
    char *file_data = (char *)inode;
    sd_card_read(file_data,FS_BEGIN+bm*BLOCK_SIZE,BLOCK_SIZE);
    /*
    printkf("file size: %d\n",file_size);
    int i=0,j=0;
    int *p= (int*)file_data;
    for(;i<file_size-10 && j<10;i += 4,j++){
        if(j<10 || j>900/4 && j<(900+20)/4){
            printkf("%x ",*(p+j));
            if(j==9) printkf("\n");
        }
    }
    */
    Elf32_Ehdr eh;
    Elf32_Phdr ph;
    memcpy(&eh,file_data,sizeof(Elf32_Ehdr));
    uint32_t e_phoff = (uint32_t ) eh.e_phoff;
    printkf("e_phoff: %x e_type: %x e_machine: %x ",e_phoff,eh.e_type,eh.e_machine);
    memcpy(&ph,file_data+e_phoff,sizeof(Elf32_Phdr));
    
    uint32_t p_filesz = ph.p_filesz;
    uint32_t p_memsz  = ph.p_memsz;
    uint32_t p_offset = ph.p_offset;
    printkf("filesz: %x memsz: %x offset: %x ",p_filesz, p_memsz, p_offset);
    printkf("\n");

    memset(code_data,0,sizeof(code_data));
    memcpy(code_data,file_data+p_offset,p_filesz);

    //get pid
    pid_t pid = 2;
    pcb_t *p;
    while(pid<16 && pcb[pid].tag==1) pid++;
    p = &pcb[pid];
    if(pid==16) {
        printkf("spawn error: no spare pcb space.\n");
        return ;
    }
    uint32_t default_cp0_status = 0x1000ff00;

    memset(pte[pid],0,sizeof(pte[pid]));

    //get start addr
    char *paddr = alloc();
    char *vaddr = (char *)0x2000;
    printkf("pid:%d paddr:%x vaddr:%x ",pid,(int32_t)paddr,(uint32_t)vaddr);
    //code
    memcpy(paddr+0xa0000000, file_data+p_offset,p_filesz);

    //set TLB
    int vpage_number = MYPNUM(vaddr);
    pte[pid][vpage_number] = (((uint32_t)paddr&0xfffff000)>>6) | PTE_C | PTE_D | PTE_V;
    TLBWI__(pte[pid][vpage_number],pte[pid][vpage_number+1],10);

    printkf("code data: %x %x %x %x %x %x\n",code_data[0],code_data[1],code_data[2],code_data[3],code_data[4],code_data[5]);

    memset(p,0,sizeof(pcb_t));
    p->kernel_context.regs[31] = (uint32_t ) int_clear_finish;
    p->kernel_context.cp0_epc = (uint32_t)vaddr;      
    p->kernel_context.regs[29] = p->kernel_stack_top = KSTACK_BASE - pid * KSTACK_SIZE;
    p->kernel_context.cp0_status = default_cp0_status;

    p->user_context.regs[31] = p->kernel_context.regs[31];
    p->user_context.cp0_epc = (uint32_t)vaddr;    
    p->user_context.regs[29] = p->user_stack_top =  KSTACK_BASE + pid * KSTACK_SIZE;
    p->user_context.cp0_status = default_cp0_status;

    p->pid = pid;
    p->type = USER_PROCESS;
    p->status = TASK_READY;
    p->priority = 0;
    p->tag = 1;
    p->name = name;
    ready_queue_push(p);
    //do_ps();

}