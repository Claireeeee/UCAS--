/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *            Copyright (C) 2018 Institute of Computing Technology, CAS
 *               Author : Han Shukai (email : hanshukai@ict.ac.cn)
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 *                  The shell acts as a task running in user mode. 
 *       The main function is to make system calls through the user's output.
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * *
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this 
 * software and associated documentation files (the "Software"), to deal in the Software 
 * without restriction, including without limitation the rights to use, copy, modify, 
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit 
 * persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  * * * * * * * * * * */

#include "test.h"
#include "stdio.h"
#include "screen.h"
#include "syscall.h"
#include "sched.h"

static void disable_interrupt()
{
    uint32_t cp0_status = get_cp0_status();
    cp0_status &= 0xfffffffe;
    set_cp0_status(cp0_status);
}

static void enable_interrupt()
{
    uint32_t cp0_status = get_cp0_status();
    cp0_status |= 0x01;
    set_cp0_status(cp0_status);
}

static char read_uart_ch(void)
{
    char ch = 0;
    unsigned char *read_port = (unsigned char *)(0xbfe48000 + 0x00);
    unsigned char *stat_port = (unsigned char *)(0xbfe48000 + 0x05);

    while ((*stat_port & 0x01))
    {
        ch = *read_port;
    }
    return ch;
}

//Running project_5 from shell is recommended. You can also run it from loadboot.
struct task_info task5_1 = {"send",(uint32_t)&phy_regs_task1, USER_PROCESS};
struct task_info task5_2 = {"recv",(uint32_t)&phy_regs_task2, USER_PROCESS};
struct task_info task5_3 = {"initmac",(uint32_t)&phy_regs_task3, USER_PROCESS};
struct task_info task6_1 = {"hello",(uint32_t)&test_fs, USER_PROCESS};
static struct task_info *test_tasks[4] = {&task5_3,&task5_1,&task5_2,&task6_1};
static int num_test_tasks = 3;

extern char cur_dir[100];

void test_shell()
{
    //printkf("get into shell\n");
    memset(cur_dir,0,sizeof(cur_dir));
    sys_move_cursor(0,SCREEN_HEIGHT/2);
    //printf("2222222222222222222222\n");
    //printkf("3333333333333333333333\n");
    printf("===================================");
    int print_location = SCREEN_HEIGHT-1;
    sys_move_cursor(0,print_location);
    printf(">root@UCAS_OS:%s$ ",cur_dir[0]?cur_dir:"~");
    while (1)
    {
        // read command from UART port
        char ch;
        char buff[31];
        memset(buff,0,sizeof(buff));
        int i=0, flag=1;
        disable_interrupt();
        if((ch=read_uart_ch()) != '\0'){
            if(ch==8   ){//\b
                    i--; 
                    screen_write_ch(ch);
                    screen_reflush();
                    continue;
            }//backspace
            else{
                buff[i++] = ch;
                screen_write_ch(ch);
                screen_reflush();
            }
            while(((ch=read_uart_ch()) != 13) && i<30){
                if(ch=='\0') continue;
                if(ch==8   ){//failed, bs is unknown
                    i--; 
                    screen_write_ch(ch);
                    screen_reflush();
                    continue;
                }//backspace
                buff[i++] = ch;
                screen_write_ch(ch);
                screen_reflush();         
            }
            buff[i] = '\0';
            screen_write_ch('\n');
            screen_reflush();
        }else{
            flag = 0;
        }
        enable_interrupt();

        // TODO solve command
        if(flag){
            if(i==30){
                sys_move_cursor(0, print_location);
                printf("The command is at most of length 30\n");
            }

            if(buff[0]=='p' && buff[1]=='s') 
                sys_ps();
            else if(buff[0]=='c'&& buff[1]=='l'&&buff[2]=='e'&&buff[3]=='a'&&buff[4]=='r') 
                sys_clear();
            else if(buff[0]=='e'&&buff[1]=='x'&&buff[2]=='e'&&buff[3]=='c'){
                int a=0,j=5;
                while(buff[j]>='0' && buff[j]<='9')
                    a = a*10 + buff[j++]-'0';
                printf("exec test_task[%d].\n",a);
                sys_spawn(test_tasks[a]);
            }else if(buff[0]=='k'&&buff[1]=='i'&&buff[2]=='l'&&buff[3]=='l'){
                int a=0,j=5;
                while(buff[j]>='0' && buff[j]<='9')
                    a = a*10 + buff[j++]-'0';
                printf("kill pcb[%d].\n",a);
                sys_kill(a);
            }else if(buff[0]=='m'&&buff[1]=='k'&&buff[2]=='f'&&buff[3]=='s'){
                sys_mkfs(&buff[5]);
            }else if(buff[0]=='s'&&buff[1]=='t'&&buff[2]=='a'&&buff[3]=='t'&&buff[4]=='f'&&buff[5]=='s'&&buff[6]=='\0'){
                sys_statfs();
            }else if(buff[0]=='c'&&buff[1]=='d'&&(buff[2]=='\0'||buff[2]==' ')){
                sys_cd(&buff[3]);
            }else if(buff[0]=='m'&&buff[1]=='k'&&buff[2]=='d'&&buff[3]=='i'&&buff[4]=='r'&&buff[5]==' '){
                sys_mkdir(&buff[6]);
            }else if(buff[0]=='r'&&buff[1]=='m'&&buff[2]=='d'&&buff[3]=='i'&&buff[4]=='r'&&buff[5]==' '){
                sys_rmdir(&buff[6]);
            }else if(buff[0]=='l'&&buff[1]=='s'&&buff[2]=='\0'){
                sys_ls();
            }else if(buff[0]=='t'&&buff[1]=='o'&&buff[2]=='u'&&buff[3]=='c'&&buff[4]=='h'&&buff[5]==' '){
                sys_touch(&buff[6]);
            }else if(buff[0]=='c'&&buff[1]=='a'&&buff[2]=='t'&&buff[3]==' '){
                sys_cat(&buff[4]);
            }else if(buff[0]=='.'&&buff[1]=='/'){
                sys_launch(&buff[2]);
            }else{
                printf("unkown command\n");
            }

            sys_move_cursor(0,print_location);
            printf("\n>root@UCAS_OS:%s$ ",cur_dir[0]?cur_dir:"~");
        }
    }
}