#ifndef INCLUDE_MAIL_BOX_
#define INCLUDE_MAIL_BOX_
#include "queue.h"
#define MBOXVOLUME 10
typedef enum{
    CLOSED,
    OPEN
}status_t;

typedef struct mailbox
{

    queue_t queue;
    char name[30];
    char message[MBOXVOLUME];
    int head;
    int tail;
    int full;
    int empty;
    status_t status;
    int used;
} mailbox_t;


void mbox_init();
mailbox_t *mbox_open(char *);
void mbox_close(mailbox_t *);
void mbox_send(mailbox_t *, void *, int);
void mbox_recv(mailbox_t *, void *, int);

#endif