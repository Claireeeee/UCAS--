#include <assert.h>
#include <elf.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
void write_bootblock(FILE *image, FILE *bbfile, Elf32_Phdr *Phdr);
Elf32_Phdr *read_exec_file(FILE *opfile);
uint8_t count_kernel_sectors(Elf32_Phdr *Phdr);
void extent_opt(Elf32_Phdr *Phdr_bb, Elf32_Phdr *Phdr_k, int kernelsz);
*/
Elf32_Phdr *read_exec_file(FILE *opfile)
{
    Elf32_Ehdr eh;
    fread(&eh, sizeof(char ), sizeof(eh), opfile);

    unsigned int e_phoff = (unsigned int ) eh.e_phoff;
    
    Elf32_Phdr * phdr = (Elf32_Phdr *) malloc(sizeof(Elf32_Phdr));
    fseek(opfile,e_phoff,0);
    fread(phdr,sizeof(char ), sizeof(Elf32_Phdr), opfile);
    //phdr = (Elf32_Phdr *) opfile;
    fseek(opfile,-1l*e_phoff,0);
    
    return phdr;
    
}

uint32_t count_kernel_sectors(Elf32_Phdr *Phdr)
{
    unsigned int memsz = Phdr->p_memsz;
    return (uint32_t ) (memsz/512 + (memsz%512 != 0));
}

void write_bootblock(FILE *image, FILE *file, Elf32_Phdr *phdr)
{
    int p_offset = (int ) phdr->p_offset;
    int p_memsz  = (int ) phdr->p_memsz;
    char tmp[p_memsz+5];

    fseek(file,1l*p_offset,0);
    fread(tmp,sizeof(char),p_memsz,file);
    fwrite(tmp,sizeof(char),p_memsz,image);
    fseek(file,-1l*p_offset,0);
}

void write_kernel(FILE *image, FILE *knfile, Elf32_Phdr *Phdr, int kernelsz)//kernelsz ?? p_memsz??
{
    int p_offset = (int ) Phdr->p_offset;
    int p_filesz = (int ) Phdr->p_filesz;

    char tmp[kernelsz*0x200];
    memset(tmp,0,sizeof(tmp));

    fseek(knfile,1l*p_offset,0);
    fseek(image,1l*0x200,0);
    fread(tmp,sizeof(char),p_filesz,knfile);
    fwrite(tmp,sizeof(char),kernelsz*0x200,image);
    fseek(knfile,-1l*p_offset,0);
    fseek(image,-1l*0x200,0);
}

void record_kernel_sectors(FILE *image, uint32_t kernelsz)
{
    fseek(image,0x1fcl,0);
    fwrite(&kernelsz,sizeof(uint32_t),1,image);
    fseek(image,-0x1fcl,0);
}

void extent_opt(Elf32_Phdr *Phdr_bb, Elf32_Phdr *Phdr_k, int kernelsz)
{
    puts("BootBlock message:");
    printf("Bootblock image memeory size is 0x%x\n",Phdr_bb->p_memsz);
    printf("Bootblock image memory offset is 0x%x\n",Phdr_bb->p_offset);
    
    puts("kernel message:");
    printf("kernel image memory size is 0x%x\n",Phdr_k->p_memsz);
    printf("kernel image memory offset is 0x%x\n",Phdr_k->p_offset);
    printf("kernel sector size is 0x%x\n",kernelsz);
}

int main()
{
    FILE *image;
    while((image=fopen("image","wb+")) == NULL){
        printf("create file failed, retrying...\n");
    }

    FILE *bb = fopen("bootblock","rb+");
    FILE *ke = fopen("main","rb+");

    Elf32_Phdr * phdr_bb = read_exec_file(bb);
    write_bootblock(image,bb,phdr_bb);

    Elf32_Phdr * phdr_ke = read_exec_file(ke);
    uint32_t ke_sz = count_kernel_sectors(phdr_ke);
    write_kernel(image,ke,phdr_ke,ke_sz);
    record_kernel_sectors(image,ke_sz);
    extent_opt(phdr_bb,phdr_ke,ke_sz);
    
    return 0;
}


/*


#include <assert.h>
#include <elf.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define IMAGE_FILE "./image"
#define ARGS "[--extended] [--vm] <bootblock> <executable-file> ..."

#define SECTOR_SIZE 512
#define OS_SIZE_LOC 2
#define BOOT_LOADER_SIG_OFFSET 0x1fe
#define BOOT_LOADER_SIG_1 0x55
#define BOOT_LOADER_SIG_2 0xaa
#define BOOT_MEM_LOC 0x7c00
#define OS_MEM_LOC 0x1000

/* structure to store command line options 
static struct
{
    int vm;
    int extended;
} options;

/* prototypes of local functions 
static void create_image(int nfiles, char *files[]);
static void error(char *fmt, ...);
static void read_ehdr(Elf32_Ehdr *ehdr, FILE *fp);
static void read_phdr(Elf32_Phdr *phdr, FILE *fp, int ph,
                      Elf32_Ehdr ehdr);
static void write_segment(Elf32_Ehdr ehdr, Elf32_Phdr phdr, FILE *fp,
                          FILE *img, int *nbytes, int *first);
static void write_os_size(int nbytes, FILE *img);

int main(int argc, char **argv)
{
}

static void create_image(int nfiles, char *files[])
{
}

static void read_ehdr(Elf32_Ehdr *ehdr, FILE *fp)
{
}

static void read_phdr(Elf32_Phdr *phdr, FILE *fp, int ph,
                      Elf32_Ehdr ehdr)
{
}

static void write_segment(Elf32_Ehdr ehdr, Elf32_Phdr phdr, FILE *fp,
                          FILE *img, int *nbytes, int *first)
{
}

static void write_os_size(int nbytes, FILE *img)
{
}

/* print an error message and exit 
static void error(char *fmt, ...)
{
}
*/
/*
#include <assert.h>
#include <elf.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void write_bootblock(FILE *image, FILE *bbfile, Elf32_Phdr *Phdr);
Elf32_Phdr *read_exec_file(FILE *opfile);
uint32_t count_kernel_sectors(Elf32_Phdr *Phdr);
void extent_opt(Elf32_Phdr *Phdr_bb, Elf32_Phdr *Phdr_k, uint32_t kernelsz);

Elf32_Phdr *read_exec_file(FILE *opfile)
{
    Elf32_Ehdr eh;
    fread(&eh, sizeof(char ), sizeof(eh), opfile);

    unsigned int e_phoff = (unsigned int ) eh.e_phoff;
    
    Elf32_Phdr * phdr = (Elf32_Phdr *) malloc(sizeof(Elf32_Phdr));
    fseek(opfile,e_phoff,0);
    fread(phdr,sizeof(char ), sizeof(Elf32_Phdr), opfile);
    //phdr = (Elf32_Phdr *) opfile;
    fseek(opfile,-1l*e_phoff,0);
    
    return phdr;
    
}

uint32_t count_kernel_sectors(Elf32_Phdr *Phdr)
{
    unsigned int memsz = Phdr->p_memsz;
    return (uint32_t ) (memsz/512 + (memsz%512 != 0));
}

void write_bootblock(FILE *image, FILE *file, Elf32_Phdr *phdr)
{
    int p_offset = (int ) phdr->p_offset;
    int p_filesz = (int ) phdr->p_filesz;
    int p_memsz  = (int ) phdr->p_memsz;
    char tmp[p_memsz];
    memset(tmp,0,sizeof(tmp));
    fseek(file,1l*p_offset,0);
    fread(tmp,sizeof(char),p_filesz,file);
    fwrite(tmp,sizeof(char),p_memsz,image);
    fseek(file,-1l*p_offset,0);
}

void write_kernel(FILE *image, FILE *knfile, Elf32_Phdr *Phdr, uint32_t kernelsz)//kernelsz ?? p_memsz??
{
    int p_offset = (int ) Phdr->p_offset;
    int p_filesz = (int ) Phdr->p_filesz;

    char tmp[kernelsz*0x200];
    memset(tmp,0,sizeof(tmp));
    printf("kernelsz: %d tmp size: %ld\n",kernelsz,sizeof(tmp));
    printf("filesz: %d\n",p_filesz);
    fseek(knfile,1l*p_offset,0);
    fseek(image,1l*0x200,0);
    fread(tmp,sizeof(char),p_filesz,knfile);//printf("1111111111111\n");
    fwrite(tmp,sizeof(char),kernelsz*0x200,image);//printf("2222222222\n");
    fseek(knfile,-1l*p_offset,0);
    fseek(image,-1l*0x200,0);
}

//uint32_t daxiaoduan(uint32_t a){
//    return (a&0xff)<<24 + (a&0xff00)<<8 + (a&0xff0000)>>8 + (a&0xff000000)>>24;
//}

void record_kernel_sectors(FILE *image, uint32_t kernelsz)
{
    kernelsz *= 512;
    //kernelsz = daxiaoduan(kernelsz);
    printf("kernelsz: %d\n",kernelsz);
    fseek(image,1l*0x1fc,0);
    fwrite(&kernelsz,sizeof(uint32_t),1,image);
    fseek(image,-1l*0x1fc,0);
}

void extent_opt(Elf32_Phdr *Phdr_bb, Elf32_Phdr *Phdr_k, uint32_t kernelsz)
{
    puts("BootBlock message:");
    printf("Bootblock image memeory size is 0x%x\n",Phdr_bb->p_memsz);
    printf("Bootblock image memory offset is 0x%x\n",Phdr_bb->p_offset);
    
    puts("kernel message:");
    printf("kernel image memory size is 0x%x\n",Phdr_k->p_memsz);
    printf("kernel image memory offset is 0x%x\n",Phdr_k->p_offset);
    printf("kernel sector size is 0x%x\n",kernelsz);
}

int main()
{
    FILE *image;
    while((image=fopen("image","wb+")) == NULL){
        printf("create file failed, retrying...\n");
    }

    FILE *bb = fopen("bootblock","rb+");
    FILE *ke = fopen("main","rb+");
    
    Elf32_Phdr * phdr_bb = read_exec_file(bb);
    write_bootblock(image,bb,phdr_bb);
    
    Elf32_Phdr * phdr_ke = read_exec_file(ke);
    uint32_t ke_sz = count_kernel_sectors(phdr_ke);
    //printf("ke_sz: %d\n",ke_sz);
    write_kernel(image,ke,phdr_ke,ke_sz);
    record_kernel_sectors(image,ke_sz);
    extent_opt(phdr_bb,phdr_ke,ke_sz);
    
    return 0;
}
*/

/*


#include <assert.h>
#include <elf.h>
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define IMAGE_FILE "./image"
#define ARGS "[--extended] [--vm] <bootblock> <executable-file> ..."

#define SECTOR_SIZE 512
#define OS_SIZE_LOC 2
#define BOOT_LOADER_SIG_OFFSET 0x1fe
#define BOOT_LOADER_SIG_1 0x55
#define BOOT_LOADER_SIG_2 0xaa
#define BOOT_MEM_LOC 0x7c00
#define OS_MEM_LOC 0x1000

/* structure to store command line options 
static struct
{
    int vm;
    int extended;
} options;

/* prototypes of local functions 
static void create_image(int nfiles, char *files[]);
static void error(char *fmt, ...);
static void read_ehdr(Elf32_Ehdr *ehdr, FILE *fp);
static void read_phdr(Elf32_Phdr *phdr, FILE *fp, int ph,
                      Elf32_Ehdr ehdr);
static void write_segment(Elf32_Ehdr ehdr, Elf32_Phdr phdr, FILE *fp,
                          FILE *img, int *nbytes, int *first);
static void write_os_size(int nbytes, FILE *img);

int main(int argc, char **argv)
{
}

static void create_image(int nfiles, char *files[])
{
}

static void read_ehdr(Elf32_Ehdr *ehdr, FILE *fp)
{
}

static void read_phdr(Elf32_Phdr *phdr, FILE *fp, int ph,
                      Elf32_Ehdr ehdr)
{
}

static void write_segment(Elf32_Ehdr ehdr, Elf32_Phdr phdr, FILE *fp,
                          FILE *img, int *nbytes, int *first)
{
}

static void write_os_size(int nbytes, FILE *img)
{
}

/* print an error message and exit 
static void error(char *fmt, ...)
{
}
*/