#ifndef INCLUDE_TEST_H
#define INCLUDE_TEST_H

#include "test5.h"
//#include "sched.h"
#define PSIZE (256)
#define PNUM (256)
#define SEND_BUFFER (0xa1200000)
#define RECV_BUFFER ((SEND_BUFFER) + (PNUM) *( PSIZE))
#define SEND_DESC ((RECV_BUFFER) + (PSIZE + 16) * PNUM)
#define RECV_DESC (SEND_DESC + (16) * PNUM)
#define LAST_RECV_DESC (RECV_DESC+(PNUM-1)*16)

//extern struct task_info *test_tasks[2];

#endif
