//#include "lock.h"
//#include "time.h"
//#include "stdio.h"
//#include "sched.h"
//#include "queue.h"
//#include "screen.h"
#include "lock.h"
#include "time.h"
#include "stdio.h"
#include "sched.h"
#include "queue.h"
#include "syscall.h"
//#include "test.h"
#include "screen.h"
#include "mm.h"
#include "mac.h"

pcb_t pcb[NUM_MAX_TASK];

/* current running task PCB */
pcb_t *current_running;

/* global process id */
pid_t process_id = 1;

extern int screen_cursor_x;
extern int screen_cursor_y;

extern uint32_t time_elapsed;

void print_queue(queue_t * q, int *idx);

static void check_sleeping()
{
    pcb_t *tmp = sleep_queue.head;
    pcb_t *tmp2;
    while(tmp != NULL){
        if(tmp->deadline <= time_elapsed){
            tmp->status = TASK_READY;
            //queue_push(&ready_queue, tmp);
            tmp2 =queue_remove(&sleep_queue, tmp);
            ready_queue_push(tmp);
            tmp = tmp2;
        }else{
            tmp = tmp->next;
        }
    }
}
int i=1;
void scheduler(void)
{
    //int print_location = 4;
    //vt100_move_cursor(1, print_location);
    //printk("Get into scheduler successfully. (%d)\n",i++);
    // TODO schedule
    current_running->cursor_x = screen_cursor_x;
    current_running->cursor_y = screen_cursor_y;

    if(current_running->status != TASK_RUNNING){
        ;
    }else if(current_running != &pcb[0]){
        priority_down(current_running);
        ready_queue_push(current_running);
    }
    irq_mac();
    check_sleeping();
    while(ready_queue_is_empty()){
        start_int();
        check_sleeping();//however, while scheduler, no time_irq, so no time_elapsed inc
    }
    close_int();

    current_running = ready_queue_dequeue();
    //current_running = queue_dequeue(&ready_queue);
    current_running->status = TASK_RUNNING;

    screen_cursor_x = current_running->cursor_x;
    screen_cursor_y = current_running->cursor_y;

    change_enhi_asid(current_running->pid);
    //vt100_move_cursor(1, print_location+1);
    //printk("current_running entrypoint: 0x%x\n",(uint32_t ) current_running->user_context.regs[31]);
    //printk("current_running: 0x%x\n", (uint32_t ) current_running);
    //printk("Scheduler function done\n");
    // Modify the current_running pointer.
}

void print_tlb_excep(void){
    printkf("ATTENTION: tlb exception happened!!!\n");
}

void print_unknown_excep(void){
    printkf("ATTENTION: unkown exception happened!!!\n");
}

void do_sleep(uint32_t sleep_time)
{
    // TODO sleep(seconds)
    //sleep is regarded as a kind of block
    current_running->deadline = time_elapsed + 1*sleep_time;

    do_block(&sleep_queue);
    //epc_add_4();
    //current_running->user_context.cp0_epc += 4;
    do_scheduler();
}

void do_block(queue_t *queue)
{
    current_running->status = TASK_BLOCKED;
    queue_push(queue,current_running);
    // block the current_running task into the queue
}

pcb_t *do_unblock_one(queue_t *queue)
{
    if(queue_is_empty(queue)==0){
        pcb_t * p = queue_dequeue(queue);
        p->status = TASK_READY;
        ready_queue_push(p);
        return p;
        //queue_push(&ready_queue,p);
    }
    return NULL;
    // unblock the head task from the queue
}

void do_unblock_all(queue_t *queue)
{
    while(queue_is_empty(queue)==0){
        pcb_t * p = queue_dequeue(queue);
        p->status = TASK_READY;
        ready_queue_push(p);
        //queue_push(&ready_queue,p);
    }
    //do_ps();
    // unblock all task in the queue
}

void ready_queue_push(pcb_t *item){
    queue_push(&(ready_queue[item->priority]),item);
}

void priority_down(pcb_t *item){
    item->priority = item->priority ?  item->priority-1 : 0;
}

int ready_queue_is_empty(){
    return queue_is_empty(&ready_queue[0]) && queue_is_empty(&ready_queue[1]) && queue_is_empty(&ready_queue[2]);
}

pcb_t *ready_queue_dequeue(){
    if(queue_is_empty(&ready_queue[2])){
        if(queue_is_empty(&ready_queue[1])){
            return queue_dequeue(&ready_queue[0]);
        }
        return queue_dequeue(&ready_queue[1]);
    }
    return queue_dequeue(&ready_queue[2]);
}

void ready_queue_init(){
    int i=0;
    for(;i<3;i++){
        queue_init(&ready_queue[i]);
    }
}

void do_spawn(task_info_t *task)
{
    pid_t pid = 2;
    pcb_t *p;
    while(pid<16 && pcb[pid].tag==1) pid++;
    p = &pcb[pid];
    if(pid==16) {
        printkf("spawn error: no spare pcb space.\n");
        return ;
    }
    uint32_t default_cp0_status = 0x1000ff00;

    memset(p,0,sizeof(pcb_t));
    p->kernel_context.regs[31] = (uint32_t ) int_clear_finish;
    p->kernel_context.cp0_epc = task->entry_point;      
    p->kernel_context.regs[29] = p->kernel_stack_top = KSTACK_BASE - pid * KSTACK_SIZE;
    p->kernel_context.cp0_status = default_cp0_status;

    p->user_context.regs[31] = p->kernel_context.regs[31];
    p->user_context.cp0_epc = task->entry_point;    
    p->user_context.regs[29] = p->user_stack_top =  USTACK_BASE;
    p->user_context.cp0_status = default_cp0_status;

    p->pid = pid;
    p->type = task->type;
    p->status = TASK_READY;
    p->priority = 0;
    p->tag = 1;
    p->name = (task->name);
    ready_queue_push(p);
    //do_ps();
}

void do_kill(pid_t pid){
    if(pid==current_running->pid) do_exit();
    else{
        //printkf("1\n");
        if(pcb[pid].waited==1){//waited
            pcb_t *p = (pcb_t *) wait_queue.head;
            int id = pcb[pid].pid;
            while(p!=NULL){
                if(p->wait == id) {
                    p->status=TASK_READY;

                    pcb_t *p2 = queue_remove(&wait_queue,p);
                    ready_queue_push(p);
                    p = p2;
                }
                else p = p->next;
            } 
        }
        //printkf("2\n");
        int i=0;//release lock
        while(i<16){
            //printkf("in while (%d)\n",i);
            if(pcb[pid].mutex_lock[i] != 0){
                //printkf("in if (%d)\n",i);
                do_mutex_lock_release(pcb[pid].mutex_lock[i]);
            }
            i++;
        }
        //printkf("3\n");
        int flag = 0;//queue
        i=0;
        while(block_queue[i] != NULL && i<16 && flag==0){//block queue
            pcb_t *p = (pcb_t *) block_queue[i]->head;
            while(p!=NULL && flag==0){
                if(p==&pcb[pid]) {
                    queue_remove(block_queue[i],p);
                    flag=1;
                    break;
                }else p=p->next;
            }
            i++;
        }
        //printkf("4\n");
        if(flag==0){//sleep
            pcb_t *p = (pcb_t *) sleep_queue.head;
            while(p!=NULL && flag==0){
                if(p==&pcb[pid]) {
                    queue_remove(&sleep_queue,p);
                    flag=1;
                    break;
                }else p=p->next;
            }
        }
        //printkf("5\n");
        if(flag==0){//wait
            pcb_t *p = (pcb_t *) wait_queue.head;
            while(p!=NULL && flag==0){
                if(p==&pcb[pid]) {
                    queue_remove(&wait_queue,p);
                    flag=1;
                    break;
                }else p=p->next;
            }
        }
        //printkf("6\n");
        i=0;
        while(i<3 && flag==0){//ready
            pcb_t *p = (pcb_t *) ready_queue[i].head;
            while(p!=NULL && flag==0){
                if(p==&pcb[pid]) {
                    queue_remove(&ready_queue[i],p);
                    flag=1;
                    break;
                }else p=p->next;
            }
            i++;
        }
        //printkf("7\n");
        pcb[pid].status = TASK_EXITED;
        pcb[pid].tag = 0;
        //do_ps();
        i=pid%3;
        int j=0;
        for(;j<PTE_ENTRY_NUMBER;j++){
            if(pte[i][j]&0x2) {
                free(pte[i][j]>>6);
                pte[i][j] = 0;
            }
        }
    }
}

void do_exit(void){
    if(current_running->waited==1){
        pcb_t *p = (pcb_t *) wait_queue.head;
        int pid = current_running->pid;
        while(p!=NULL){
            if(p->wait == pid) {
                p->status=TASK_READY;
                pcb_t *p2 = queue_remove(&wait_queue,p);
                ready_queue_push(p);
                p = p2;
            }
            else p = p->next;
        }
    }

    int i=0;
    while(i<16){
        if(current_running->mutex_lock[i] != 0){
            do_mutex_lock_release(current_running->mutex_lock[i]);
        }
        i++;
    }
    
    i=current_running->pid%3;
    int j=0;
    for(;j<PTE_ENTRY_NUMBER;j++){
        if(pte[i][j]&0x2) {
            free(pte[i][j]>>6);
            pte[i][j] = 0;
        }
    }

    current_running->status = TASK_EXITED;
    current_running->tag = 0;
    //do_ps();
    do_scheduler();
}

void do_waitpid(pid_t pid){
    current_running->wait = pid;
    pcb[pid].waited = 1;

    do_block(&wait_queue);
    do_scheduler();
}

pid_t do_getpid(void){
    return current_running->pid;
}

void print_queue(queue_t * q, int *idx){
    pcb_t * p = q->head;
    while(p!=NULL){
        //screen_scroll(SCREEN_HEIGHT / 2 + 1, SCREEN_HEIGHT - 1);
        //screen_reflush();    
        if(p->status==TASK_RUNNING){
            printkf("[%d] PID : %d STATUS : %s\n",(*idx)++, p->pid, "RUNNING");
        }else if(p->status==TASK_BLOCKED){
            printkf("[%d] PID : %d STATUS : %s\n",(*idx)++, p->pid, "BLOCKED");
        }else if(p->status==TASK_READY){
            printkf("[%d] PID : %d STATUS : %s\n",(*idx)++, p->pid, "READY");
        }else{
            printkf("[%d] PID : %d STATUS : %s\n",(*idx)++, p->pid, "UNKNOWN");
        }
        p = p->next;
    }
}
void do_ps(void){
    int idx = 0;
    if(ready_queue_is_empty()==1){
        //screen_scroll(SCREEN_HEIGHT / 2 + 1, SCREEN_HEIGHT - 1);
        //screen_reflush();
        //printkf("ready queue is empty\n");
    }else{
        print_queue(&ready_queue[2],&idx);
        print_queue(&ready_queue[1],&idx);
        print_queue(&ready_queue[0],&idx);
    }
    print_queue(&sleep_queue,&idx);
    print_queue(&wait_queue,&idx);
    int i=0;
    while(i<16){
        //printkf("block_queue[%d]: 0x%x\n",i,block_queue[i]);
        if(block_queue[i]!=0)
            print_queue(block_queue[i],&idx);
        i++;
    }
}

void do_clear(void){
    screen_clear(0,SCREEN_HEIGHT/2-1);
    screen_clear(SCREEN_HEIGHT/2+1, SCREEN_HEIGHT-1);
}
