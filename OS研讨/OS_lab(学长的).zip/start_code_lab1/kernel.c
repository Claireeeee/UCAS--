#define PORT 0xbfe48000

void __attribute__((section(".entry_function"))) _start(void)
{
	// Call PMON BIOS printstr to print message "Hello OS!"
	char str[10] = "Hello OS!"; 
	//((void(*)())0x8007ba00)('H');
	//((void(*)())0x8007ba00)('e');
	//((void(*)())0x8007ba00)('l');
	//((void(*)())0x8007ba00)('l');
	//((void(*)())0x8007ba00)('o');
	//((void(*)())0x8007ba00)(' ');
	//((void(*)())0x8007ba00)('O');
	//((void(*)())0x8007ba00)('S');
	//((void(*)())0x8007ba00)('!');

	((void(*)())0x8007b980)(str);
	while(1)
		;
	return;
}
