#include "time.h"
#include "test3.h"
#include "lock.h"
#include "sched.h"
#include "stdio.h"
#include "syscall.h"

static char blank[] = {"                                                "};

mutex_lock_t lock1;
mutex_lock_t lock2;
mutex_lock_t lock3;

int tmp=0;
// pid = 2
void ready_to_exit_task()
{
    int i = 0, print_location = 0;

    mutex_lock_init(&lock1);
    mutex_lock_init(&lock2);
    mutex_lock_init(&lock3);

    mutex_lock_acquire(&lock1);
    mutex_lock_acquire(&lock2);
    mutex_lock_acquire(&lock3);

    sys_spawn(&task2);
    sys_spawn(&task3);
    sys_spawn(&task4);

    for (i = 0; ; i++)
    {
        sys_move_cursor(0, print_location);
        printf("> [TASK] I am task with pid %d, I have acquired two mutex lock. (%d)\n", current_running->pid, i++);
    }

    sys_exit(); // test exit
}

// pid = 3
void wait_lock_task1()
{
    int i, print_location = 1;

    sys_move_cursor(0, print_location);
    printf("> [TASK] I want to acquire a mute lock1 from task(pid=3).\n");

    mutex_lock_acquire(&lock1);

    sys_move_cursor(0, print_location);
    printf("> [TASK] I have acquired a mutex lock1 from task(pid=3). tmp:%d\n",tmp++);

    sys_exit(); // test exit
}

// pid = 4
void wait_lock_task2()
{
    int i, print_location = 2;

    sys_move_cursor(0, print_location);
    printf("> [TASK] I want to acquire a mute lock2 from task(pid=4).\n");

    mutex_lock_acquire(&lock2);

    sys_move_cursor(0, print_location);
    printf("> [TASK] I have acquired a mutex lock2 from task(pid=4). tmp:%d\n",tmp++);

    sys_exit(); // test exit
}

// pid = 5
void wait_lock_task3()
{
    int i, print_location = 3;

    sys_move_cursor(0, print_location);
    printf("> [TASK] I want to acquire a mute lock3 from task(pid=5).\n");

    mutex_lock_acquire(&lock3);

    sys_move_cursor(0, print_location);
    printf("> [TASK] I have acquired a mutex lock3 from task(pid=5). tmp:%d\n",tmp++);

    sys_exit(); // test exit
}