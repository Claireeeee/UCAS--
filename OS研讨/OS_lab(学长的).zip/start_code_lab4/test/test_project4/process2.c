#include "sched.h"
#include "stdio.h"
#include "syscall.h"
#include "time.h"
#include "screen.h"
#include "test4.h"

#define RW_TIMES 4

int rand()
{	
	int current_time = get_timer();
	return current_time ;
}

static void disable_interrupt()
{
    uint32_t cp0_status = get_cp0_status();
    cp0_status &= 0xfffffffe;
    set_cp0_status(cp0_status);
}

static void enable_interrupt()
{
    uint32_t cp0_status = get_cp0_status();
    cp0_status |= 0x01;
    set_cp0_status(cp0_status);
}

static char read_uart_ch(void)
{
    char ch = 0;
    unsigned char *read_port = (unsigned char *)(0xbfe48000 + 0x00);
    unsigned char *stat_port = (unsigned char *)(0xbfe48000 + 0x05);

    while ((*stat_port & 0x01))
    {
        ch = *read_port;
    }
    return ch;
}

static void scanf(int *mem)
{
	//TODO:Use read_uart_ch() to complete scanf(), read input as a hex number.
	//Extending function parameters to (const char *fmt, ...) as printf is recommended but not required.
		disable_interrupt();
			int i=0;
			char ch,buff[9];
            while(((ch=read_uart_ch()) != 13) && i<9){
                if(ch=='\0') continue;
                if(ch==8   ){//failed, bs is unknown
                    i--; 
                    screen_write_ch(ch);
                    screen_reflush();
                    continue;
                }//backspace
                buff[i++] = ch;
                screen_write_ch(ch);
                screen_reflush();         
            }
            buff[i] = '\0';
            screen_write_ch('\n');
            screen_reflush();       
        enable_interrupt();

		int a=0;i=0;
		while(buff[i]){
			if(buff[i]<='9' && buff[i]>='0')
				a = a*16 + (buff[i]-'0');
			else if(buff[i]<='f' && buff[i]>='a')
				a = a*16 + (buff[i]-'a')+10;
			else if(buff[i]<='F' && buff[i]>='A')
				a = a*16 + (buff[i]-'A')+10;
			else printk("input wrong\n");
			i++;
		}
		*mem = a;
}

void rw_task1(void)
{
	int mem1, mem2 = 0;
	int curs = 1;
	int memory[RW_TIMES];
	int i = 0;
	for(i = 0; i < RW_TIMES; i++)
	{
		vt100_move_cursor(1, curs+i);
		//printk("input: ");
		scanf(&mem1);
		//vt100_move_cursor(1, curs+i);
		memory[i] = mem2 = rand();
		*(int *)mem1 = mem2;
		printk("Write: 0x%x, %d", mem1, mem2);
	}
	curs = RW_TIMES+1;
	for(i = 0; i < RW_TIMES; i++)
	{
		vt100_move_cursor(1, curs+i);
		//printk("output: ");
		scanf(&mem1);
		vt100_move_cursor(1, curs+i);
		memory[i+RW_TIMES] = *(int *)mem1;
		if(memory[i+RW_TIMES] == memory[i])
			printk("Read succeed: %d", memory[i+RW_TIMES]);
		else
			printk("Read error: %d", memory[i+RW_TIMES]);
	}
	while(1);
	//Only input address.
	//Achieving input r/w command is recommended but not required.
}
