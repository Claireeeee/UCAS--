#include "mm.h"
#include "sched.h"
//TODO:Finish memory management functions here refer to mm.h and add any functions you need.

pte_t pte[3][PTE_ENTRY_NUMBER];


uint8_t mem[PAGE_FRAME_NUMBER];

void init_page_table(){
    /*
    int i=0;
    for(;i<PTE_ENTRY_NUMBER;i++)
        pte[i] = (PADDR_BASE+ i%PAGE_FRAME_NUMBER*PAGE_FRAME_SIZE) + 0x2f;
    */
    memset(pte,0,sizeof(pte));
}

void init_TLB(){
    /*
    uint32_t i=0;
    for(;i<TLB_ENTRY_NUMBER;i++){
        uint32_t enlo0 = (pte[2*i]&0xffffff80 + (pte[2*i]&0x7e))>>1;
        uint32_t enlo1 = (pte[2*i+1]&0xffffff80 + (pte[2*i+1]&0x7e))>>1;
        TLBWI(enlo0,enlo1,i);
    }//不再置global位，能够减少进程切换时的消耗
    */
}

void init_swap(){

}

void do_TLB_Refill(uint32_t idx){
    
    static uint32_t tlb_i=0;
    int pid = do_getpid();

    //printk("idx: 0x%X, enhi: 0x%X, pcb-reg29: 0x%X 0x%X\n",idx,get_enhi(),pcb[pid].user_context.regs[29], pcb[pid].kernel_context.regs[29]);

    int _idx = (idx&0x80000000==0) ? idx&0x1f : 0;//(tlb_i++)%32;
   
    pid-=2;
    uint32_t vaddr = pcb[pid+2].user_context.cp0_badvaddr;
    int vpage_number = PNUM(vaddr);
    //printk("pid: %d , vaddr: 0x%X, sp: 0x%X\n",pid,vaddr, get_sp());
    //printk("vaddr page number: 0x%x\n",vpage_number);
    if((pte[pid][vpage_number]&0x2)==0){
        //printk("33333333333333333333\n");
        uint32_t tmp = (uint32_t ) alloc();
        pte[pid][vpage_number] = ((tmp&0xfffff000)>>6) | PTE_C | PTE_D | PTE_V;//phy number for high 12 bit, C(010),D(1),V(1),G(0), for 6 bit
        //printk("tmp: 0x%X\n",tmp);
    }

    //printk("pte[%d][%d]: 0x%X\n",pid, vpage_number, pte[pid][vpage_number]);

    if(vpage_number%2){
        //printk("odd\n");
        TLBWI(pte[pid][vpage_number-1],pte[pid][vpage_number],_idx);
    }else{
        //printk("even\n");
        TLBWI(pte[pid][vpage_number],pte[pid][vpage_number+1],_idx);
    }
    return ;
}

void do_page_fault(){

}

//0xa0f00000-0xa1ffffff
//for user mem, from 0x00f00000-0x001fffff
//th param must be physical addr
void free(uint32_t v){   
    mem[v] = 0;
    
    /*
    struct run *r;
    //printkf("888888888888888\n");
    if((uint32_t)v % PAGE_FRAME_SIZE) printkf("free addr not aligned\n");
    if(mem.is_init)
        r = (struct run*) ((uint32_t)v+0xa0000000);
    else
        r = (struct run*) v;
    r->next = mem.freelist;
    //printkf("999999999999999\n");
    if(mem.is_init)
        mem.freelist = (struct run*) ((uint32_t)r-0xa0000000);
    else
        mem.freelist = (struct run*) r;
    return ;
    */
}

char *alloc(void ){
    
    int i=0;
    for(;i<PAGE_FRAME_NUMBER;i++){
        if(mem[i]==0) {
            mem[i]=1;
            return (char *) (0xf00000+0x1000*i);
        }
    }
    printk("fmem empty");
    return NULL;


    /*
    if(mem.freelist==NULL) {printkf("error: mem run out\n"); return (char *) 0x00f00000;}
    struct run *r;
    r = mem.freelist;
    printk("4444444444444444444\n");
    mem.freelist = ((struct run*)(((uint32_t )r)+0xa0000000))->next;
    printk("1111111111111111111111111111111111\n");
    printk("mem.freelist: 0x%X\n. r: 0x%X\n",mem.freelist,r);

    return (char *) ((uint32_t)(r)+0xffffc);
    */
}

void init_mem(void){
    memset(mem,0,sizeof(mem));
    set_page_mask();
    //0 for free, and 1 for busy
    /*
    mem.freelist = NULL;
    mem.is_init  = 1;
    //printkf("44444444444444444\n");
    free_range((char *)PADDR_BASE,(char *)PADDR_STOP);
    mem.is_init  = 0;
    */
}

void free_range(uint32_t start, uint32_t end){
    //printkf("55555555555555555\n");
    if(start % PAGE_FRAME_SIZE) printkf("free_range error: param start not aligned\n");
    if(end % PAGE_FRAME_SIZE) printkf("free range error: param end not aligned\n");
    //printkf("66666666666666666\n");
    //char *p=(char *) start;
    //for(;p+PAGE_FRAME_SIZE<= (char *)end; p+=PAGE_FRAME_SIZE)
    //    free((p);
    //printkf("77777777777777777\n");
    for(;start<=end;start++){
        free(start);
    }
    return ;
}