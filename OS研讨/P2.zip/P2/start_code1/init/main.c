
#include "lock.h"
#include "time.h"
#include "irq.h"
#include "test.h"
#include "stdio.h"
#include "queue.h"
#include "sched.h"
#include "screen.h"
#include "common.h"
#include "syscall.h"

extern queue_t ready_queue;
extern queue_t block_queue;
#define STACK_BASE 0xa0f00000
#define STACK_SIZE 0x100000//1MB
static void init_pcb()
{
	pcb_t * p;
	queue_init(&ready_queue);
	queue_init(&block_queue);

	int i=0;
	for(;i<5;i++){
		p = &pcb[i];
		memset(p,0,sizeof(pcb_t));		
		p->kernel_context.regs[31] = part1_tasks[i]->entry_point;		
		p->kernel_context.regs[29] = p->kernel_stack_top = STACK_BASE + process_id * STACK_SIZE;


		p->user_context.regs[31] = p->kernel_context.regs[31];
		p->user_context.regs[29] = p->user_stack_top =  p->kernel_context.regs[29];


		p->pid = process_id;
		p->type = part1_tasks[i]->type;
		p->status = TASK_READY;


		queue_push(&ready_queue, p);
		process_id++;

	}
	current_running = &pcb[15];
	(*current_running).pid=-1;
}

static void init_exception_handler()
{
}

static void init_exception()
{
	// 1. Get CP0_STATUS
	// 2. Disable all interrupt
	// 3. Copy the level 2 exception handling code to 0x80000180
	// 4. reset CP0_COMPARE & CP0_COUNT register
}

static void init_syscall(void)
{
	// init system call table.
}

// jump from bootloader.
// The beginning of everything >_< ~~~~~~~~~~~~~~
void __attribute__((section(".entry_function"))) _start(void)
{
	// Close the cache, no longer refresh the cache 
	// when making the exception vector entry copy
	asm_start();

	// init interrupt (^_^)
	init_exception();
	printk("> [INIT] Interrupt processing initialization succeeded.\n");

	// init system call table (0_0)
	init_syscall();
	printk("> [INIT] System call initialized successfully.\n");

	// init Process Control Block (-_-!)
	init_pcb();
	printk("> [INIT] PCB initialization succeeded.\n");

	// init screen (QAQ)
	init_screen();
	printk("> [INIT] SCREEN initialization succeeded.\n");

	// TODO Enable interrupt
	
	while (1)
	{
		// (QAQQQQQQQQQQQ)
		// If you do non-preemptive scheduling, you need to use it to surrender control
		 do_scheduler();
	};
	return;
}

