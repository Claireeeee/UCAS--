#include "lock.h"
#include "sched.h"
#include "common.h"
#include "screen.h"
#include "syscall.h"
extern int (*syscall_handler[NUM_SYSCALLS])();

void system_call_helper(int fn, int arg1, int arg2, int arg3)
{
    // syscall[fn](arg1, arg2, arg3)
    if(fn < 0 || fn >= NUM_SYSCALLS)
        fn = 0;
    //处理完毕，返回值放入regs[2]
    current_running->user_context.regs[2] = syscall_handler[fn](arg1, arg2, arg3);
    //为什么+4？ 这条指令调用了syscall，而且已经处理完毕，所以+4？
    current_running->user_context.cp0_epc += 4;
}

void sys_sleep(uint32_t time)
{
    invoke_syscall(SYSCALL_SLEEP, time, IGNORE, IGNORE);
}

void sys_block(queue_t *queue)
{
    invoke_syscall(SYSCALL_BLOCK, (int)queue, IGNORE, IGNORE);
}

void sys_unblock_one(queue_t *queue)
{
    invoke_syscall(SYSCALL_UNBLOCK_ONE, (int)queue, IGNORE, IGNORE);
}

void sys_unblock_all(queue_t *queue)
{
    invoke_syscall(SYSCALL_UNBLOCK_ALL, (int)queue, IGNORE, IGNORE);
}

void sys_write(char *buff)
{
    invoke_syscall(SYSCALL_WRITE, (int)buff, IGNORE, IGNORE);
}

void sys_reflush()
{
    invoke_syscall(SYSCALL_REFLUSH, IGNORE, IGNORE, IGNORE);
}

void sys_move_cursor(int x, int y)
{
    invoke_syscall(SYSCALL_CURSOR, x, y, IGNORE);
}

void mutex_lock_init(mutex_lock_t *lock)
{
    invoke_syscall(SYSCALL_MUTEX_LOCK_INIT, (int)lock, IGNORE, IGNORE);
}

void mutex_lock_acquire(mutex_lock_t *lock)
{
    invoke_syscall(SYSCALL_MUTEX_LOCK_ACQUIRE, (int)lock, IGNORE, IGNORE);
}

void mutex_lock_release(mutex_lock_t *lock)
{
    invoke_syscall(SYSCALL_MUTEX_LOCK_RELEASE, (int)lock, IGNORE, IGNORE);
}

//do the sysy call
void do_sys_others(void){
    printk("Error: Invalide Syscall\n");
}

void do_sys_sleep(uint32_t sleep_time){
    do_sleep(sleep_time);
}

void do_sys_block(queue_t *queue){
    do_block(queue);
}

void do_sys_unblock_one(queue_t *queue){
    do_unblock_one(queue);
}

void do_sys_unblock_all(queue_t *queue){
    do_unblock_all(queue);
}

void do_sys_write(char *buff){
    screen_write(buff);
    screen_reflush();
}

void do_sys_move_cursor(int x, int y){
    screen_move_cursor(x, y);
}

void do_sys_reflush(void){
    screen_reflush();   
}

void do_sys_mutex_lock_init(mutex_lock_t *mutex){
    do_mutex_lock_init(mutex);
}

void do_sys_mutex_lock_acquire(mutex_lock_t *mutex){
    do_mutex_lock_acquire(mutex);
}

void do_sys_mutex_lock_release(mutex_lock_t *mutex){
    do_mutex_lock_release(mutex);
}
