#include "lock.h"
#include "time.h"
#include "stdio.h"
#include "sched.h"
#include "queue.h"
#include "syscall.h"
#include "test2.h"
#include "screen.h"

pcb_t pcb[NUM_MAX_TASK];

/* current running task PCB */
pcb_t *current_running;

/* global process id */
pid_t process_id = 1;
extern uint32_t time_elapsed;
extern int screen_cursor_x;
extern int screen_cursor_y;

static void check_sleeping()
{
    pcb_t *sh = sleep_queue.head;

    while(sh != NULL){
        if(sh->sleepto <= time_elapsed){
            sh->status = TASK_READY;
            queue_push(&(ready_queue[sh->priority]),sh);
            //ready_queue_push(sh);
            sh = queue_remove(&sleep_queue, sh);
        }else{
            sh = sh->next;
        }
    }
}

void scheduler(void)
{
    check_sleeping();
    if((current_running->status ==TASK_RUNNING))  {   	
        current_running->status = TASK_READY;
        if (current_running->priority>0){
            current_running->priority -= 1;    //优先级降，or重新放回最高
        }
        else current_running->priority =2;
        queue_push(&(ready_queue[current_running->priority]),current_running);  //2，1，0
    }

    	current_running->cursor_x = screen_cursor_x;
    	current_running->cursor_y = screen_cursor_y;
//切换
int i=2;
for (; ; )
{
    while((i>=0)&&queue_is_empty(&(ready_queue[i]))) {   //2，1，0
        i--;
    };
    if(i<0){
        start_int();  
        check_sleeping();
    }
    else break;
}
    close_int();

    current_running = queue_dequeue(&(ready_queue[i]));
    current_running->status = TASK_RUNNING;
//printk("\n**********id:%d,time_slice:%d\n",current_running->pid,current_running->time_slice);

    screen_cursor_x = current_running->cursor_x;
    screen_cursor_y = current_running->cursor_y;
//printk("\n******id: %d, status: %d********\n",(*current_running).pid,(*current_running).status);
}

void do_sleep(uint32_t sleep_time)
{
    //printk("hello sleep!!!!!!11");
    current_running->status = TASK_BLOCKED;
    current_running->sleepto = time_elapsed + sleep_time;
    queue_push(&sleep_queue, current_running);
    do_scheduler();
}

void do_block(queue_t *queue)
{
    current_running->status = TASK_BLOCKED;
    queue_push(queue,current_running);
}

void do_unblock_one(queue_t *queue)
{
    if(queue_is_empty(queue)==0){
        pcb_t * p = queue_dequeue(queue);
        p->status = TASK_READY;
        queue_push(&(ready_queue[p->priority]),p);
    }
}

void do_unblock_all(queue_t *queue)
{
    while(queue_is_empty(queue)==0){
        pcb_t * p = queue_dequeue(queue);
        p->status = TASK_READY;
        //ready_queue_push(p);
        queue_push(&(ready_queue[p->priority]),p);
    }
}
