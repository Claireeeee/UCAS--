#include "lock.h"
#include "time.h"
#include "irq.h"
#include "test.h"
#include "stdio.h"
#include "queue.h"
#include "sched.h"
#include "screen.h"
#include "common.h"
#include "syscall.h"

extern queue_t ready_queue[3];
extern queue_t *block_queue[10];

#define STACK_BASE 0xa0f00000
#define STACK_SIZE   0x100000  //1MB
uint32_t exception_handler[32];
extern int (*syscall_handler[NUM_SYSCALLS])();


static void init_pcb()
{
	pcb_t * p;
	int i=0;
	for(;i<3;i++){
	queue_init(&(ready_queue[i]));
	}
	memset(block_queue,0,sizeof(block_queue));  //block_queue数组的初始化
	queue_init(&wait_queue);
	queue_init(&sleep_queue);

    for (i = 0; i < 16; i++)
    {
    	pcb[i].status=TASK_EXITED;
    }
//printk("init pcb\n");
		p = &pcb[1];
		memset(p,0,sizeof(pcb_t));		
		p->kernel_context.regs[31] = (uint32_t )exception_exit;		
		p->kernel_context.regs[29] = p->kernel_stack_top =STACK_BASE + 1 * STACK_SIZE;

		//new:
		p->kernel_context.cp0_epc = (uint32_t ) test_shell;		
		p->kernel_context.cp0_status=0x30008003;

		p->user_context.regs[31] = p->kernel_context.regs[31];
		p->user_context.regs[29] = p->user_stack_top =  STACK_BASE +(0+1)*STACK_SIZE;
		p->user_context.cp0_epc = (uint32_t ) test_shell;		
		p->user_context.cp0_status=0x30008003;

	p->pid = 0;
	p->type = USER_PROCESS;
	p->status = TASK_READY;
	p->priority = 2;
	p->name = "shell";
	queue_push(&(ready_queue[2]), p);
	p->time_slice=TIMER_INTERVAL;  //1,2,3 time slice

	current_running = &pcb[0];
	(*current_running).pid=-1;


}

static void init_exception_handler()
{
	int i = 0;
	for(;i<32;++i){
		exception_handler[i] = (uint32_t ) handle_other;
	}
	exception_handler[0] = (uint32_t ) handle_int;
	exception_handler[8] = (uint32_t ) handle_syscall;
}

static void init_exception()
{
	// 1. Get CP0_STATUS
	// 2. Disable all interrupt
	// 3. Copy the level 2 exception handling code to 0x80000180
	// 4. reset CP0_COMPARE & CP0_COUNT register

	init_exception_handler();
	bzero(0x80000000, 0x180);
	memset(0x80000180, 0, (uint32_t ) (exception_handler_end - exception_handler_begin));
	memcpy((uint8_t *) 0x80000180, (uint8_t *)exception_handler_entry, (uint32_t ) (exception_handler_end - exception_handler_begin));

	reset_cp0s(TIMER_INTERVAL);
}

static void init_syscall(void)
{
	int i;
	for(i=0;i<NUM_SYSCALLS;i++){
		syscall_handler[i] = (int (*)()) do_sys_others;
	}
	syscall_handler[SYSCALL_SLEEP] = (int (*)()) do_sys_sleep;
	syscall_handler[SYSCALL_BLOCK] = (int (*)()) do_sys_block;
	syscall_handler[SYSCALL_UNBLOCK_ONE] = (int (*)()) do_sys_unblock_one;
	syscall_handler[SYSCALL_UNBLOCK_ALL] = (int (*)()) do_sys_unblock_all;
	syscall_handler[SYSCALL_WRITE] = (int (*)()) do_sys_write;
	syscall_handler[SYSCALL_CURSOR] = (int (*)()) do_sys_move_cursor;
	syscall_handler[SYSCALL_REFLUSH] = (int (*)()) do_sys_reflush;
	syscall_handler[SYSCALL_MUTEX_LOCK_INIT] = (int (*)()) do_sys_mutex_lock_init;
	syscall_handler[SYSCALL_MUTEX_LOCK_ACQUIRE] = (int (*)()) do_sys_mutex_lock_acquire;
	syscall_handler[SYSCALL_MUTEX_LOCK_RELEASE] = (int (*)()) do_sys_mutex_lock_release;
	syscall_handler[SYSCALL_PS] = (int (*)()) do_sys_ps;
	syscall_handler[SYSCALL_CLEAR] = (int (*)()) do_sys_clear;
	syscall_handler[SYSCALL_SPAWN] = (int (*)()) do_sys_spawn;
	syscall_handler[SYSCALL_KILL]  = (int (*)()) do_sys_kill;
	syscall_handler[SYSCALL_EXIT] = (int (*)()) do_sys_exit;
	syscall_handler[SYSCALL_WAITPID] = (int (*)()) do_sys_waitpid;
	syscall_handler[SYSCALL_GETPID] = (int (*)()) do_sys_getpid;
	syscall_handler[SYSCALL_SEMAPHORE_INIT] = (int (*)()) do_sys_semaphore_init;
	syscall_handler[SYSCALL_SEMAPHORE_UP] = (int (*)()) do_sys_semaphore_up;
	syscall_handler[SYSCALL_SEMAPHORE_DOWN] = (int (*)()) do_sys_semaphore_down;
	syscall_handler[SYSCALL_BARRIER_INIT] = (int (*)()) do_sys_barrier_init;
	syscall_handler[SYSCALL_BARRIER_WAIT] = (int (*)()) do_sys_barrier_wait;
	syscall_handler[SYSCALL_CONDITION_INIT] = (int (*)()) do_sys_condition_init;
	syscall_handler[SYSCALL_CONDITION_SIGNAL] = (int (*)()) do_sys_condition_signal;
	syscall_handler[SYSCALL_CONDITION_BROADCAST] = (int (*)()) do_sys_condition_broadcast;
	syscall_handler[SYSCALL_CONDITION_WAIT] = (int (*)()) do_sys_condition_wait;

}

// jump from bootloader.
// The beginning of everything >_< ~~~~~~~~~~~~~~
void __attribute__((section(".entry_function"))) _start(void)
{
	// Close the cache, no longer refresh the cache 
	// when making the exception vector entry copy
	asm_start();

	// init interrupt (^_^)
	init_exception();
	printk("> [INIT] Interrupt processing initialization succeeded.\n");

	// init system call table (0_0)
	init_syscall();
	printk("> [INIT] System call initialized successfully.\n");

	// init Process Control Block (-_-!)
	init_pcb();
	printk("> [INIT] PCB initialization succeeded.\n");

	// init screen (QAQ)
	init_screen();
	printk("> [INIT] SCREEN initialization succeeded.\n");
	screen_clear(0,SCREEN_HEIGHT-1);
	printk("> HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHhhh.\n");

	// TODO Enable interrupt
	do_sscheduler();
	return;
}

