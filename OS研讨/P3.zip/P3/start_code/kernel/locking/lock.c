#include "lock.h"
#include "sched.h"
#include "syscall.h"
extern pcb_t *current_running;

int blockqueue_register(queue_t *queue){
    int i=0;
    while(block_queue[i]!=queue && block_queue[i]!= NULL && i<NUM_MAX_LOCK) i++;
    if(i==NUM_MAX_LOCK){
        printkf("block error: no space in block space");
        return;
    }
    block_queue[i] = queue;
    return i;
}

void spin_lock_init(spin_lock_t *lock)
{
    lock->status = UNLOCKED;
}

void spin_lock_acquire(spin_lock_t *lock)
{
    while (LOCKED == lock->status)
    {
    };
    lock->status = LOCKED;
}

void spin_lock_release(spin_lock_t *lock)
{
    lock->status = UNLOCKED;
}

void do_mutex_lock_init(mutex_lock_t *lock)
{
    lock->status = UNLOCKED;
    queue_init(&lock->queue);
    lock->index=blockqueue_register(&lock->queue);
}

void do_mutex_lock_acquire(mutex_lock_t *lock)
{
    while(lock->status == LOCKED){
        current_running->status=TASK_BLOCKED;
        do_block(&lock->queue);
        //do_scheduler();                //等下一次调度回来，继续获取
    }
    lock->status = LOCKED;
    int i=0;
    while(current_running->mutex_lock[i] != 0 && i<NUM_MAX_LOCK) i++;
    if(i<NUM_MAX_LOCK) current_running->mutex_lock[i] = lock;
    else printkf("this process has got 10 mutex_locks!!!\n");

}

void do_mutex_lock_release(mutex_lock_t *lock)
{
    
    lock->status = UNLOCKED;
    do_unblock_all(&lock->queue);

    int i=0;
    while(i<NUM_MAX_LOCK){  
        if(current_running->mutex_lock[i] == lock){
            current_running->mutex_lock[i] = 0;
            break;
        }
        i++;
    } 

}

