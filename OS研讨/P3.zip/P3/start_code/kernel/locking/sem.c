#include "sem.h"
#include "stdio.h"
#include "lock.h"
#include "sched.h"
void do_semaphore_init(semaphore_t *s, int val)
{
	s->value=val;
	queue_init(&s->queue);
	s->index=blockqueue_register(&s->queue);
}

void do_semaphore_up(semaphore_t *s)
{
    s->value += 1;
    if(s->value<=0)
    	do_unblock_one(&s->queue);
}

void do_semaphore_down(semaphore_t *s)
{
    s->value -= 1;
    while(s->value < 0){
	//
        current_running->status=TASK_BLOCKED;
        do_block(&s->queue);
        //do_scheduler();
    }


}
