#include "barrier.h"
#include "lock.h"

void do_barrier_init(barrier_t *barrier, int goal)
{
    //printkf("1\n");
    add_queue_to_block(&(barrier->queue));
    //printkf("2\n");
    queue_init(&(barrier->queue));
    //printkf("3\n");
    barrier->goal = goal;
    barrier->value = 0;
}

void do_barrier_wait(barrier_t *barrier)
{
    barrier->value += 1;
    //printf("value: %d\n",barrier->value);
    if(barrier->value >= barrier->goal){
        do_unblock_all(&(barrier->queue));
        barrier->value = 0;
    }else{
        do_block(&(barrier->queue));
        do_scheduler();
    }
}