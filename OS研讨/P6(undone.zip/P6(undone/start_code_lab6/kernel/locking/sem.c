#include "sem.h"
#include "stdio.h"
#include "lock.h"

void do_semaphore_init(semaphore_t *s, int val)
{
    queue_init(&s->queue);
    s->value = val;
}

void do_semaphore_up(semaphore_t *s)
{
    //printkf("in sema_up\n");
    s->value += 1;
    //if(s->value==1){
    do_unblock_all(&s->queue);
    //}
    //printkf("out sema_up\n");
}

void do_semaphore_down(semaphore_t *s)
{
    while(s->value == 0){
        do_block(&s->queue);
        do_scheduler();
    }
    s->value -= 1;
}