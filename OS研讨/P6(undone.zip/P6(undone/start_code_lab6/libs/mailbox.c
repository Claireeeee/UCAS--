#include "string.h"
#include "mailbox.h"
#include "lock.h"

#define MAX_NUM_BOX 32

static mailbox_t mboxs[MAX_NUM_BOX];
static mutex_lock_t mutex;

void mbox_init()
{
    memset(mboxs,0,sizeof(mboxs));
    do_mutex_lock_init(&mutex);
}

mailbox_t *mbox_open(char *name)
{
    do_mutex_lock_acquire(&mutex);
    int i=0,flag=0;
    while(i<32 & flag==0){
        if(mboxs[i].used == 0) ;
        else if(strcmp(name,mboxs[i].name)==0){
            mboxs[i].status = OPEN;
            flag=1;
            do_mutex_lock_release(&mutex);
            return &mboxs[i];
        }
        i++;
    }
    if(flag==0){
        i=0;
        while(i<32){
            if(mboxs[i].used == 0){
                flag=1;
                memset(&mboxs[i],0,sizeof(mboxs[i]));
                mboxs[i].used=1;
                mboxs[i].status = OPEN;
                mboxs[i].head = mboxs[i].tail = 0;
                mboxs[i].empty=1;
                strcpy(mboxs[i].name,name);
                queue_init(&mboxs[i].queue);
                add_queue_to_block(&mboxs[i].queue);
                do_mutex_lock_release(&mutex);
                return &mboxs[i];
            }
            i++;
        }
    }
    if(flag==0) {
        printkf("mboxs open error: mboxs is full\n");
        do_mutex_lock_release(&mutex);
    }
}

void mbox_close(mailbox_t *mailbox)
{
    mailbox->status = CLOSED;
}

void mbox_send(mailbox_t *mailbox, void *msg, int msg_length)
{
    //printf("1\n");
    do_mutex_lock_acquire(&mutex);
    //printf("3\n");
    char *_msg = (char *)msg;
    int i=0;
    while(mailbox->full==0 && i<msg_length){
        while(mailbox->full==1) {
            do_mutex_lock_release(&mutex);
            do_block(&mailbox->queue);
            do_scheduler();
            mailbox->full = (mailbox->tail==mailbox->head) && !mailbox->empty;
            do_mutex_lock_acquire(&mutex);
        }
        do_unblock_all(&mailbox->queue);
        mailbox->empty = 0;
        mailbox->message[mailbox->tail] = *(_msg++);
        mailbox->tail = (mailbox->tail+1) % MBOXVOLUME;
        mailbox->full = mailbox->tail==mailbox->head;
        i++;
    }
    do_mutex_lock_release(&mutex);
    //printf("2\n");
}

void mbox_recv(mailbox_t *mailbox, void *msg, int msg_length)
{
    do_mutex_lock_acquire(&mutex);
    char *_msg = (char *) msg;
    int i=0;
    while(i<msg_length){
        while(mailbox->empty==1){
            //printf("1\n");
            do_mutex_lock_release(&mutex);
            do_block(&mailbox->queue);
            do_scheduler();
            mailbox->empty = (mailbox->tail==mailbox->head) && !mailbox->full;
            do_mutex_lock_acquire(&mutex);
        }
        do_unblock_all(&mailbox->queue);
        mailbox->full=0;
        *(_msg++) = mailbox->message[mailbox->head];
        mailbox->head = (mailbox->head+1) % MBOXVOLUME;
        mailbox->empty = mailbox->head == mailbox->tail;
        i++;
    }
    do_mutex_lock_release(&mutex);
}