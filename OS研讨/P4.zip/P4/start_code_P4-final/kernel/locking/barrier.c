#include "barrier.h"
#include "queue.h"
#include "sched.h"
void do_barrier_init(barrier_t *barrierad, int goal)
{
    queue_init(&barrierad->queue);
    barrierad->goal = goal;
    barrierad->value = 0;
    barrierad->index=blockqueue_register(&barrierad->queue);
}

void do_barrier_wait(barrier_t *barrierad)
{
    barrierad->value += 1;
    if(barrierad->value >= barrierad->goal){
        do_unblock_all(&barrierad->queue);
        barrierad->value = 0;
    }else{
        current_running->status=TASK_BLOCKED;
	do_block(&barrierad->queue);
        //do_scheduler();
    }
}
