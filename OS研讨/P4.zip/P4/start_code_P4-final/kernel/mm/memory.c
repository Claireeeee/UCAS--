#include "mm.h"
#include "sched.h"
#include "queue.h"
pte_t pt_table[NUM_MAX_TASK][PTE_ENTRY_NUMBER];   
typedef struct pool_e{
    void* pre;
    void* next;
    int index;
}ple_t;    //12byte

ple_t page_frame[PAGE_FRAME_NUMBER/2];  //2^13/2 = 0x1000,16M infact
ple_t pool_head;
ple_t pool_tail;


void init_page_table(){
    memset(pt_table,0,sizeof(pt_table));
}

void init_page_frame(void){
    memset(page_frame,0,sizeof(page_frame));
    set_page_mask();

    pool_head.pre=NULL;
    pool_head.next=&(page_frame[0]);
    int i;
    ple_t *pre=&pool_head;
    ple_t *p=pre->next;
    for (i=0; i <PAGE_FRAME_NUMBER/2-1; i++)
    {
        p->pre=pre;
        p->next=&(page_frame[i+1]);
        p->index=i;
        pre=p;
        p=p->next;
    }
    page_frame[i].index=i;
    page_frame[i].pre=pre;
    page_frame[i].next=&pool_tail;
    pool_tail.pre=&(page_frame[i]);
    pool_tail.next=NULL;
}

void init_TLB(){
}

void init_swap(){

}

void do_TLB_Refill(uint32_t index){
    
    static int tlb_i=0;
    int pid = do_getpid();
    int _index = (index&0x80000000==0) ? index&0x1f : (tlb_i++)%32;   //miss: new; invalid:index

   
    uint32_t vaddr = pcb[pid].user_context.cp0_badvaddr;
    int vpage_number = V_2_PNUM(vaddr);  //slr 12bit

    if((pt_table[pid][vpage_number]&0x2)==0){
        uint32_t addr = (uint32_t ) frame_alloc();
        pt_table[pid][vpage_number] = ((addr&0xfffff000)>>6) | PTE_C | PTE_D | PTE_V;
    }

    if(vpage_number%2){
        //odd
        tlbwi_func(pt_table[pid][vpage_number-1],pt_table[pid][vpage_number],_index);
    }else{
        //even
        tlbwi_func(pt_table[pid][vpage_number],pt_table[pid][vpage_number+1],_index);
    }
}

void frame_free(uint32_t v){
    //page_frame[v] = 0;
    ((ple_t*)pool_tail.pre)->next=&(page_frame[v]);
    page_frame[v].pre=pool_tail.pre;
    page_frame[v].next=&pool_tail;
    pool_tail.pre=&(page_frame[v]);
}

char *frame_alloc(void ){
    
    /*int i=0;
    for(;i<PAGE_FRAME_NUMBER;i++){
        if(page_frame[i]==0) {
            page_frame[i]=1;
            return (char *) (0xf00000+0x1000*i);
        }
    }*/
    if (pool_head.next!=&pool_tail)
    {
        int idx=((ple_t*)pool_head.next)->index;
        pool_head.next=((ple_t*)pool_head.next)->next;
        ((ple_t*)pool_head.next)->pre=&pool_head;
        return (char *) (0xf00000+0x1000*idx);
    }
    else {
    printk("memory empty");
    sys_exit();
    return NULL;
    }
}

void free_range(uint32_t start, uint32_t end){
    if(start % PAGE_FRAME_SIZE) printkf("free_range error: param start not aligned\n");
    if(end % PAGE_FRAME_SIZE) printkf("free range error: param end not aligned\n");
    for(;start<=end;start++){
        frame_free(start);
    }
}
