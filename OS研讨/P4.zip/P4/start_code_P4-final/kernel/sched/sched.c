#include "lock.h"
#include "time.h"
#include "stdio.h"
#include "sched.h"
#include "queue.h"
#include "syscall.h"
#include "screen.h"
#include "irq.h"
#include "mm.h"
//#include "test.h"
pcb_t pcb[NUM_MAX_TASK];

/* current running task PCB */
pcb_t *current_running;
void print_q(queue_t * q, int *proindex);
/* global process id */
//pid_t process_id = 1;
extern uint32_t time_elapsed;
extern int screen_cursor_x;
extern int screen_cursor_y;

static void check_sleeping()
{
    pcb_t *sh = sleep_queue.head;
     pcb_t *shh;
    while(sh != NULL){
        if(sh->sleepto <= time_elapsed){
            sh->status = TASK_READY;
            shh = queue_remove(&sleep_queue, sh);
            queue_push(&(ready_queue[sh->priority]),sh);
	    sh=shh;
        }else{
            sh = sh->next;
        }
    }
}

void scheduler(void)
{

    	current_running->cursor_x = screen_cursor_x;
    	current_running->cursor_y = screen_cursor_y;

    check_sleeping();

    if((current_running->status ==TASK_RUNNING))  {   	
        current_running->status = TASK_READY;
        if (current_running->priority>0){
            current_running->priority -= 1;    //优先级降，or重新放回最高
        }
        else current_running->priority =2;
        queue_push(&(ready_queue[current_running->priority]),current_running);  //2，1，0
    }

//切换
	int i=2;
	for (; ; )
	{
	    i=2;
	    while((i>=0)&&queue_is_empty(&(ready_queue[i]))) {   //2，1，0
		i--;
	    };
	    if(i<0){
		//start_int();  
		//check_sleeping();
	    }
	    else break;
	}

    close_int();

    current_running = queue_dequeue(&(ready_queue[i]));
    current_running->status = TASK_RUNNING;

    screen_cursor_x = current_running->cursor_x;
    screen_cursor_y = current_running->cursor_y;
    change_enhi_asid(current_running->pid);
}

void do_sleep(uint32_t sleep_time)
{
    //printk("hello sleep!!!!!!11");
    current_running->status = TASK_SLEEP;
    current_running->sleepto = time_elapsed + sleep_time;
    do_block(&sleep_queue);

    //do_scheduler();
}

void do_ps(void){
    int i=2;
    while((i>=0)&&queue_is_empty(&(ready_queue[i]))) {   //2，1，0
        i--;
    };
    int proindex = 0;
    /*if(i<0){
        //screen_scroll(SCREEN_HEIGHT / 2 + 1, SCREEN_HEIGHT - 1);
        //screen_reflush();
        printkf("No process is ready\n");
    }else{*/
        print_q(&ready_queue[2],&proindex );
        //printkf("ready queue 2\n");
        print_q(&ready_queue[1],&proindex );
        //printkf("ready queue 1\n");
        print_q(&ready_queue[0],&proindex );
        //printkf("ready queue 0\n");
    /*}*/
    print_q(&sleep_queue,&proindex );
        //printkf("sleep queue 1\n");
    print_q(&wait_queue,&proindex );
        //printkf("wait queue 1\n");
    i=0;
    while(i<NUM_MAX_LOCK){
        //printkf("block_queue[%d]: 0x%x\n",i,block_queue[i]);
        if(block_queue[i]!=0){
            print_q(block_queue[i],&proindex);
            //printkf("block queue %d\n",i);
	}
        i++;
    }
}

void print_q(queue_t * q, int *proindex){
    pcb_t * p = q->head;
    while(p!=NULL){
        //screen_scroll(SCREEN_HEIGHT / 2 + 1, SCREEN_HEIGHT - 1);
        //screen_reflush();
        switch(p->status)
        {
            case TASK_RUNNING:
                printkf("[%d] PID : %d STATUS : %s\n",(*proindex)++, p->pid, "RUNNING");
                break;
            case TASK_BLOCKED:
                printkf("[%d] PID : %d STATUS : %s\n",(*proindex)++, p->pid, "BLOCKED");
                break;
            case TASK_READY:
                printkf("[%d] PID : %d STATUS : %s\n",(*proindex)++, p->pid, "READY");
                break;
            case TASK_SLEEP:
                printkf("[%d] PID : %d STATUS : %s\n",(*proindex)++, p->pid, "SLEEP");
                break;
            case TASK_WAIT:
                printkf("[%d] PID : %d STATUS : %s\n",(*proindex)++, p->pid, "WAIT");
                break;
            default :
                printkf("[%d] PID : %d STATUS : %s\n",(*proindex)++, p->pid, "UNKNOWN");
        }
        p = p->next;
    }
}


void do_clear(void){
    //为什么不直接全清
    screen_clear(0,SCREEN_HEIGHT/2-1);
    screen_clear(SCREEN_HEIGHT/2+1, SCREEN_HEIGHT-1);
}

void do_spawn(int *sys_argvs)  //找一个空的pcb，用进程信息初始化
{
    pid_t pid = 2;
    pcb_t *p;
    task_info_t task=*((task_info_t*)sys_argvs[0]);
    while(pid<16 && pcb[pid].status!=TASK_EXITED) pid++;  //找空位

    if(pid==16) {
        printkf("spawn error: no space in ptable.\n");
    }
    else{
        p = &pcb[pid];
        memset(p,0,sizeof(pcb_t));      
        p->kernel_context.regs[31] = (uint32_t )exception_exit;     
        p->kernel_context.regs[29] = KSTACK_TOP - pid * KSTACK_SIZE;
	//memset(STACK_BASE + pid * STACK_SIZE,0,STACK_SIZE);   
	//memset(STACK_BASE + (pid+16) * STACK_SIZE,0,STACK_SIZE);   
        p->kernel_stack_top =  KSTACK_TOP - pid * KSTACK_SIZE;
        p->kernel_context.cp0_epc = task.entry_point;
        p->kernel_context.cp0_status=0x30008003;
        
        p->user_context.regs[31] = (uint32_t )exception_exit;
        p->user_context.regs[29] = USTACK_TOP;
        p->user_stack_top =  USTACK_TOP;
        p->user_context.cp0_epc = task.entry_point;
        p->user_context.cp0_status=0x30008003;
        p->user_context.regs[4]=(uint32_t )&(sys_argvs[1]);
        p->pid = pid;
        p->type = task.type;
        p->status = TASK_READY;
        p->name = task.name;
        p->priority=2;      //2,1,0
	p->wait=-1;
        p->time_slice=TIMER_INTERVAL*(1+(pid%3));  //1,2,3 time slice
        p->page_table=(pt_t *)pt_table[pid];
        queue_push(&(ready_queue[2]), p);
    }
}


void do_kill(pid_t pid){
    if(pid==current_running->pid) do_exit();  //如果是当前进程，进exit函数处理
    else{
        //printkf("1\n");
        int wait_cnt=pcb[pid].waited;
        if(wait_cnt>0){   //唤醒正在等待当前进程的进程
            pcb_t *p = (pcb_t *) wait_queue.head;
            while(p!=NULL && wait_cnt>0){
                if(p->wait == pid) { 
                    p->status=TASK_READY;
		    p->wait=-1;
                    pcb_t *p2 = queue_remove(&wait_queue,p);  //返回移除后的下一个
                    queue_push(&(ready_queue[p->priority]), p);
                    p = p2;
                    wait_cnt--;
                }
                else p = p->next;
            }
        }

        //release lock
        int i=0;
        while(i<NUM_MAX_LOCK){
            //printkf("in while (%d)\n",i);
            if(pcb[pid].mutex_lock[i] != 0){
                //printkf("in if (%d)\n",i);
                do_mutex_lock_release(pcb[pid].mutex_lock[i]);
		pcb[pid].mutex_lock[i] = 0;
            }
            i++;
        }

        //如果是block，sleep，wait，或ready队列中的进程
        //block状态包括：锁block队列，sleep队列，wait队列

        switch(pcb[pid].status)
        {
            case TASK_BLOCKED:
                {
                    int i=0,flag=0;
                    pcb_t *p;
                    while(block_queue[i] != NULL && i<NUM_MAX_LOCK && flag==0)
                    {//block queue
                        p = (pcb_t *) block_queue[i]->head;
                        while(p!=NULL && flag==0){
                            if(p==&pcb[pid]) {
                                flag=1;
                                queue_remove(block_queue[i],p);
                                break;
                            }
                            else p=p->next;
                        }
                        i++;
                    }
                    break;
                }
            case TASK_SLEEP:
                {
                    pcb_t *p = (pcb_t *) sleep_queue.head;
                    while(p!=NULL){
                        if(p==&pcb[pid]) {
                            queue_remove(&sleep_queue,p);
                            break;
                        }
                        else p=p->next;
                    }
                    break;
                }
            case TASK_WAIT:
                {
                    pcb_t *p = (pcb_t *) wait_queue.head;
                    while(p!=NULL){
                        if(p==&pcb[pid]) {
                            queue_remove(&wait_queue,p);
                            break;
                        }else p=p->next;
                    }
                    break;
                }
            case TASK_READY:
                {
                    int i=0;
                    int flag=0;
                    while(i<3 && flag==0){//ready
                        pcb_t *p = (pcb_t *) ready_queue[i].head;
                        while(p!=NULL && flag==0){
                            if(p==&pcb[pid]) {
                                queue_remove(&ready_queue[i],p);
                                flag=1;
                                break;
                            }
                            else p=p->next;
                        }
                        i++;
                    }
                    break;
                }
            default :
		break;
        }
        i=pid;
        int j=0;
        for(;j<PTE_ENTRY_NUMBER;j++){
            if(pt_table[i][j]&0x2) {
                frame_free(pt_table[i][j]>>6);
                pt_table[i][j] = 0;
            }
        }
        pcb[pid].status = TASK_EXITED;
    }
}

void do_exit(void){
    int wait_cnt=current_running->waited;
    if(wait_cnt>0){   //唤醒正在等待当前进程的进程
        pcb_t *p = (pcb_t *) wait_queue.head;
        int pid = current_running->pid;
        while(p!=NULL && wait_cnt>0){
            if(p->wait == pid) {
                p->status=TASK_READY;
		p->wait=-1;
                pcb_t *p2 = queue_remove(&wait_queue,p);  //返回移除后的下一个
                queue_push(&(ready_queue[p->priority]), p);
                p = p2;
                wait_cnt--;
            }
            else p = p->next;
        }
    }
    //释放锁

    int i=0;
    while(i<NUM_MAX_LOCK){
        if(current_running->mutex_lock[i] != 0){
            do_mutex_lock_release(current_running->mutex_lock[i]);
	    current_running->mutex_lock[i] =0;
        }
        i++;
    }
    i=current_running->pid;
    int j=0;
        for(;j<PTE_ENTRY_NUMBER;j++){
            if(pt_table[i][j]&0x2) {
                frame_free(pt_table[i][j]>>6);
                pt_table[i][j] = 0;
            }
        }
    current_running->status = TASK_EXITED;
    do_scheduler();
}

void do_waitpid(pid_t pid){
    current_running->wait = pid;   //等待一个pid执行完毕再继续
    pcb[pid].waited += 1;

    current_running->status = TASK_WAIT;
    do_block(&wait_queue);

    //do_scheduler();
}

void do_block(queue_t *queue)
{
    if (current_running->status==TASK_RUNNING)
    {
        current_running->status=TASK_BLOCKED;
    }
    //current_running->user_context.cp0_epc += 4;
    queue_push(queue,current_running);
    do_scheduler();
}

void do_unblock_one(queue_t *queue)
{
    if(queue_is_empty(queue)==0){
        pcb_t * p = queue_dequeue(queue);
        p->status = TASK_READY;
        queue_push(&(ready_queue[p->priority]),p);
    }
}

void do_unblock_all(queue_t *queue)
{
    while(queue_is_empty(queue)==0){
        pcb_t * p = queue_dequeue(queue);
        p->status = TASK_READY;
        queue_push(&(ready_queue[p->priority]),p);
    }
}

pid_t do_getpid(void){
    return current_running->pid;
}
