#ifndef INCLUDE_MM_H_
#define INCLUDE_MM_H_

#include "type.h"
#include "sched.h"

#define TLB_ENTRY_NUMBER 32
#define PTE_ENTRY_NUMBER 0x800 //2^11个页表项, *4byte=8kb, *4KB=8M,0~0x800000
#define PAGE_FRAME_NUMBER 0x2000  //32M/4KB=2^13个页框  

#define PADDR_BASE 0x00f00000
#define PADDR_TOP 0x02000000
#define VADDR_BASE 0x00000000
#define PAGE_FRAME_SIZE  0x1000//4KB

//pte_t 结构：
// 20位物理页号， 6位flag，依次为C(3), D(1), V(1), G(1)

//page number
#define P_SHIFT 12
#define V_2_PNUM(va) ((uint32_t)(va) >> P_SHIFT)
#define PTE_C 0x10
#define PTE_D 0x4
#define PTE_V 0x2
#define PTE_G 0x1

void do_TLB_Refill();
void do_page_fault();

void init_page_table();
void init_TLB();
void init_swap();

void init_page_frame(void );
void frame_free(uint32_t );
char *frame_alloc(void );
void ff_range(uint32_t , uint32_t);

extern pte_t pt_table[NUM_MAX_TASK][PTE_ENTRY_NUMBER];
extern int free_idx;

#endif
