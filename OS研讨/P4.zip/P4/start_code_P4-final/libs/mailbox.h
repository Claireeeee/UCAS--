#ifndef INCLUDE_MAIL_BOX_
#define INCLUDE_MAIL_BOX_
#include "queue.h"
#define MAXNUMCHAR 50
typedef enum{
    CLOSED,  //0
    OPEN    //1
}status_t;

typedef struct mailbox
{
    int index;
    queue_t queue;
    queue_t sendqueue;
    queue_t resvqueue;
    char name[20];
    char message[MAXNUMCHAR];
    int head;
    int tail;
    int full;
    int empty;
    status_t status;
    int used;     //modify when open & close 
} mailbox_t;


void mbox_init();
mailbox_t *mbox_open(char *);
void mbox_close(mailbox_t *);
void mbox_send(mailbox_t *, void *, int);
void mbox_recv(mailbox_t *, void *, int);

#endif

