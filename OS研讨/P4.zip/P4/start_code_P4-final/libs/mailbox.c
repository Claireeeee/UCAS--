#include "string.h"
#include "mailbox.h"
#include "lock.h"

#define MAX_NUM_BOX 32

static mailbox_t mboxs[MAX_NUM_BOX];
static mutex_lock_t mutex;

void mbox_init()
{
    memset(mboxs,0,sizeof(mboxs));
    do_mutex_lock_init(&mutex);
}


mailbox_t *mbox_open(char *name)
{
    do_mutex_lock_acquire(&mutex);
    int i=0,fstclo=-1;
    for(;i<MAX_NUM_BOX&&strcmp(name,mboxs[i].name)!=0;i++){  //==0 means the same
        if (mboxs[i].status==CLOSED&&fstclo<0)  //first closed mailbox
        {
            fstclo=i;
        }
    }
    if (i==MAX_NUM_BOX&&fstclo<0)
    {
        printkf("mboxs open error: mboxs is full\n");
        do_mutex_lock_release(&mutex);
    }
    else if (i==MAX_NUM_BOX&&fstclo>=0)
    {
        i=fstclo;
        memset(&mboxs[i],0,sizeof(mboxs[i]));
        mboxs[i].status = OPEN;
        mboxs[i].head = mboxs[i].tail = 0;
        mboxs[i].empty=1;
        strcpy(mboxs[i].name,name);
        queue_init(&mboxs[i].sendqueue);
        queue_init(&mboxs[i].resvqueue);
        mboxs[i].index=blockqueue_register(&mboxs[i].sendqueue);
        blockqueue_register(&mboxs[i].resvqueue);
        do_mutex_lock_release(&mutex);
        return &mboxs[i];
    }
    else  //(strcmp(name,mboxs[i].name)==0)
    {
        mboxs[i].status = OPEN;
        do_mutex_lock_release(&mutex);
        return &mboxs[i];
    }
}

void mbox_close(mailbox_t *mailbox)
{
    mailbox->status = CLOSED;
}

void mbox_send(mailbox_t *mailbox, void *msg, int msg_length)
{
    do_mutex_lock_acquire(&mutex);
    char *_msg = (char *)msg;
    int i=0;
    while(i<msg_length){   //
    while(mailbox->full==1)
    {
        //printf("\nOHHHHHHHHHHHHHH  full!!!!!!!!1\n  my name is %s",mailbox->name);
        do_mutex_lock_release(&mutex);
        sys_block(&mailbox->sendqueue);
        do_mutex_lock_acquire(&mutex);
    }
        mailbox->message[mailbox->tail%MAXNUMCHAR] = *(_msg++);
        mailbox->tail +=1;
        mailbox->full = mailbox->tail==(mailbox->head+MAXNUMCHAR);   //
        mailbox->empty = 0;
        do_unblock_all(&mailbox->resvqueue);    //
        i++;
    }
    do_mutex_lock_release(&mutex);
}

void mbox_recv(mailbox_t *mailbox, void *msg, int msg_length)
{
    do_mutex_lock_acquire(&mutex);
    char *_msg = (char *)msg;
    int i=0;
    while(i<msg_length){   //一个字符一个字符的输入
    while(mailbox->empty==1)
    {
        do_mutex_lock_release(&mutex);
        sys_block(&mailbox->resvqueue);
        do_mutex_lock_acquire(&mutex);
    }
        *(_msg++)=mailbox->message[mailbox->head%MAXNUMCHAR];
        mailbox->head +=1;
        mailbox->empty = mailbox->tail==mailbox->head;   //
        mailbox->full= 0;
        do_unblock_all(&mailbox->sendqueue);    //
        i++;
    }

    do_mutex_lock_release(&mutex);

}


