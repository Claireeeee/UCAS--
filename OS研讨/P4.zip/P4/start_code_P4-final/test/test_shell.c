#include "test.h"
#include "stdio.h"
#include "screen.h"
#include "syscall.h"
#include "sched.h"

static void disable_interrupt()
{
    uint32_t cp0_status = get_cp0_status();
    cp0_status &= 0xfffffffe;
    set_cp0_status(cp0_status);
}

static void enable_interrupt()
{
    uint32_t cp0_status = get_cp0_status();
    cp0_status |= 0x01;
    set_cp0_status(cp0_status);
}

static char read_uart_ch(void)
{
    char ch = 0;
    unsigned char *read_port = (unsigned char *)(0xbfe48000 + 0x00);
    unsigned char *stat_port = (unsigned char *)(0xbfe48000 + 0x05);

    while ((*stat_port & 0x01))
    {
        ch = *read_port;
    }
    return ch;
}

struct task_info task1 = {"task1", (uint32_t)&drawing_task1, USER_PROCESS};
struct task_info task2 = {"task2", (uint32_t)&rw_task1, USER_PROCESS};

static struct task_info *test_tasks[2] = {&task1, &task2};
static int num_test_tasks = 2;

void test_shell()
{
    //分配中断输出区
    sys_move_cursor(0,SCREEN_HEIGHT/2);
    printf("---------------------HELLO:)))))))--------------------");
    int print_location = SCREEN_HEIGHT-1;  //the second last line
    sys_move_cursor(0,print_location);
    printf(">root@UCAS_OS: ");

//要支持的指令：ps，clear，exec x，kill x

    while (1)
    {
        char ch;
        char buff[101];   //指令长度
        int i=0, gotcom=1;

        disable_interrupt();
        //close_int();
	ch=read_uart_ch();
        if((ch!='\0') && (ch!= 13))   //判断有无指令，如果没有，跳过解析进入下一轮循环
        {
            if(ch==127||ch==8){//bs（backspace
                    i--; 
                    screen_write_ch(ch);
                    screen_reflush();
                    continue;
            }
            else{
                buff[i++] = ch;
                screen_write_ch(ch);   //实时显示
                screen_reflush();
            }

            //读取一行指令（空/退格/记入缓冲区；回车符结束
            while(((ch=read_uart_ch()) != 13) && i<100)    //13是回车符（enter键直接映射为13的/r（而不是/n
            {
                if(ch=='\0') continue;
                if(ch==127||ch==8   ){  //backspace
                    i--; 
                    screen_write_ch(ch);
                    screen_reflush();
                    continue;
                }

                buff[i++] = ch;
                screen_write_ch(ch);
                screen_reflush();         
            }
            
            buff[i] = '\0';
            screen_write_ch('\n');
            screen_reflush();
        }

        else
        {
            gotcom = 0;
        }
	//start_int();
        enable_interrupt();


        if(gotcom){

            if(i==100){
                sys_move_cursor(0, print_location);
                printf("The command is at most of length 100\n");
            }

            if(buff[0]=='p' && buff[1]=='s') 
                sys_ps();
            else if(buff[0]=='c'&& buff[1]=='l'&&buff[2]=='e'&&buff[3]=='a'&&buff[4]=='r') 
                sys_clear();
            /*else if(buff[0]=='e'&&buff[1]=='x'&&buff[2]=='e'&&buff[3]=='c')
            {
		int k=0;
                int a=0,j=5;
                while(buff[j]>='0' && buff[j]<='9')
                    a = a*10 + buff[j++]-'0';
		sys_argvs[k++]=test_tasks[a];
		for(j++;buff[j]!='\0'&&j<100;j++)
		{
}
                printf("exec test_task[%d].\n",a);
                sys_spawn(test_tasks[a]);
            }*/
		else if(buff[0]=='e'&&buff[1]=='x'&&buff[2]=='e'&&buff[3]=='c')
		{
			int k=0;
		    int a=0,j=5;
		    while(buff[j]>='0' && buff[j]<='9')
			a = a*10 + buff[j++]-'0';
		    printf("exec test_task[%d].\n",a);
			sys_argvs[k++]=(int)test_tasks[a];
			for(;buff[j]!='\0'&&j<100;)
			{
			j++;
			if (buff[j]=='0'&&buff[j+1]=='x')
			{
			    a=0;j+=2;
			    while(buff[j]>='0' && buff[j]<='9' || buff[j]>='a'&&buff[j]<='f')
			    {
				if (buff[j]>='0' && buff[j]<='9')
				    a = a*16 + buff[j++]-'0';
				else
				    a = a*16 + buff[j++]-'a'+10;
			    }
			    sys_argvs[k++]=a;
			}
		    }

		    sys_spawn((int *)&(sys_argvs[0]));
		}
            else if(buff[0]=='k'&&buff[1]=='i'&&buff[2]=='l'&&buff[3]=='l')
            {
                int a=0,j=5;
                while(buff[j]>='0' && buff[j]<='9')
                    a = a*10 + buff[j++]-'0';
                printf("kill pcb[%d].\n",a);
                sys_kill(a);
            }
            else
            {
                printf("UNKNOWN COMMAND\n");
            }
            //screen_reflush();

            print_location = SCREEN_HEIGHT-1;
            sys_move_cursor(0,print_location);
            printf(">root@UCAS_OS: ");

        }
    }
}
