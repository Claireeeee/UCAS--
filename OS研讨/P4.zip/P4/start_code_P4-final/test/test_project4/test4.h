#ifndef INCLUDE_TASK4_H_
#define INCLUDE_TASK4_H_

#include "type.h"

//test drawing
void drawing_task1(void);

//test memory
void rw_task1(unsigned long*);

//test_shell
void test_shell(void);

#endif
