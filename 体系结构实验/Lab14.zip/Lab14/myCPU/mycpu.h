`ifndef MYCPU_H
    `define MYCPU_H

    `define BR_BUS_WD       35
    `define FS_TO_DS_BUS_WD 101
    `define DS_TO_ES_BUS_WD 217 //179+32
    `define ES_TO_MS_BUS_WD 152 //+5
    `define MS_TO_WS_BUS_WD 137 
    `define WS_TO_RF_BUS_WD 62

	`define cp0_status_addr 96
	`define cp0_cause_addr  104
	`define cp0_epc_addr    112
    `define CR_COUNT        {5'd9,  3'd0}
    `define CR_COMPARE      {5'd11, 3'd0}
    `define CR_BADVADDR     {5'd8 , 3'd0}

    `define CR_EntryHi      {5'd10, 3'd0}
    `define CR_EntryLo0     {5'd2 , 3'd0}
    `define CR_EntryLo1     {5'd3 , 3'd0}
    `define CR_Index        {5'd0 , 3'd0}
    `define TLBNUM  16

`endif
/*
assign cp0_rd_value = 
        {32{cp0_raddr=={5'd8 , 3'd0}}}&badvaddr_value    
      | {32{cp0_raddr=={5'd12, 3'd0}}}&status_value     
      | {32{cp0_raddr=={5'd13, 3'd0}}}&cause_value      
      | {32{cp0_raddr=={5'd14, 3'd0}}}&epc_value        
      | {32{cp0_raddr=={5'd15, 3'd0}}}&pid_value        
      | {32{cp0_raddr=={5'd16, 3'd0}}}&config_value     
      | {32{cp0_raddr=={5'd16, 3'd1}}}&config1_value    
      | {32{cp0_raddr=={5'd30, 3'd0}}}&errorepc_value   
      | {32{cp0_raddr=={5'd23, 3'd0}}}&cr_debug_value
      | {32{cp0_raddr=={5'd24, 3'd0}}}&depc_value
      | {32{cp0_raddr=={5'd31, 3'd0}}}&desave_value
      | {32{cp0_raddr=={5'd9,  3'd0}}}&count_value
      | {32{cp0_raddr=={5'd11, 3'd0}}}&compare_value
      ;*/
